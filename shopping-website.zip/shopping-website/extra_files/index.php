<?php
	session_start();
?>
<?php
	include('inc/header.php');
	include('lib/banner-class.php');
	$banner = new bannerSection();
	include('lib/products-class.php');
	$product = new productSection();
?>
<!--CATEGORY SECTION -->
<section class="thumnailSection">
<div class="container  text-center ">
  <div class="row">
	<?php
	$category = new categorySection;
	$categoryResult = $category->updateCategorySection();
	if(mysqli_num_rows($categoryResult)>0){
		while($category = mysqli_fetch_assoc($categoryResult)){
			//ABSOLUTE image path using define.php
			$imagePath = UPLOAD_PATH.'categories/'.$category['image'];
	?>
      <div class="thumbnail col">
       	<div class="thumbnailPic">
       		<img src="<?php echo $imagePath; ?>" alt="image" />
       	</div>
       	<div class="thumbnailname">
       		<h5><a href="cricketProducts.php"><?php echo $category['title']; ?></a></h5>
       	</div>
      </div>
	<?php
		}
	}
	?>
  </div>
 </div>
</section>

<!-- BANNER CAROUSEL -->
<section class="carouselSection border border-dark border-1 border-start-0 border-end-0">
<div id="carouselExampleDark" class="carousel carousel-white slide" data-bs-ride="carousel">
       <?php
		$bannerResult = $banner->updateBannerSection();
		if(mysqli_num_rows($bannerResult)>0){
			$i=0;
			$activeButton = 'active';
       ?>
		<div class="carousel-indicators">
          <?php
		     while($bannerRow = mysqli_fetch_assoc($bannerResult)){
          ?>
           <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="<?php echo $i; ?>" class="<?php echo $activeButton; ?>" aria-current="true" aria-label="Slide <?php echo $i+1; ?>"></button>
          <?php
			$i++;
			$activeButton ='';
             }
          ?>
        </div>
       <?php
        }
       ?>
	  
  <div class="carousel-inner" data-bs-interval="3000">
       <?php
			$bannerRes = $banner->updateBannerSection();
			if(mysqli_num_rows($bannerRes)>0){
			$active = 'active';
				while($bannerRow = mysqli_fetch_assoc($bannerRes)){
					$image = 'banners/'.$bannerRow['image'];
					$imagePath = UPLOAD_PATH.$image;
       ?>
           <div class="carousel-item <?php echo $active;?>" data-bs-interval="2000">
            	<img src="<?php echo $imagePath; ?>" class="d-block w-100" alt="..." />
           </div>
     	<?php
     	  $active='';
     		}
     	}
     	?>
  </div>
  
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</section>

<!--HOME PAGE PRODUCTS-->
<section class="homeProductsSection">
<div class="container">
	<div class="homeProductsHeading">
		<h5 class="fw-bold">Featured Products!</h5>
	</div>
	<!-- CRICKET -->
	<div class="homeProductRow row">
	<?php
		$result = $product->updateCricketSection();
		if(mysqli_num_rows($result)>0){
			while($productRow = mysqli_fetch_assoc($result)){
				$image = 'products/'.$productRow['image'];
					$imagePath = UPLOAD_PATH.$image;
	?>
	 <div class="col-6 col-sm-6 col-md-3 col-lg-3">
        <div class="card" style="width:;">
        	<a href=""><img src="<?php echo $imagePath;?>" class="card-img-top" alt="..." /></a>
			<!--https://www.decathlon.in/p/8754325/tennis-cricket-bat-and-balls/t-500-light-adult-blue?id=8754325&type=p-->
        	<div class="card-body">
        		<h5 class="card-title"><?php echo $productRow['title'];?></h5>
        		<p class="fw-bold">Price: ₹ <span class="text-success productPrice"><?php echo $productRow['price'];?> </span></p>
        		<a href="" class="w-100 btn border border-dark border-1">Check Product</a>
        	</div>
        </div>
	 </div>
	 <?php
			}
		}
	 ?>
	 </div>
	 <!-- <div class="col-6 col-sm-6 col-md-3 col-lg-3">
        <div class="card" style="width:;">
        	<a href=""><img src="images/products/cricketProducts/flxbat4.avif" class="card-img-top" alt="..." /></a>
			<!-- https://www.decathlon.in/p/8754018/kids-cricket-bats/kids-cricket-bat-kashmir-willow-kw100-blue?id=8754018&type=p-->
        	<!--<div class="card-body">
        		<h5 class="cardTitle card-title">FLX KW100 Bat For Kids with Strongest Handle</h5>
        		<p class="fw-bold">Price: <span class="text-success">₹ 1,820 </span></p>
        		<a href="" class="w-100 btn border border-dark border-1">Check Product</a>
        	</div>
        </div>
	 </div>
	 <div class="col-6 col-sm-6 col-md-3 col-lg-3">
        <div class="card" style="width:;">
        	<img src="images/products/cricketProducts/flxbat2.avif" class="card-img-top" alt="..." />
			<!--https://www.decathlon.in/p/8754271/kids-cricket-bats/t-100-easy-kids-tennis-ball-cricket-bat-grey?id=8754271&type=p-->
        	<!--<div class="card-body">
        		<h5 class="card-title">FLX T 500 Cricket Bat</h5>
        		<p class="fw-bold">Price: <span class="text-success">₹ 1,320 </span></p>
        		<a href="" class="w-100 btn border border-dark border-1">Check Product</a>
        	</div>
        </div>
	 </div>
	 <div class="col-6 col-sm-6 col-md-3 col-lg-3">
        <div class="card" style="width:;">
        	<img src="images/products/cricketProducts/flxbat3.avif" class="card-img-top" alt="..." />
			<!--https://www.decathlon.in/p/8754288/kids-cricket-bats/t-500-lite-kids-poplar-wood-bat-blue?id=8754288&type=p -->
        	<!--<div class="card-body">
        		<h6 class="card-title">T 100 Easy Cricket Bat for Adults with Sticker</h6>
        		<p class="fw-bold">Price: <span class="text-success">₹ 1,499 </span></p>
        		<a href="" class="w-100 btn border border-dark border-1g">Check Product</a>
        	</div>
        </div>
	 </div>
	</div>
	<!-- FOOTBALL -->
	<div class="homeProductRow row">
	<?php
	$result = $product->updateFootballSection();
		if(mysqli_num_rows($result)>0){
			while($productRow = mysqli_fetch_assoc($result)){
				$image = 'products/'.$productRow['image'];
					$imagePath = UPLOAD_PATH.$image;
	
	?>
	 <div class="col-6 col-sm-6 col-md-3 col-lg-3">
        <div class="card" style="width:;">
        	<a href=""><img src="<?php echo $imagePath; ?>" class="card-img-top" alt="..." /></a>
			<!-- https://www.decathlon.in/p/8619218/footballs/football-club-ball-size-5-fifa-basic-f500-white-yellow?id=8619218&type=p -->
        	<div class="card-body">
        		<h5 class="card-title"><?php echo $productRow['title']; ?></h5>
        		<p class="fw-bold">Price: ₹ <span class="text-success"><?php echo $productRow['price'];  ?></span></p>
        		<a href="" class="w-100 btn border border-dark border-1">Check Product</a>
        	</div>
        </div>
	 </div>
	 <?php
			}
		}
	 ?>
	 </div>
	 <!--<div class="col-6 col-sm-6 col-md-3 col-lg-3">
        <div class="card" style="width:;">
        	<img src="images/products/footballProducts/football2.avif" class="card-img-top" alt="..." />
			<!--https://www.decathlon.in/p/8619228/footballs/football-ball-match-size-5-fifa-pro-f900-green?id=8619228&type=p -->
        	<!--<div class="card-body">
        		<h5 class="card-title">KIPSTA Fifa Pro Football For Kids with High durability</h5>
        		<p class="fw-bold">Price: <span class="text-success">₹ 1,100 </span></p>
        		<a href="" class="w-100 btn border border-dark border-1">Check Product</a>
        	</div>
        </div>
	 </div>
	 <div class="col-6 col-sm-6 col-md-3 col-lg-3">
        <div class="card" style="width:;">
        	<img src="images/products/footballProducts/football3.avif" class="card-img-top" alt="..." />
			<!--https://www.decathlon.in/p/8676296/footballs/football-ball-training-size-3-below-8-years-first-kick-blue?id=8676296&type=p -->
        	<!--<div class="card-body">
        		<h5 class="card-title">KIPSTA Kids Football</h5>
        		<p class="fw-bold">Price: <span class="text-success">₹ 1,999 </span></p>
        		<a href="" class="w-100 btn border border-dark border-1">Check Product</a>
        	</div>
        </div>
	 </div>
	 <div class="col-6 col-sm-6 col-md-3 col-lg-3">
        <div class="card" style="width:;">
        	<img src="images/products/footballProducts/football4.avif" class="card-img-top" alt="..." />
			<!-- https://www.decathlon.in/p/8753532/footballs/size-4-football-sunny-300-green?id=8753532&type=p -->
        	<!--<div class="card-body">
        		<h5 class="card-title">KIPSTA Sunny 300 Football</h5>
        		<p class="fw-bold">Price: <span class="text-success">₹ 950 </span></p>
        		<a href="" class="w-100 btn border border-dark border-1">Check Product</a>
        	</div>
        </div>
	 </div>
	</div>
	<!-- BADMINTON -->
	<div class="homeProductRow row">
	<?php
	$result = $product->updateBadmintonSection();
	if(mysqli_num_rows($result)>0){
		while($productRow = mysqli_fetch_assoc($result)){
			$image = 'products/'.$productRow['image'];
			$imagePath = UPLOAD_PATH.$image;
	?>
	<div class="col-6 col-sm-6 col-md-3 col-lg-3">
        <div class="card" style="width:;">
        	<img src="<?php echo $imagePath; ?>" class="card-img-top" alt="..." />
			<!-- https://www.decathlon.in/p/8515766/outdoor-badminton/adult-badminton-racket-br-100-red?id=8515766&type=p -->
        	<div class="card-body">
        		<h5 class="card-title"><?php echo $productRow['title'];  ?></h5>
        		<p class="fw-bold">Price: ₹ <span class="text-success"><?php echo $productRow['price']; ?></span></p>
        		<a href="" class="w-100 btn border border-dark border-1">Check Product</a>
        	</div>
        </div>
	 </div>
	<?php
		}
	}
	?>
	</div>
	 <!--<div class="col-6 col-sm-6 col-md-3 col-lg-3">
        <div class="card" style="width:;">
        	<img src="images/products/badmintonProducts/badminton2.avif" class="card-img-top" alt="..." />
			<!-- https://www.decathlon.in/p/8649017/outdoor-badminton/adult-badminton-racket-br-160-black-green?id=8649017&type=p -->
        	<!--<div class="card-body">
        		<h5 class="card-title">BR 160 Badminton</h5>
        		<p class="fw-bold">Price: <span class="text-success">₹ 1,600 </span></p>
        		<a href="" class="w-100 btn border border-dark border-1">Check Product</a>
        	</div>
        </div>
	 </div>
	 <div class="col-6 col-sm-6 col-md-3 col-lg-3">
        <div class="card" style="width:;">
        	<img src="images/products/badmintonProducts/badminton3.avif" class="card-img-top" alt="..." />
			<!-- https://www.decathlon.in/p/8735707/outdoor-badminton/adult-badminton-racket-br-190-set-partner-blue-grey-pink?id=8735707&type=p -->
        	<!--<div class="card-body">
        		<h5 class="card-title">Perly BR 190</h5>
        		<p class="fw-bold">Price: <span class="text-success">₹ 1,800 </span></p>
        		<a href="" class="w-100 btn border border-dark border-1">Check Product</a>
        	</div>
        </div>
	 </div>
	 <div class="col-6 col-sm-6 col-md-3 col-lg-3">
        <div class="card" style="width:;">
        	<img src="images/products/badmintonProducts/badminton4.avif" class="card-img-top" alt="..." />
			<!--https://www.decathlon.in/p/8846012/kid-s-badminton-racket/kids-badminton-racket-85g-aluminium-br-100-orange?id=8846012&type=p-->
        	<!--<div class="card-body">
        		<h5 class="card-title">Perly Kids Badminton</h5>
        		<p class="fw-bold">Price: <span class="text-success">₹ 1,320 </span></p>
        		<a href="" class="w-100 btn border border-dark border-1">Check Product</a>
        	</div>
        </div>
	 </div>
	</div>
	<!-- BASKETBALL -->
	<div class="homeProductRow row">
	<?php
	$result = $product->updateBasketballSection();
	if(mysqli_num_rows($result)>0){
		while($productRow = mysqli_fetch_assoc($result)){
			$image = 'products/'.$productRow['image'];
			$imagePath = UPLOAD_PATH.$image;
	?>
	<div class="col-6 col-sm-6 col-md-3 col-lg-3">
        <div class="card" style="width:;">
        	<img src="<?php echo $imagePath;  ?>" class="card-img-top" alt="..." />
			<!--  https://www.decathlon.in/p/8734288/basketball-hoops/kids-wall-mounted-basketball-hoop-sk100-dunkers-turquoise-purple?id=8734288&type=p-->
        	<div class="card-body">
        		<h5 class="card-title"><?php echo $productRow['title'];  ?></h5>
        		<p class="fw-bold">Price: ₹ <span class="text-success"><?php echo $productRow['price']; ?></span></p>
        		<a href="" class="w-100 btn border border-dark border-1">Check Product</a>
        	</div>
        </div>
	 </div>
	<?php
		}
	}
	?>
	</div>
	 <!--<div class="col-6 col-sm-6 col-md-3 col-lg-3">
        <div class="card" style="width:;">
        	<img src="images/products/basketballProducts/basketball.avif" class="card-img-top" alt="..." />
			<!--https://www.decathlon.in/p/8616155/adult-basketballs/basketball-ball-size-1-mini-b-red?id=8616155&type=p  -->
        	<!--<div class="card-body">
        		<h5 class="card-title">Tarmak Basketball</h5>
        		<p class="fw-bold">Price: <span class="text-success">₹ 1,540 </span></p>
        		<a href="" class="w-100 btn border border-dark border-1">Check Product</a>
        	</div>
        </div>
	 </div>
	 <div class="col-6 col-sm-6 col-md-3 col-lg-3">
        <div class="card" style="width:;">
        	<img src="images/products/basketballProducts/basketballRing.avif" class="card-img-top" alt="..." />
			<!-- https://www.decathlon.in/p/8496975/backboards-hoops-accessories/basketball-ring-official-size-flexible-basketball-rim-r900-red?id=8496975&type=p -->
        	<!--<div class="card-body">
        		<h5 class="card-title">Basketball Ring</h5>
        		<p class="fw-bold">Price: <span class="text-success">₹ 900 </span></p>
        		<a href="" class="w-100 btn border border-dark border-1">Check Product</a>
        	</div>
        </div>
	 </div>
	 <div class="col-6 col-sm-6 col-md-3 col-lg-3">
        <div class="card" style="width:;">
        	<img src="images/products/basketballProducts/basketballBoard2.avif" class="card-img-top" alt="..." />
			<!-- https://www.decathlon.in/p/8547161/basketball-hoops/basketball-hoop-wall-mounted-fibre-board-sb700?id=8547161&type=p -->
        	<!--<div class="card-body">
        		<h5 class="card-title">Basketball Tarmak Board</h5>
				<p class="fw-bold">Price: <span class="text-success">₹ 3,320 </span></p>
        		<a href="" class="checkout w-100 btn border border-dark border-1">Check Product</a>
        	</div>
        </div>
	 </div>
	</div>-->
</div>
<script>
	document.addEventListener("DOMContentLoaded", function(){
		const title = document.querySelectorAll('.card-title');
		title.forEach(title =>{
			if(title.innerText.length > 36){
				title.innerText = title.innerText.slice(0,36) + '...';
			}
		});
	});
</script>

</section>

<?php
  include('inc/footer.php');
?>