<!-- HEADER LINKS -->
<head>
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap" rel="stylesheet" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" />
	<!-- <script src="https://code.jquery.com/jquery-2.1.3.min.js"></script> -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
</head>
<!-- PASSWORD encrypt/decrypt -->
<?php
   password enc/dec
   $enteredPass =  base64_encode('222222'); 
   $salt = 'a;g0d-wd8*oiba';
   $enteredPass = hash("sha256", $enteredPass.$salt);
   echo $enteredPass = strrev($enteredPass);
?>
<!--card title -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cricket Bats</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
    <div class="homeProductRow row">
        <div class="col-6 col-sm-6 col-md-3 col-lg-3">
            <div class="card">
                <img src="images/products/cricketProducts/flxbat.avif" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">T 100 Bat</h5>
                    <p class="fw-bold">Price: <span class="text-success">₹ 2,999</span></p>
                    <a href="" class="w-100 btn border border-dark border-1">Check Product</a>
                </div>
            </div>
        </div>
        <div class="col-6 col-sm-6 col-md-3 col-lg-3">
            <div class="card">
                <img src="images/products/cricketProducts/flxbat4.avif" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">FLX KW100 Bat</h5>
                    <p class="fw-bold">Price: <span class="text-success">₹ 1,820</span></p>
                    <a href="" class="w-100 btn border border-dark border-1">Check Product</a>
                </div>
            </div>
        </div>
        <div class="col-6 col-sm-6 col-md-3 col-lg-3">
            <div class="card">
                <img src="images/products/cricketProducts/flxbat2.avif" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">FLX T 500 Bat</h5>
                    <p class="fw-bold">Price: <span class="text-success">₹ 1,320</span></p>
                    <a href="" class="w-100 btn border border-dark border-1">Check Product</a>
                </div>
            </div>
        </div>
        <div class="col-6 col-sm-6 col-md-3 col-lg-3">
            <div class="card">
                <img src="images/products/cricketProducts/flxbat3.avif" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">T 100 Easy Cricket Bat</h5>
                    <p class="fw-bold">Price: <span class="text-success">₹ 1,499</span></p>
                    <a href="" class="w-100 btn border border-dark border-1g">Check Product</a>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const titles = document.querySelectorAll('.card-title');
            titles.forEach(title => {
                if (title.textContent.length > 15) {
                    title.textContent = title.textContent.slice(0, 15) + '...';
                }
            });
        });
    </script>
</body>
</html>
<!--session fnmae-->
<?php
include('inc/header.php');
include('lib/login-class.php');
$login = new Login;
$message = '';
?>

<?php
$email = $pass = "";
$emailError = $passwordError = "";

if(isset($_POST['login'])){
    $email = $_POST['loginEmail'];
    $pass = $_POST['loginPassword'];
    
    if(empty($email)){
        $emailError = 'Enter your Email Address!';
    }
    if(empty($pass)){
        $passwordError = 'Enter your Password!';
    }
    
    if(empty($emailError) && empty($passwordError)){
        $result = $login->checkLoginData($email, $pass);
        if($result === "successful"){
            // Assuming you have a database connection in $conn
            $sql = "SELECT first_name FROM users WHERE email = '$email'";
            $queryResult = mysqli_query($conn, $sql);
            if($queryResult && mysqli_num_rows($queryResult) > 0){
                $row = mysqli_fetch_assoc($queryResult);
                $_SESSION['username'] = $row['first_name']; // Storing first_name in the session
                $_SESSION['loggedin'] = true;
                echo "<script>
                    window.location.href='home.php';
                    </script>";
            } else {
                $message = 'User not found!';
            }
        } else if($result === "failed"){
            $message = 'Credentials didn\'t match!';
        }
    }
}
?>
<!--class name-->
<?php 
session_start();
if(isset($_SESSION['loggedin'])){
	header("Location: home.php");
	exit();
}
?>

<?php
require_once('inc/header.php');
require_once('lib/login-class.php');
$login = new Login;
$message='';
?>

<?php
$email = $pass = "";
$emailError = $passwordError = "";

if(isset($_POST['login'])){
	$email = $_POST['loginEmail'];
	$pass = $_POST['loginPassword'];
	
	if(empty($email)){
		$emailError = 'Enter your Email Address!';
	}
	if(empty($pass)){
		$passwordError = 'Enter your Password!';
	}
	
	if(empty($emailError) && empty($passwordError)){
        $result = $login->checkLoginData($email, $pass);
        if($result === "successful"){
            $sql = "SELECT first_name FROM users WHERE email = '$email'";
            $queryResult = mysqli_query($conn, $sql);
            if($queryResult && mysqli_num_rows($queryResult) > 0){
                $row = mysqli_fetch_assoc($queryResult);
                $_SESSION['username'] = $row['first_name'];
                $_SESSION['loggedin'] = true;
                echo "<script>
                    window.location.href='home.php';
                    </script>";
                exit();
            } else {
                $message = 'User not found!';
            }
        } else if($result === "failed"){
            $message = 'Credentials didn\'t match!';
        }
    }
}
?>

<?php
if(empty($emailError) && empty($passwordError)){
    $result = $login->checkLoginData($email, $pass);
    if($result === "successful"){
        $sql = "SELECT id FROM users WHERE email = '$email'";
        $queryResult = mysqli_query($conn, $sql);
        if($queryResult && mysqli_num_rows($queryResult) > 0){
            $row = mysqli_fetch_assoc($queryResult);
            $id = $row['id'];
            //$_SESSION['username'] = $row['first_name'];
            $_SESSION['loggedin'] = true;
            echo "<script>
                window.location.href='index.php?id=$id';
                </script>";
            exit();
        } else {
            $message = 'User not found!';
        }
    } else if($result === "failed"){
        $message = 'Credentials didn\'t match!';
    }
}
logout.php $ Login
login.php
function logout()
	{
		unset($_SESSION['cust_id']);
		unset($_SESSION['cust_name']);
		unset($_SESSION['cust_type']);
		return 1;
	}
?>
<?php
session_start();

$_SESSION['user_id'] = $userId;
header("Location: home.php");
exit();
?>
logout.php
<?php
session_start();

if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];
  
    $db = new mysqli("hostname", "username", "password", "database");
    if ($db->connect_error) {
        die("Connection failed: " . $db->connect_error);
    }

    $stmt = $db->prepare("SELECT id FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        session_unset();
        session_destroy();
        $_SESSION = array(); 
        header("Location: home.php");
        exit();
    } else {
        echo "Invalid session or user not found.";
    }

    $stmt->close();
    $db->close();
} else {
    // No user is logged in
    header("Location: home.php");
    exit();
}
?>
my logout.php
<?php
 include('lib/connection.php');
	session_start(); 
	if (isset($_SESSION['cms_user_id'])) {
		global $conn;
		$userId = $_SESSION['cms_user_id'];
		$sql = "SELECT id from cms_users where id = '$userId'";
		$result = mysqli_query($conn,$sql);
		if(mysqli_num_rows($result)>0){
			session_unset();
			session_destroy();
			$_SESSION=array();
			$_SESSION['cms_loggedin'] = false;
			header("Location: home.php");
		exit();
		}
	
	}
?>
<!-- queryResult -->
<?php
	class categorySection {
		public function updateCategorySection() {
			global $conn;
			
			$sql = "
				SELECT c1.title, c1.image, c1.font_class
				FROM category c1
				JOIN category c2 ON c1.parent_id = c2.id
				WHERE c1.live = '1' 
				  AND c1.delete_id = '0'
				  AND c2.parent_id = '0' 
				  AND c2.live = '1'
			";
			
			$result = mysqli_query($conn, $sql);
			return $result;
		}
	}
?>
<!-- Category Menu -->
<div class="dropdown mt-3">
	<button class="w-75 btn btn-secondary text-start mb-3" type="button">
		<i class="fa-solid fa-house"></i> <a style="text-decoration:none;color:white;" href="<?php echo ROOT_PATH;?>index.php?id=<?php echo $id;?>" >HOME </a>
	</button>
	<button class="w-75 btn btn-secondary dropdown-toggle text-start" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown">
		<i class="fa-solid fa-layer-group"></i> CATEGORIES
	</button>
	<ul class="dropdown-menu bg-warning w-75" aria-labelledby="dropdownMenuButton">
    <?php
     $categoryResult = $category->updateCategoryMenu();
     if(mysqli_num_rows($categoryResult)>0){
    	 while($category = mysqli_fetch_assoc($categoryResult)){
    ?>
		<li><a class="categoryItems dropdown-item" href="cricketProducts.php"><i class="<?php echo $category['font_class'];?>"></i>  <?php echo $category['title'];?></a></li>
    <?php
     	}
     }
    ?>
	</ul>
</div>
<!--price -->
<div class="col-6 col-sm-6 col-md-3 col-lg-3">
    <div class="card">
        <a href=""><img src="<?php echo $imagePath;?>" class="card-img-top" alt="..." /></a>
        <!--https://www.decathlon.in/p/8754325/tennis-cricket-bat-and-balls/t-500-light-adult-blue?id=8754325&type=p-->
        <div class="card-body">
            <h5 class="card-title"><?php echo $productRow['title'];?></h5>
            <p class="fw-bold">Price: <span class="text-success productPrice">₹ <?php echo $productRow['price'];?> </span></p>
            <a href="" class="w-100 btn border border-dark border-1">Check Product</a>
        </div>
    </div>
    <script>
    document.addEventListener("DOMContentLoaded", function() {
        const prices = document.querySelectorAll('.productPrice');
        prices.forEach(price => {
            const priceText = price.innerText.replace('₹ ', '').replace(',', '');
            const formattedPrice = Number(priceText).toLocaleString('en-IN', { style: 'currency', currency: 'INR' });
            price.innerText = formattedPrice;
        });
    });
    </script>
</div>
<!-- load products in front end -->

<?php
$categoryLimit = 4; // Limit to 4 categories
$categoryCount = 0; // Initialize category counter

$result = $product->queryMainCategory();
if($result){
    while($mainCatRow = mysqli_fetch_assoc($result)){
        $id = $mainCatRow['id'];
        $categoryCount++; // Increment category counter

        if($categoryCount > $categoryLimit) break; // Stop loop after 4 categories

        ?>
        <div class="homeProductRow row">
        <?php
        $productResult = $product->queryProductForCategory($id);
        if($productResult){
            while($productRow = mysqli_fetch_assoc($productResult)){
                $image = 'products/'.$productRow['image'];
                $imagePath = UPLOAD_PATH.$image;
        ?>
        <div class="col-6 col-sm-6 col-md-3 col-lg-3">
            <div class="card" style="width:;" data-id="<?php echo $productRow['id'];?>" >
                <a href=""><img src="<?php echo $imagePath;?>" class="card-img-top" alt="..." /></a>
                <div class="card-body">
                    <h5 class="card-title"><?php echo $productRow['title'];?></h5>
                    <p class="fw-bold">Price: ₹ <span class="text-success productPrice"><?php echo $productRow['price'];?> </span></p>
                    <a href="" class="w-100 btn border border-dark border-1">Check Product</a>
                </div>
            </div>
        </div>
        <?php
            }
        }
        ?>
        </div>
        <?php
    }
}
?>
