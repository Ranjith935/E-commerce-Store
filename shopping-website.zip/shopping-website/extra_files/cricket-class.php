<?php
	class Cricket{
		public function insertCricketData($userId){
			global $conn;
			$title=$_POST['title'];
			$description = $_POST['description'];
			$fontclass = $_POST['fontclass'];
			
			$bLive = $_POST['bLive'];
			$ip = $_SERVER['REMOTE_ADDR'];
			
			include('inc/uploadCricket.php');
			$target_file = uploadFile($_FILES['fileupload']);
		
			$sql="INSERT INTO cricket SET
				`title`='".$title."', 
				`description`='".$description."', 
				`image`='".$target_file."', 
				`font_class`='".$fontclass."', 
				`live`='".$bLive."', 
				`ip_address`='".$ip."',
				`created_by` = '".$userId."' ";
				
			$result = mysqli_query($conn,$sql);
			return $result;
	   }
		
		// For banner.php to load the data from table
		public function selectTableData(){
			global $conn;
			$query = "SELECT id,title, description,live FROM cricket WHERE delete_id='0'";
			$result = mysqli_query($conn,$query);
			return $result;
		}
		// to display the banner image.
		public function showImage($title){
			global $conn;
			$query = "SELECT image FROM cricket WHERE title = '$title'";
			$result = mysqli_query($conn,$query);
			$row = mysqli_fetch_assoc($result);
			return $row['image'];
		}
		// to fetch all data using banner id for edit.
		public function getBannerById($id){
			global $conn;
			$query = "SELECT * FROM banners WHERE id = '$id'";
			$result = mysqli_query($conn,$query);
			$row = mysqli_fetch_assoc($result);
			return $row;
		}
		//to update the banner data through edit.
		public function updateBannerData($id,$userId){
			global $conn;
			$title=$_POST['title'];
			$description = $_POST['description'];
			$buttontext = $_POST['buttontext'];
			$buttonurl = $_POST['buttonurl'];
			$textPosition = $_POST['textPosition'];
			$nwradio = $_POST['nwradio'];
			$bLive = $_POST['bLive'];
			$ip = $_SERVER['REMOTE_ADDR'];
			$imagecheck = $_POST['imageChecked'];
			
			// Checkbox condition for image upload
			if (($imagecheck == '1') && (!empty($_FILES['fileupload']))) {
				include('inc/upload.php');
				$target_file = uploadFile($_FILES['fileupload']);
			}else {
				$query = "SELECT `image` FROM banners WHERE id='$id'";
				$result = mysqli_query($conn, $query);
				$row = mysqli_fetch_assoc($result);
				$target_file = $row['image'];
			}
			$query = "UPDATE banners SET
				`title`='".$title."',
				`description`='".$description."',
				`image`='".$target_file."',
				`button_text`='".$buttontext."',
				`button_url`='".$buttonurl."',
				`text_position`='".$textPosition."',
				`new_window`='".$nwradio."',
				`live`='".$bLive."',
				`ip_address`='".$ip."',
				`modified_by`='".$userId."'
				WHERE id ='$id'";
				$result = mysqli_query($conn,$query);
				return $result;
		  }
			
		   //check live 
		    // public function toggleLiveStatus($id) {
				// global $conn; 
        
         // Fetch current live status
				// $query = "SELECT live FROM banners WHERE id = $id";
				// $result = mysqli_query($conn, $query);
        
				// if ($result && mysqli_num_rows($result) == 1) {
				// $row = mysqli_fetch_assoc($result);
				// $currentStatus = $row['live'];
            
				// // Toggle live status
				// $newStatus = $currentStatus == 1 ? 0 : 1;
            
				// $updateQuery = "UPDATE banners SET live = $newStatus WHERE id = $id";
				// $updateResult = mysqli_query($conn, $updateQuery);
            
				// if ($updateResult) {
					// return $newStatus; // Return new live status
				// } else {
					// return false; // Failed to update status
				// }
				// } else {
				// return false; // Banner not found
				// }	
			// }
			
		// delete the banner item
		public function deleteBannerData($id){
			global $conn;
			$sql = "UPDATE banners SET delete_id = '1' WHERE id = $id";
			$result = mysqli_query($conn,$sql);
			return $result;
		}
	}
?>

