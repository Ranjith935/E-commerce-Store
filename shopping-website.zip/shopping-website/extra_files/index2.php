<?php
	session_start();
?>
<?php
	include('inc/header.php');
	include('lib/banner-class.php');
	$banner = new bannerSection();
	include('lib/products-class.php');
	$product = new productSection();
?>
<!--CATEGORY SECTION -->
<section class="thumnailSection">
<div class="container  text-center ">
  <div class="row">
	<?php
	$category = new categorySection;
	$categoryResult = $category->updateCategorySection();
	if(mysqli_num_rows($categoryResult)>0){
		while($category = mysqli_fetch_assoc($categoryResult)){
			//ABSOLUTE image path using define.php
			$imagePath = UPLOAD_PATH.'categories/'.$category['image'];
	?>
      <div class="thumbnail col">
       	<div class="thumbnailPic">
       		<img src="<?php echo $imagePath; ?>" alt="image" />
       	</div>
       	<div class="thumbnailname">
       		<h5><a href="cricketProducts.php"><?php echo $category['title']; ?></a></h5>
       	</div>
      </div>
	<?php
		}
	}
	?>
  </div>
 </div>
</section>

<!-- BANNER CAROUSEL -->
<section class="carouselSection border border-dark border-1 border-start-0 border-end-0">
<div id="carouselExampleDark" class="carousel carousel-white slide" data-bs-ride="carousel">
       <?php
		$bannerResult = $banner->updateBannerSection();
		if(mysqli_num_rows($bannerResult)>0){
			$i=0;
			$activeButton = 'active';
       ?>
		<div class="carousel-indicators">
          <?php
		     while($bannerRow = mysqli_fetch_assoc($bannerResult)){
          ?>
           <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="<?php echo $i; ?>" class="<?php echo $activeButton; ?>" aria-current="true" aria-label="Slide <?php echo $i+1; ?>"></button>
          <?php
			$i++;
			$activeButton ='';
             }
          ?>
        </div>
       <?php
        }
       ?>
	  
  <div class="carousel-inner" data-bs-interval="3000">
       <?php
			$bannerRes = $banner->updateBannerSection();
			if(mysqli_num_rows($bannerRes)>0){
			$active = 'active';
				while($bannerRow = mysqli_fetch_assoc($bannerRes)){
					$image = 'banners/'.$bannerRow['image'];
					$imagePath = UPLOAD_PATH.$image;
       ?>
           <div class="carousel-item <?php echo $active;?>" data-bs-interval="2000">
            	<img src="<?php echo $imagePath; ?>" class="d-block w-100" alt="..." />
           </div>
     	<?php
     	   $active='';
				}
			}
     	?>
  </div>
 
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</section>

<!--HOME PAGE PRODUCTS-->
<section class="homeProductsSection">
<div class="container">
	<div class="homeProductsHeading">
		<h5 class="fw-bold">Featured Products!</h5>
	</div>
<!-- CRICKET -->
	<div class="homeProductRow row">
	<?php
		$result = $product->updateCricketSection();
		if(mysqli_num_rows($result)>0){
			while($productRow = mysqli_fetch_assoc($result)){
				$image = 'products/'.$productRow['image'];
					$imagePath = UPLOAD_PATH.$image;
	?>
	 <div class="col-6 col-sm-6 col-md-3 col-lg-3">
        <div class="card" style="width:;" data-id="<?php echo $productRow['id'];?>" >
        	<a href=""><img src="<?php echo $imagePath;?>" class="card-img-top" alt="..." /></a>
			<!--https://www.decathlon.in/p/8754325/tennis-cricket-bat-and-balls/t-500-light-adult-blue?id=8754325&type=p-->
        	<div class="card-body">
        		<h5 class="card-title"><?php echo $productRow['title'];?></h5>
        		<p class="fw-bold">Price: ₹ <span class="text-success productPrice"><?php echo $productRow['price'];?> </span></p>
        		<a href="" class="w-100 btn border border-dark border-1">Check Product</a>
        	</div>
        </div>
	 </div>
	 <?php
			}
		}
	 ?>
	 </div>
<!-- FOOTBALL -->
	<div class="homeProductRow row">
	<?php
	$result = $product->updateFootballSection();
		if(mysqli_num_rows($result)>0){
			while($productRow = mysqli_fetch_assoc($result)){
				$image = 'products/'.$productRow['image'];
					$imagePath = UPLOAD_PATH.$image;
	?>
	 <div class="col-6 col-sm-6 col-md-3 col-lg-3">
        <div class="card" style="width:;" data-id="<?php echo $productRow['id'];?>">
        	<a href=""><img src="<?php echo $imagePath; ?>" class="card-img-top" alt="..." /></a>
			<!-- https://www.decathlon.in/p/8619218/footballs/football-club-ball-size-5-fifa-basic-f500-white-yellow?id=8619218&type=p -->
        	<div class="card-body">
        		<h5 class="card-title"><?php echo $productRow['title']; ?></h5>
        		<p class="fw-bold">Price: ₹ <span class="text-success productPrice"><?php echo $productRow['price'];  ?></span></p>
        		<a href="" class="w-100 btn border border-dark border-1">Check Product</a>
        	</div>
        </div>
	 </div>
	 <?php
			}
		}
	 ?>
	 </div>
<!-- BADMINTON -->
	<div class="homeProductRow row">
	<?php
	$result = $product->updateBadmintonSection();
	if(mysqli_num_rows($result)>0){
		while($productRow = mysqli_fetch_assoc($result)){
			$image = 'products/'.$productRow['image'];
			$imagePath = UPLOAD_PATH.$image;
	?>
	<div class="col-6 col-sm-6 col-md-3 col-lg-3">
        <div class="card" style="width:;" data-id="<?php echo $productRow['id'];?>">
        	<a href=""><img src="<?php echo $imagePath; ?>" class="card-img-top" alt="..." /></a>
			<!-- https://www.decathlon.in/p/8515766/outdoor-badminton/adult-badminton-racket-br-100-red?id=8515766&type=p -->
        	<div class="card-body">
        		<h5 class="card-title"><?php echo $productRow['title'];  ?></h5>
        		<p class="fw-bold">Price: ₹ <span class="text-success productPrice"><?php echo $productRow['price']; ?></span></p>
        		<a href="" class="w-100 btn border border-dark border-1">Check Product</a>
        	</div>
        </div>
	 </div>
	<?php
		}
	}
	?>
	</div>
<!-- BASKETBALL -->
	<div class="homeProductRow row">
	<?php
	$result = $product->updateBasketballSection();
	if(mysqli_num_rows($result)>0){
		while($productRow = mysqli_fetch_assoc($result)){
			$image = 'products/'.$productRow['image'];
			$imagePath = UPLOAD_PATH.$image;
	?>
	<div class="col-6 col-sm-6 col-md-3 col-lg-3">
        <div class="card" style="width:;" data-id="<?php echo $productRow['id'];?>">
        	<a href=""><img src="<?php echo $imagePath;  ?>" class="card-img-top" alt="..." /></a>
			<!--  https://www.decathlon.in/p/8734288/basketball-hoops/kids-wall-mounted-basketball-hoop-sk100-dunkers-turquoise-purple?id=8734288&type=p-->
        	<div class="card-body">
        		<h5 class="card-title"><?php echo $productRow['title'];  ?></h5>
        		<p class="fw-bold">Price: ₹ <span class="text-success productPrice"><?php echo $productRow['price']; ?></span></p>
        		<a href="" class="w-100 btn border border-dark border-1">Check Product</a>
        	</div>
        </div>
	 </div>
	<?php
		}
	}
	?>
	</div>
</div>
<script>
 // document.addEventListener("DOMContentLoaded", function(){
	 // const price = document.querySelectorAll('.productPrice');
	 // price.forEach(price =>{
		 // const priceText = price.innerText.toLocaleString();
		 // price.innerHTML = priceText;
	 // });
 // });
</script>
<script>
	document.addEventListener("DOMContentLoaded", function(){
		const title = document.querySelectorAll('.card-title');
		title.forEach(title =>{
			if(title.innerText.length > 36){
				title.innerText = title.innerText.slice(0,36) + '...';
			}
		});
	});
</script>
<script>
// const img = document.querySelectorAll('.card-img-top');
// div.forEach(div => {
   // div.addEventListener('click', function() {
		// const id = this.getAttribute('data-id');
		// window.location.href = "editcategory.php?id="+id;
	// });
// });
</script>
</section>
<?php
  include('inc/footer.php');
?>