<?php
	class productSection {
		public function updateCricketSection() {
			global $conn;
			$sql = "SELECT id,title,image,price
				FROM products WHERE live='1' AND delete_id='0' AND fk_cid IN 
				(SELECT c1.id
				FROM category c1
				JOIN category c2 ON c1.parent_id = c2.id
				WHERE c1.live= '1'
				  AND c1.title='Cricket'
				  AND c1.delete_id ='0'
				  AND c2.parent_id ='0'
				  AND c2.live = '1'
				  AND c2.delete_id='0') LIMIT 4";
				//$sql = "SELECT title,image,price
				//FROM products WHERE live='1' AND delete_id='0' AND fk_cid IN 
				//(SELECT id FROM category WHERE title='Cricket' AND live='1' AND delete_id='0') LIMIT 4";
			$result = mysqli_query($conn, $sql);
			return $result;
		}
		public function updateFootballSection() {
			global $conn;
			$sql = "SELECT id,title, image, price
				FROM  products WHERE live='1' AND delete_id='0' AND fk_cid IN
				(SELECT c1.id 
				FROM category c1
				JOIN category c2 ON c1.parent_id = c2.id
				WHERE c1.live='1'
					AND c1.title='Football'
					AND c1.delete_id='0'
					AND c2.parent_id='0'
					AND c2.live='1'
					AND c2.delete_id='0') LIMIT 4";
			$result = mysqli_query($conn, $sql);
			return $result;
		}
		public function updateBadmintonSection() {
			global $conn;
			$sql ="SELECT id,title, image, price
				FROM products WHERE live='1' AND delete_id='0' AND fk_cid IN
				(SELECT c1.id
				FROM category c1
				JOIN category c2 ON c1.parent_id = c2.id
				WHERE c1.live='1'
					AND c1.title='Badminton'
					AND c1.delete_id='0'
					AND c2.parent_id='0'
					AND c2.live='1'
					AND c2.delete_id='0') LIMIT 4";
			//$sql = "SELECT title, image, price
				//FROM products WHERE fk_cid IN (SELECT id FROM category WHERE title='Badminton') LIMIT 4";
			$result = mysqli_query($conn, $sql);
			return $result;
		}
		public function updateBasketballSection(){
			global $conn;
			$sql ="SELECT id,title, image, price
				FROM products WHERE live='1' AND delete_id='0' AND fk_cid IN
				(SELECT c1.id
				FROM category c1
				JOIN category c2 ON c1.parent_id = c2.id
				WHERE c1.live='1'
					AND c1.title='Basketball'
					AND c1.delete_id='0'
					AND c2.parent_id='0'
					AND c2.live='1'
					AND c2.delete_id='0') LIMIT 4";
			$result = mysqli_query($conn, $sql);
			return $result;
		}
	}
?>