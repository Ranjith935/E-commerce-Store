<?php
	//FOR UPLOAD
	$siteFolder = 'http://localhost:90/shopping-website/';
	define("UPLOAD_PATH",$siteFolder.'uploads/');
	
	//ROOT PATH
	define("ROOT_PATH",$siteFolder);
	
	//FOR CSS
	define("CSS_PATH",$siteFolder.'css/');
	
	//FOR JS
	define("JS_PATH",$siteFolder.'js/');
?>