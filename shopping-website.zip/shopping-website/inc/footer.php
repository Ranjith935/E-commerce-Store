<footer class="footerSection bg-info">
	<div class="container footerContainer">
		<div class="row footerRow">
			<div class="col-3 footerColumn">
				<h5 class="footerHeading fw-bold">ABOUT <i>SportsGearHub</i></h5>
				<p>SportsGearHub assures you the fastest, safest, and most reliable method possible for sending your products. We deliver to all serviceable pin code locations within the geographical boundary of India. In most cases, your order will be sent to our delivery partner.</p>
			</div>
			<div class="col-3 footerColumn">
				<h5 class="footerHeading fw-bold">COMPANY</h5>
				<p>Who we are</p>
				<p>Careers</p>
				<p>Services</p>
				<p>Get in touch</p>
			</div>
			<div class="col-3 footerColumn">
				<h5 class="footerHeading fw-bold">HELP & FAQs</h5>
				<p>Online Ordering</p>
				<p>Shipping Service</p>
				<p>Billing Rules</p>
				<p>International shipments</p>
			</div>
			<div class="col-3 footerColumn">
				<h5 class="footerHeading fw-bold">ADDRESS</h5>
				<p><i class="fa-solid fa-phone"></i> Phone: +1 (0) 000 0000 001</p>
				<p><i class="fa fa-envelope checked"></i> Email: yourmail@example.com</p>
				<p><i class="fa fa-location-dot"></i> Address: 1234 Street Name City, AA 99999, LA 3rd buliding.</p>
				<div class="socialMedia">
					<i class="fa fa-facebook"></i>
					<i class="fa fa-twitter"></i>
					<i class="fa-brands fa-linkedin"></i>
					<i class="fa fa-instagram"></i>
				</div>
			</div>
		</div>
	 </div>
	 <div class="row bg-white lastRow text-center">
		<p>@ 2024 All Rights Reserved. By SportGearHub Wordpress Templates By DesignTM</p>
	</div>
</footer>