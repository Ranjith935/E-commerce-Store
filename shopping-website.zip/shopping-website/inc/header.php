<?php
	include('lib/connection.php');
?>
<?php
	include('inc/defines.php');
	include('lib/category-class.php');
	$category = new categorySection(); 
	include('lib/login-class.php');
	$log = new Login();
?>
<?php
//Retrieving firstname using ID(to display in the home page)
	$id = isset($_GET['id']) ? $_GET['id'] : null;
	$logindata = null;
	if($id){
		$logindata = $log->queryFirstName($id);
		$firstName = $logindata;
	}
?>
<head>
 <title>SPORTS-SHOP WEBSITE</title>
 <meta name="description" content="It is a Sports-Gear shopping website, which contains all premium products!">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<link rel="stylesheet" href="<?php echo CSS_PATH;?>bootstrap.min.css">
	<!--First all.min then font-awesome.min(Otherwise it will override)-->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
	
	<link rel="stylesheet" href="<?php echo CSS_PATH;?>style.css" />
	<script type="text/javascript" src="<?php echo JS_PATH; ?>bootstrap.bundle.min.js"> </script>
	<script type="text/javascript" src="<?php echo JS_PATH; ?>jquery-2.1.3.min.js"> </script>
</head>

<header class="headerSection sticky-top">
<?php //echo $_SESSION['cms_username']; ?>
<nav class="mainNavbar navbar container-fluid bg-info">

	<nav class="firstnav navbar navbar-expand-lg bg-info text-white">
		<div class="container">
			<a class="navbar-brand fw-bold" href="" ><i>SportsGearHub</i></a>
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent" aria-controls="navbarContent" aria-expanded="false">
				<span class="navbar-toggler-icon"></span>
			</button>

			<div class="collapse navbar-collapse " id="navbarContent">
			<div class="searchBar mt-4 ps-0">
				<form class="d-flex" role="search">
				<input class="form-control" type="search" placeholder="Search for Gears..." aria-label="Search">
					<button class="btn btn-outline-dark" type="submit">Search</button>
				</form>
			</div>
				<ul class="navbar-nav">
					<li class="nav-item">
					
					<?php 
						if (isset($_SESSION['loggedin']) && $_SESSION['loggedin']){
					?>
						<a class="text-start fw-bold text-dark nav-link ps-4" style="pointer-events:none;" href="">WELCOME <?php echo $firstName; ?>!</a>
					<?php
						}else{
					?>
						<a class="fw-bold text-dark nav-link ps-4" href="<?php echo ROOT_PATH;?>login.htm">LOGIN <i class="fa-solid fa-user"></i></a>
					<?php
						}
					?>
					</li>
					<li class="nav-item">
						<a class="fw-bold text-dark nav-link ps-4" href="">CART <i class="fa-solid fa-cart-shopping"></i></a>
					</li>
				</ul>
			</div>
		</div>
	</nav>
	<nav class="secondnav navbar">
				<button class="btn fw-bold text-dark" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample" aria-controls="offcanvasExample">
						MENU <span class="menuIcon navbar-toggler-icon"></span>
				</button>
					<div class="offcanvas offcanvas-end bg-info" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
						<div class="offcanvas-header">
							<h5 class="offcanvas-title fw-bold" id="offcanvasExampleLabel"><u>Menu List</u></h5>
							<button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
						</div>
						 <div class="offcanvas-body">
							<div class="dropdown mt-3" style="text-transform:uppercase;">
								<button class="w-75 btn btn-secondary dropdown-toggle text-start" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
									<i class="fa-solid fa-layer-group"></i> CATEGORIES
								</button>
								<ul class="dropdown-menu bg-warning w-50" aria-labelledby="dropdownMenuButton">
								<?php
                                 $mainCategory= $category->updateCategoryMenu();
                                 if(mysqli_num_rows($mainCategory)>0){
                                	 while($mainrow = mysqli_fetch_assoc($mainCategory)){
	                            ?>
                                   <li class="nav-item dropdown dropend">
                                       <a class="dropdown-item dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" onclick="event.stopPropagation();"><i class="<?php echo $mainrow['font_class']; ?>"></i>  <?php echo $mainrow['title'];  ?></a>
                                       <ul class="dropdown-menu bg-warning">
											<?php
											  $subCategory = $category->updateCategorySection();
											  if(mysqli_num_rows($subCategory)>0){
											  while($subrow = mysqli_fetch_assoc($subCategory)){
													if($subrow['parent_id']==$mainrow['id']){
											?>
												<li><a class="dropdown-item" href="#"><i class="<?php echo $subrow['font_class']; ?>"></i>  <?php echo $subrow['title'];  ?></a></li>
										    <?php
													}
											  }
											 }
											?>
                                       </ul>
                                   </li>
								<?php
									 }
								 }
								?>
                               </ul>
							</div>
							<div class="dropdown mt-3">
								<button class="w-75 btn btn-secondary dropdown-toggle text-start" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown">
									<i class="fas fa-user mx-1"></i> PROFILE
								</button>
								<ul class="dropdown-menu bg-warning w-75" aria-labelledby="dropdownMenuButton">
									<!--<li><a class="dropdown-item" href="#"><i class="fa-solid fa-id-card-clip"></i>  My account</a></li> -->
									<li><a class="dropdown-item" href="#"><i class="fa-solid fa-box-open"></i>  Orders</a></li>
									<li><a class="dropdown-item" href="#"><i class="fa-solid fa-address-book"></i>  Address</a></li>
									<li><a class="dropdown-item" name="logout" href="<?php echo ROOT_PATH;?>logout.php"><i class="fa-solid fa-right-from-bracket"></i>  Log out</a></li>
								</ul>
							</div>
						</div>
					</div>
	</nav>
</nav>
</header>
