
<?php 
	session_start();
	if(isset($_SESSION['cms_loggedin'])){
		header("Location: home.php");
	}
?>
<?php 
	include('inc/header.php');
	include('lib/login-class.php');
	$login = new Login;
	$message='';
?>

<?php
$email=$pass="";
$emailError=$passwordError="";

if(isset($_POST['login'])){
	$email = $_POST['loginEmail'];
	$pass = $_POST['loginPassword'];
	
	if(empty($email)){
		$emailError = 'Enter your Email Address!';
	}
	if(empty($pass)){
		$passwordError = 'Enter your Password!';
	}
	
	if(empty($emailError) && empty($passwordError)){
		 $result = $login->checkLoginData($email,$pass);
		 if($result === "successful"){
			 $sql = "SELECT id FROM cms_users where email = '$email'";
			 $queryResult = mysqli_query($conn, $sql);
            if($queryResult && mysqli_num_rows($queryResult) > 0){
               $row = mysqli_fetch_assoc($queryResult);
			 $_SESSION['cms_user_id'] = $row['id'];
			 $id = $_SESSION['cms_user_id'];
			 $_SESSION['cms_username']= $email;
			 $_SESSION['cms_loggedin'] = true;
			 echo"<script>
				 window.location.href='home.php?id=$id';
				</script>";
		 }else if($result === "failed"){
			 $message = 'Credentials didn\'t match!';
		 }
	}
}
}
?>
<!--ALERT BOX FOR LOGIN MISMATCH -->
<?php if($message): ?>
    <div class="d-flex justify-content-center">
        <div class="alert text-center w-25 alert-warning alert-dismissible fade show mt-3 mb-0" role="alert">
            <strong class="text-secondary"><?php echo $message; ?></strong> 
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    </div>
<?php endif; ?>

<section class="loginPage">
  <div class="container loginContainer">
    <div class="row justify-content-center align-items-center">
        <div class="card bg-secondary text-white">
          <div class="card-body">
              <h2 class="fw-bold text-center">LOGIN</h2>
              <p class="text-white-50 text-center mb-5">Please enter your Email and Password!</p>
			<form name="form" action="" onsubmit="return isvalid()" method="POST">
              <div class="form-outline form-white mb-4">
                <label class="form-label" for="loginEmail">Email</label>
				<input type="email" id="loginEmail" name="loginEmail" class="form-control form-control" />
				<span id="emailError" style="color:red;font-size:13px;padding-left:15px;"><?php echo $emailError; ?></span><br>
				
                <label class="form-label" for="loginPassword">Password</label><br>
				<input type="password" id="loginPassword" name="loginPassword" class="form-control form-control" />
				<span id="passwordError" style="color:red;font-size:13px;padding-left:15px;"><?php echo $passwordError; ?></span><br>
				<span style="float:right;font-size:14px;">Show Password <input style="width:30px; height:20px;margin-top:15px;" type="checkbox" onclick="myFunction()"> </span>
              </div>
				<div class="text-center mt-5">
					<button class="btn btn-outline-light btn-lg" type="submit" name="login" id="login">Login</button>
					<div>
						<p class="mb-0">Don't have an account? <a href="register.php" class="text-white-50 fw-bold">Sign Up</a></p>
					</div>
				</div>
			</form>
          </div>
        </div>
    </div>
  </div>
</section>

<?php 
	include('inc/footer.php');
?>
