<?php  
	session_start(); 
	if(!isset($_SESSION['loggedin'])){
		header("Location: login.php");
		exit();
	}
	include('lib/connection.php');
	include('lib/products-class.php');
	$product = new Product();
	$updateMessage = isset($_GET['message']) ? $_GET['message'] : null;
?>
<!DOCTYPE html>
<html>
<body>
<!-- PAGE NAVBAR SECTION --> 
<?php
	include 'inc/header.php' ;
?>

<section class="cmsBSection">
<div class="container bg-secondary">
	<div class="cmsContainer">
		<h4 class="fw-bold text-white text-center">Products List</h4>
		<button id="addButton" class="addButton btn bg-danger text-white fw-bold">ADD</button>
		<script>
			document.getElementById('addButton').addEventListener('click',function(){
				window.location.href = '<?php echo ROOT_PATH;?>addproducts.php';
			});
		</script>
		<?php if($updateMessage): ?>
           	<div class="d-flex justify-content-center">
                <div id="topAlert" class="alert w-75 alert-secondary alert-dismissible fade show" role="alert">
                    <strong class="text-success">Success!</strong> <?php echo $updateMessage; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
				<script>
				<!--to remove the message in urL -->
			        const url = new URL(window.location);
					url.searchParams.delete('message');
					window.history.replaceState(null,null,url);
				</script>
				<script>
				<!-- Timeout for AlertBox -->
					setTimeout(()=>{
						document.getElementById("topAlert").remove();
					},2000);
				</script>
           </div>
		 
		<?php endif; ?>
			<table id="myTable" class="cmsBTable bg-white">
			<thead>
				<tr class="bg-black text-white">
					<th>Actions</th>
					<th>Title</th>
					<th class="w-25">Description</th>
					<th>Category</th>
				</tr>
			</thead>
			<tbody class="sort">
				   <?php
					$result = $product->selectProductData();
					if(mysqli_num_rows($result) > 0){
					  while($row= mysqli_fetch_assoc($result)){
						$image = $product->showImage($row['id']);
						$imagePath = UPLOAD_PATH.'products/'.$image;
				   ?>
						<tr>
						  <td class="w-25">
								<div class="d-flex justify-content-center">
									<button class="imageBtn btn hover-text p-0">
										<img src="<?php echo $imagePath; ?>" class="border border-dark" alt="" width="30"  />
										<span class="tooltip-text" id="right">
											<img src="<?php echo $imagePath; ?>" alt="Image" width="160" />
										</span>
									</button>
									<button class="livebtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Live" data-id="<?php echo $row['id']; ?>" >
										<i class="fa-regular <?php if($row['live'] == 1){ echo 'fa-eye'; }else{ echo 'fa-eye-slash';} ?>"></i>
									</button>
									<button class="editbtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit" data-id="<?php echo $row['id']; ?>">
										<i class="fa-regular fa-pen-to-square"></i>
									</button>
									<button class="deletebtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete" data-id="<?php echo $row['id']; ?>">
										<i class="fa-solid fa-trash"></i>
									</button>
								</div>
						 </td>
						 <td class="w-25">
							<a class="editWithTitle text-dark" href="editproducts.php?id=<?php echo $row['id']; ?>" >
								<?php echo $row['title']; ?>
							</a>
						 </td>
						 <td class="w-75"><?php echo $row['description']; ?></td>
						 <td>
				        	 <!--to get the main category name using cid-->
				        	<?php
				        	  $mainCategory = $product->productMainCategory($row['id']);
				        		foreach($mainCategory as $category){
				        	?>
				        	<?php echo $category; ?><br>
				        	<?php
				        		}
				        	?>
						 </td>
						</tr>
						
					<?php
					  }
					}else {
					?>
                    <tr><td colspan="4">No data inserted.</td></tr>
					<?php
				    	}
				    ?>
			</tbody>
		</table>
		<input type="button" value="ADD" class="addButton2 btn bg-danger text-white fw-bold" onclick="location.href='<?php echo ROOT_PATH;?>addproducts.php'"/>
	</div>
  </div>
</section>

<script>
<!--Edit-->
document.querySelectorAll('.editbtn').forEach(button => {
   button.addEventListener('click', function() {
		const id = this.getAttribute('data-id');
		window.location.href = "editproducts.php?id="+id;
	});
});
<!--Live toggle-->
document.querySelectorAll('.livebtn').forEach(button => {
  button.addEventListener('click', function() {
    const id = this.getAttribute('data-id');
	const button = this;
	$.ajax({
		type: 'POST',
		url: 'toggleliveproducts.php',
		data: {id:id},
		dataType: 'json',
		success: function(response) {
			if (response.live == 1) {
				alertMessage =' Product is live';
				addAlert(alertMessage);
				button.querySelector('i').classList.remove('fa-eye-slash');
				button.querySelector('i').classList.add('fa-eye');
			} else {
				alertMessage =' Product is un-live'; 
				addAlert(alertMessage);
				button.querySelector('i').classList.remove('fa-eye');
				button.querySelector('i').classList.add('fa-eye-slash');
			}
		},
		error: function(xhr,status,error) {
			console.error(xhr.responseText);
		}
		});
	});
});
<!--live function to show alert box-->
function addAlert(message){
	const existingAlert = document.getElementById("liveAlert");
	if(existingAlert){
		existingAlert.remove();
	}
    let alert =
			'<div id="liveAlert" class="alert w-75 alert-secondary alert-dismissible fade show" role="alert">' +
            '<strong class="text-success">Success!</strong>' + message + '.' +
            '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>' +
			'</div>';
    const mytable = document.querySelector('.cmsBTable');
    mytable.insertAdjacentHTML('beforebegin', alert);
	<!-- Timeout to remove the AlertBoxx-->
	setTimeout(() => {
		document.getElementById("liveAlert").remove();
	},4000)
}
<!--Delete-->
document.querySelectorAll('.deletebtn').forEach(button => {
	button.addEventListener('click', function() {
		const id= this.getAttribute('data-id');
		if(confirm('Confirm to delete?')){
			window.location.href = "deleteproduct.php?id="+id;
		}
	});
});
<!--Change live button status onn hover -->
document.querySelectorAll('.livebtn').forEach(button => {
	button.addEventListener('mouseover',function() {
		const id = this.getAttribute('data-id');
		const button = this;
		$.ajax({
			type:'POST',
			url: 'getliveProduct.php',
			data :{id},
			dataType: 'json',
			success: function(response){
				if(response.live=='1'){
					const liveStatus = 'Live';
					button.setAttribute('title', liveStatus);
				}else if(response.live == '0'){
					const liveStatus ='Un-live';
					button.setAttribute('title', liveStatus);
				}
			},
			error: function(xhr,status,error) {
				console.error(xhr.responseText);
			}
		});
	});		
});
</script>
<script>
	// var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
	// var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
		// return new bootstrap.Tooltip(tooltipTriggerEl)
	// })
</script>
<?php 
	include('inc/footer.php');
?>
</body>
</html>