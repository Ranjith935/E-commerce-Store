<?php
session_start();
if(!isset($_SESSION['loggedin'])){
    header("Location: login.php");
    exit();
}
include('lib/connection.php');
include('lib/category-class.php');
$category = new Category();

if(isset($_POST['id'])){
    $id = $_POST['id'];
    $result = $category->getCategoryById($id);
    if($result){
        $live = $result['live'];
        echo json_encode(['live' => $live]);
    } else {
        echo json_encode(['error' => 'Category not found']);
    }
}
?>