<?php  
	session_start(); 
	if(!isset($_SESSION['loggedin'])){
		header("Location: login.php");
		exit();
	}

 include('lib/connection.php');
 include_once('inc/defines.php');
 include('lib/category-class.php');
 $category = new Category();
 $message ='';

 // checking id
 $id = isset($_GET['id']) ? $_GET['id'] : null;
 $categoryData = null;

 if($id){
	$categoryData = $category->getCategoryById($id);
	// Retrieving the image using ABSOLUTE-PATH
	$imagePath = UPLOAD_PATH.'categories/'.$categoryData['image'];
 }
 //update the data
 if(isset($_POST['updateBannerData'])){
	 
	$username = $_SESSION['cms_username'];
	$sql= "SELECT id FROM cms_users where email ='$username'";
	$res = mysqli_query($conn,$sql);
	$user = mysqli_fetch_assoc($res);
	$userId = $user['id'];
	
	$title=$_POST['title'];
	$description = $_POST['description']; 
	
	if(empty($title)){ 
		echo"<script>
		alert('Specify the Title');
		window.location.href='editcategory.php?id=$id';
		</script>";
		exit();
	}
	if(empty($description)){
		echo"<script>
		alert('Specify the Description');
		window.location.href='editcategory.php?id=$id';
		</script>";
		exit();
	}
	$result = $category->updateCategoryData($id,$userId);
	if($result){
		$message=' Category Updated Successfully!';
			echo "<script>
			window.location.href='category.php?message=$message';
			</script>";
	}
	else{
		$message = 'Failed to Update Category';
			echo"<script>
				window.location.href='category.php?message=$message';
				</script>";
		}
 }
?>

<!DOCTYPE html>
<html>
<body>
<!-- PAGE NAVBAR SECTION --> 
<?php
	include('inc/header.php') ;
?>
<section class="cmcASection">
<div class="container bg-secondary text-white">
	<div class="cmsContainer">
	<h4 class="fw-bold mb-4 text-center">Edit Category</h4>
		<form class="addFrom" method="post" action="" enctype="multipart/form-data" >
			<div class="form-group row mb-3">
				<label for="mainCategory" class="col-sm-3 form-label fw-bold text-end">Category:</label>
				<div class="col-sm-8">
					<select class="text-center w-50 p-1" name="mainC" style="-moz-appearance: none;">
					<?php
						$mainC = $category->getMainCategoryByParentId($categoryData['parent_id']);
					?>
						<option value="<?php echo $categoryData['parent_id']; ?>"><?php echo $mainC['title']; ?></option>
					</select>
				</div>
			</div>
			<div class="form-group row mb-3">
				<label for="title" class="col-sm-3 form-label fw-bold text-end">Title:</label>
				<div class="col-sm-8">
					<input type="text" class="form-control" id="title" name="title" value="<?php echo $categoryData['title'] ?>">
				</div>
			</div>
			<div class="form-group row mb-3">
				<label for="description" class="col-sm-3 form-label fw-bold text-end">Description:</label>
				<div class="col-sm-8">
					<textarea class="form-control" id="description" name="description" rows="5"><?php echo $categoryData['description'] ?></textarea>
				</div>
			</div>
			<div class="form-group row mb-3">
				<label for="image" class="col-sm-3 form-label fw-bold text-end">Image:</label>
				<div class="displayImage w-25">
					<img src="<?php echo $imagePath;?>" width="250" >
				</div>
			</div>
			<div class="form-group row mb-3">
				<label for="fileupload" class="col-sm-3 form-label fw-bold text-end">Upload Image:</label>
				<div class="col-sm-4">
					<input type="file" class="form-control" id="fileupload" name="fileupload">
				</div>
				<div class="col-sm-2">
					<input type="text"  class="form-control  bg-secondary text-white" width="40px" value="File size <= 5 MB" disabled>
				</div>
			</div>
			<div class="form-group row mb-3">
				<label for="" class="col-sm-3 form-label fw-bold text-end"></label>
				<div class="col-sm-3">
					<div class="form-check">
						<input class="form-check-input" type="checkbox" value="1" id="imageChecked" name="imageChecked" />
							<label class="form-check-label" for="imageChecked">
								Confirm to update image
							</label>
					</div>
				</div>
			</div>
			<div class="form-group row mb-3">
				<label for="title" class="col-sm-3 form-label fw-bold text-end">Font-Class:</label>
				<div class="col-sm-8 w-50">
					<input type="text" class="form-control" id="fontclass" name="fontclass" value="<?php echo $categoryData['font_class']; ?>" >
				</div>
			</div>
			<div class="form-group row mb-3">
				<label for="bLiveyes" class="col-sm-3 form-label fw-bold text-end">Category is Live:</label>
				<div class="col-sm-1">
					<input class="form-check-input" type="radio" name="bLive" id="bLiveyes" value="1" <?php echo isset($categoryData['live']) && $categoryData['live']=='1' ? 'checked' : ''; ?> >
					<label class="form-check-label" for="bLiveoyes">Yes</label>
				</div>
				<div class="col-sm-1">
					<input class="form-check-input" type="radio" name="bLive" id="bLiveno" value="0" <?php echo isset($categoryData['live']) && $categoryData['live'] == '0' ? 'checked' : ''; ?> >
					<label class="form-check-label" for="bLiveno">No</label>
				</div>
			</div>
			<input type="button" value="Back" id="prevPage" class="prevPage btn bg-danger text-white fw-bold " onclick="location.href='<?php echo ROOT_PATH; ?>category.php'"/>
			<input type="submit" value="Update" id="updateBannerData" name="updateBannerData" class="updateBannerData btn bg-danger text-white fw-bold"/>
		<!--<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>-->
    
<div>
<?php
    if($categoryData['parent_id'] == 0) {
?>
    <table class="cmsBTable bg-white mt-2">
        <thead>
			<tr class="text-dark">
				<th colspan="3">Sub-categories of <?php echo $categoryData['title']; ?></th>
			</tr>
            <tr class="bg-black text-white">
                <th>Actions</th>
                <th>Title</th>
                <th class="w-75">Description</th>
            </tr>
        </thead>
        <tbody class="sortCategory">
            <?php
                $subCategory = $category->selectCategoryData();
                if(mysqli_num_rows($subCategory) > 0) {
                    while($subrow = mysqli_fetch_assoc($subCategory)) {
                        if($subrow['parent_id'] == $id) {
                            $subCategoryImage = $category->showImage($subrow['id']);
                            $subImagePath = UPLOAD_PATH.'categories/'.$subCategoryImage;
            ?>
            <tr class="text-dark" data-id="<?php echo $subrow['id']; ?>">
                <td>
                    <div class="d-flex ms-4">
                        <button class="btn" style="border:none;" disabled>
                            <i class="fa-solid fa-arrow-right-long text-center"></i>
                        </button>
                        <button class="imageBtn btn hover-text p-0">
                            <img src="<?php echo $subImagePath; ?>" class="border border-dark" alt="" width="30" />
                            <span class="tooltip-text" id="right">
                                <img src="<?php echo $subImagePath; ?>" alt="Image" width="170" />
                            </span>
                        </button>
						<a href="editcategory.php?id=<?php echo $subrow['id']; ?>" class="btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
							<i class="fa-regular fa-pen-to-square"></i>
						</a>
                    </div>
                </td>
				<td class="w-25 text-dark">
					<a class="editWithTitle text-dark" href="editcategory.php?id=<?php echo $subrow['id']; ?>" >
					<?php echo $subrow['title']; ?>
					</a>
				</td>
                <td class="w-50"><?php echo $subrow['description']; ?></td>
            </tr>
            <?php
                        }
                    }
                } else{
            ?>
            <tr class="text-dark"><td colspan="3">No data inserted.</td></tr>
            <?php
                }
            ?>
        </tbody>
    </table>
    <?php
		}
    ?>
	<!-- For subcategory Products -->
	<?php
        if($categoryData['parent_id'] != 0) {
    ?>
    <table class="cmsBTable bg-white mt-2">
        <thead>
			<tr class="text-dark">
				<th colspan="3">Products of <?php echo $categoryData['title']; ?></th>
			</tr>
            <tr class="bg-black text-white">
                <th>Actions</th>
                <th>Title</th>
                <th class="w-75">Description</th>
            </tr>
        </thead>
        <tbody class="sortProducts">
            <?php
                $products = $category->getProductsForCategory($id);
                if(mysqli_num_rows($products) > 0) {
                    while($productRow = mysqli_fetch_assoc($products)) {
                        //if($productRow['cat_id'] == $id) {
                            $productCategoryImage = $category->showProductImage($productRow['id']);
                            $productImagePath = UPLOAD_PATH.'products/'.$productCategoryImage;
            ?>
            <tr class="text-dark" data-id="<?php echo $productRow['id']; ?>">
                <td>
                    <div class="d-flex ms-4">
                        <button class="btn" style="border:none;" disabled>
                            <i class="fa-solid fa-arrow-right-long text-center"></i>
                        </button>
                        <button class="imageBtn btn hover-text p-0">
                            <img src="<?php echo $productImagePath; ?>" class="border border-dark" alt="" width="30" />
                            <span class="tooltip-text" id="right">
                                <img src="<?php echo $productImagePath; ?>" alt="Image" width="170" />
                            </span>
                        </button>
						<a href="editproducts.php?id=<?php echo $productRow['id']; ?>" class="btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
							<i class="fa-regular fa-pen-to-square"></i>
						</a>
                    </div>
                </td>
				<td class="w-25">
					<a class="editWithTitle text-dark" href="editproducts.php?id=<?php echo $productRow['id']; ?>">
					<?php echo $productRow['title']; ?>
					</a>
				</td>
                <td class="w-50"><?php echo $productRow['description']; ?></td>
            </tr>
            <?php
                    }
                } else{
            ?>
            <tr class="text-dark"><td colspan="3">No data inserted.</td></tr>
            <?php
                }
            ?>
        </tbody>
    </table>
    <?php
        }
    ?>
    </div>
	</form>
	</div>
  </div>
</section>

<script src="https://code.jquery.com/ui/1.13.3/jquery-ui.js"></script>
<script>
<!-- Sort for categories -->
$(function() {
	$('.sortCategory').sortable({
		update: function(event, ui) {
			var order = $(this).sortable('toArray', {attribute: 'data-id'});
			$.ajax({
				url: 'update-category-sort-order.php',
				method: 'POST',
				data: {order},
				success: function(response) {
					var mesg = ' Order Updated!';
					alertBox(mesg);
				}
			});
		}
	});
});
<!-- Sort for products -->
$(function() {
	$('.sortProducts').sortable({
		update: function(event,ui){
			var order= $(this).sortable('toArray', { attribute: 'data-id'});
			$.ajax({
				url: 'update-products-sort-order.php',
				method: 'POST',
				data:{order},
				success: function(response){
					var msg = ' Order Updated!';
					alertBox(msg);
				}
			});
		}
	});
});
<!-- Alertbox for Sorting -->
function alertBox(message) {
	const existingAlert = document.getElementById("liveAlert");
	if (existingAlert) {
		existingAlert.remove();
	}
	let alert =
		'<div id="liveAlert" class="alert w-25 alert-secondary alert-dismissible fade show mt-3" role="alert">' +
		'<strong class="text-success">Success!</strong> ' + message +
		'<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>' +
		'</div>';
	const table = document.querySelector('.cmsBTable');
	table.insertAdjacentHTML('beforebegin', alert);
	
	setTimeout(() => {
		document.getElementById("liveAlert").remove();
	}, 1000);
}
</script>
<?php
	include('inc/footer.php');
?>
</body>
</html>
