<?php
	session_start();
	if (!isset($_SESSION['loggedin'])) {
		header("Location: login.php");
		exit();
	}
	include('lib/connection.php');
	
	$username = $_SESSION['cms_username'];
	$sql= "SELECT id FROM cms_users where email ='$username'";
	$res = mysqli_query($conn,$sql);
	$user = mysqli_fetch_assoc($res);
	$userId = $user['id'];
	
include('lib/category-class.php');
 $category = new Category();

// checking id
 $id = isset($_GET['id']) ? $_GET['id'] : null;
 $result = null;

 if($id){
	$result = $category->deleteCategoryData($id,$userId);
	// id delete_id is 1(One)
	if($result=='1'){
		echo "<script>
		alert('Category Deleted Successfully.');
		window.location.href='category.php';
		</script>";
	}
 }
?>