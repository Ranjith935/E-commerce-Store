<?php 
	include('inc/header.php');
	include('lib/register-class.php');
	$register = new Register;
	$message='';
?>
<!--REGISTER -->
<?php
	$fname = $lname = $pnumber = $email = $password = $confirmPassword = "";
	$fnameError = $lnameError = $phoneError = $emailError = $passwordError = $confirmPasswordError = "";
	
if(isset($_POST['register'])){
	
	$fname = $_POST['registerFName'];
	$lname = $_POST['registerLName'];
	$pnumber = $_POST['registerNumber'];
	$email = $_POST['registerEmail'];
	$password = $_POST['registerPassword'];
	$confirmPassword = $_POST['registerConfirmPassword'];
	
	if(empty($fname)){
		$fnameError = 'Enter your First Name';
	}
	if(empty($lname)){
		$lnameError = 'Enter your Last Name';
	}
	if(empty($pnumber)){
		$phoneError = 'Enter your Phone Number';
	}
	if(empty($email)){
		$emailError = 'Enter your Email';
	}
	if(empty($password)){
		$passwordError = 'Enter your Password';
	}
	if(empty($confirmPassword)){
		$confirmPasswordError = 'Confirm your Password';
	}
	if($password !== $confirmPassword){
		$confirmPasswordError = 'Passwords do not match';
	}
	
	if(empty($fnameError) && empty($lnameError) && empty($phoneError) && empty($emailError) && empty($passwordError) && empty($confirmPasswordError)){
		$result = $register->checkRegister($fname, $lname, $pnumber, $email, $password);
		if($result === "successful") {
			$fname = $lname = $pnumber = $email = $password = $confirmPassword = "";
			$message = 'Registration Successful!';
		}else if($result === "failed"){
			$message = 'User already exists!';
		}
	}
}
?>
<!--ALERT BOX FOR REGISTER PAGE -->
<?php if($message):?>
    <div class="d-flex justify-content-center">
        <div class="alert text-center w-25 alert-warning alert-dismissible fade show mt-3 mb-0" role="alert">
            <strong class="text-secondary"><?php echo $message; ?></strong> 
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    </div>
<?php endif; ?>

<section class="registerPage">
  <div class="container registerContainer">
    <div class="row justify-content-center align-items-center">
        <div class="card bg-secondary text-white">
            <h2 class="fw-bold text-center">REGISTER</h2>
            <p class="text-white-50 text-center mb-4">Please create an Account!</p>
	        <form name="form" action="" method="POST" onsubmit="return isvalid()">
                      <div class="row">
                        <div class="col col-md-6 col-lg-6">
							<label class="form-label" for="registerFName">Firstname</label>
							<input type="text" id="registerFName" name="registerFName" class="form-control" placeholder="Enter your First name" />
							<span id="fnameError" style="color:red;font-size:13px;padding-left:15px;"><?php echo $fnameError; ?></span>
                        </div>
                        <div class="col col-md-6 col-lg-6">
							<label class="form-label" for="registerLName">Lastname</label>
							<input type="text" id="registerLName" name="registerLName" class="form-control" placeholder="Enter your Last name" />
							<span id="lnameError" style="color:red;font-size:13px;padding-left:15px;"><?php echo $lnameError; ?></span>
                        </div>
                      </div>
	        		  <div class="row">
	        			<div class="col col-md-6 col-lg-6">
	        				<label class="form-label" for="registerNumber">Phone Number</label>
	        				<input type="text" id="registerNumber" name ="registerNumber" class="form-control" placeholder="Enter your Phone Number"/>
	        				<span id="phoneError" style="color:red;font-size:13px;padding-left:15px;"><?php echo $phoneError; ?></span>
	        			</div>
	        		  </div>
	        		  <div class="row">
	        			<div class="col col-md-6 col-lg-6">
	        				<label class="form-label" for="registerEmail">Email</label>
	        				<input type="email" id="registerEmail" name ="registerEmail" class="form-control" placeholder="Enter your Email"/>
	        				<span id="emailError" style="color:red;font-size:13px;padding-left:15px;"><?php echo $emailError; ?></span>
	        			</div>
	        		  </div>
	        		  <div class="row">
	        			<div class="col col-md-6 col-lg-6">
	        				<label class="form-label" for="registerPassword">Password</label>
	        				<input type="password" id="registerPassword" name="registerPassword" class="form-control form-control" placeholder="Enter your Password"/>
	        				<span id="passwordError" style="color:red;font-size:13px;padding-left:15px;"><?php echo $passwordError; ?></span>
	        			</div>
	        			<div class="col col-md-6 col-lg-6">
	        				<label class="form-label" for="registerConfirmPassword">Confirm Password</label>
	        				<input type="password" id="registerConfirmPassword" name="registerConfirmPassword" class="form-control form-control" placeholder="Confirm your Password"/>
	        				<span id="confirmPasswordError" style="color:red;font-size:13px;padding-left:15px;"><?php echo $confirmPasswordError; ?></span>
	        			</div>
	        			<span style="font-size:14px;"><input style="width:30px; height:20px;" type="checkbox" onclick="myFunction()">Show Password </span>
	        		  </div>
	        		  <div class="text-center">
							<button class="btn btn-outline-light btn-lg" type="submit" name="register" id="register">Register</button>
							<div>
								<p class="mb-0">Already have an account? <a href="login.php" class="text-white-50 fw-bold">Login</a></p>
							</div>
	        		  </div>
	        </form>
        </div>
    </div>
  </div>
		<script>
			function myFunction() {
					var x = document.getElementById("registerPassword");
					var y = document.getElementById("registerConfirmPassword");
					if ((x.type === "password") &&(y.type === "password")) {
						x.type = "text";
						y.type = "text";
					}else {
						y.type = "password";
						x.type = "password";
					}
			}

			function isvalid(){
				var fname = document.getElementById("registerFName").value;
				var lname = document.getElementById("registerLName").value;
				var pnumber = document.getElementById("registerNumber").value;
				var email = document.getElementById("registerEmail").value;
				var pass = document.getElementById("registerPassword").value;
				var rpass = document.getElementById("registerConfirmPassword").value;
				
				var fnameError = document.getElementById("fnameError");
				var lnameError = document.getElementById("lnameError");
				var phoneError = document.getElementById("phoneError");
				var emailError = document.getElementById("emailError");
				var passwordError = document.getElementById("passwordError");
				var confirmPasswordError = document.getElementById("confirmPasswordError");
				var pattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
				
				var valid = true;
				
				if(fname.length ==""){
					fnameError.innerHTML ='Enter your First name';
					valid = false;
				}else{
					document.getElementById("registerFName").innerHTML = fname;
					fnameError.innerHTML='';
				}
				if(lname.length ==""){
					lnameError.innerHTML ='Enter your last name';
					valid = false;
				}else{
					document.getElementById("registerLName").innerHTML = lname;
					lnameError.innerHTML = '';
				}
				if(pnumber.length == ""){
					phoneError.innerHTML ='Enter your Phone Number';
					valid = false;
				}else{
					phoneError.innerHTML = '';
				}
				if(email.length ==""){
					emailError.innerHTML ='Enter your Email';
					valid = false;
				}else{
					emailError.innerHTML = '';
				}
				if(pass.length ==""){
					passwordError.innerHTML ='Enter your Password';
					valid = false;
				}else{
					passwordError.innerHTML='';
				}
				if(rpass.length ==""){
					confirmPasswordError.innerHTML ='Confirm your Password';
					valid = false;
				}else{
					confirmPasswordError.innerHTML = '';
				}
				if(!pattern.test(email)){
					emailError.innerHTML='Enter valid Email';
					valid = false;
				}else{
					emailError.innerHTML = '';
				}
				if(pass!=rpass){
					confirmPasswordError.innerHTML ='Password didnot match';
					valid = false;
				}else{
					confirmPasswordError.innerHTML ='';
				}
				if(pass.length<6){
					passwordError.innerHTML ='Enter Password (length >6)';
					valid = false;
				}else{
					passwordError.innerHTML = '';
				}
				return valid;
			}
		</script>
</section>

<?php 
	include('inc/footer.php');
?>