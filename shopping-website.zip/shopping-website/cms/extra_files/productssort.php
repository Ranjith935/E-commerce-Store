<!-- for subcategory- Products -->
	<?php
        if($categoryData['parent_id'] != 0) {
    ?>
	<script>
        $(function() {
            $(".sortProducts").sortable({
                update: function(event, ui) {
                    var order = $(this).sortable('toArray', { attribute: 'data-id' });
                    $.ajax({
                        url: 'update-products-sort-order.php',
                        method: 'POST',
                        data: { order: order },
                        success: function(response) {
                            console.log(response);
                        }
                    });
                }
            });
        });
    </script>
    <table class="cmsBTable bg-white mt-2">
        <thead>
            <tr class="bg-black text-white">
                <th>Actions</th>
                <th>Title</th>
                <th class="w-75">Description</th>
            </tr>
        </thead>
        <tbody class="sortProducts">
            <?php
                $products = $category->getProductsForCategory($id);
                if(mysqli_num_rows($products) > 0) {
                    while($productRow = mysqli_fetch_assoc($products)) {
                        //if($productRow['cat_id'] == $id) {
                            $productCategoryImage = $category->showProductImage($productRow['id']);
                            $productImagePath = UPLOAD_PATH.'products/'.$productCategoryImage;
            ?>
            <tr class="text-dark" data-id="<?php echo $productRow['id']; ?>">
                <td>
                    <div class="d-flex ms-4">
                        <button class="btn" style="border:none;" disabled>
                            <i class="fa-solid fa-arrow-right-long text-center"></i>
                        </button>
                        <button class="imageBtn btn hover-text p-0">
                            <img src="<?php echo $productImagePath; ?>" class="border border-dark" alt="" width="30" />
                            <span class="tooltip-text" id="right">
                                <img src="<?php echo $productImagePath; ?>" alt="Image" width="170" />
                            </span>
                        </button>
                        <button class="editbtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit" data-id="<?php echo $productRow['id']; ?>">
                            <i class="fa-regular fa-pen-to-square"></i>
                        </button>
                    </div>
                </td>
                <td class="w-25"><?php echo $productRow['title']; ?></td>
                <td class="w-50"><?php echo $productRow['description']; ?></td>
            </tr>
            <?php
                    }
                } else {
            ?>
            <tr class="text-dark"><td colspan="3">No data inserted.</td></tr>
            <?php
                }
            ?>
        </tbody>
    </table>
    <?php
        }
    ?>
	<!--<script>
 document.querySelectorAll('.editbtn').forEach(button => {
   button.addEventListener('click', function() {
		const id = this.getAttribute('data-id');
		window.location.href = "editproducts.php?id="+id;
	});
});
</script>-->
<script>
$(function(){
	$('.sortProducts').sortable({
		update: function(event,ui){
			var order =$(this).sortable('toArray',{attribute: 'data-id'});
			$.ajax({
				url: 'update-sort-products-order.php',
				method:'POST',
				data :{order},
				success:function(response){
					var mesg = ' Order Updated!';
					alertBox(mesg);
				}
			});
		}
	});
});
function alertBox(message){
	const existingAlert = document.getElementById("livealert");
	if(existingAlert){
		existingAlert.remove();
	}
	Let alert =
		'<div id="livealert" class="alert w-50 alert-secondary alert-dismissable fade show mt-3" role="alert">'+
		'<strong class="text-success">Success</strong>' + message + '.' +
		'<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="close"</button>'
		'</div>';
		const table = document.querySelector('.cmsTable');
		table.insertAdjcentHTML('beforebegin',alert);
		
		setTimeout(()=>{
			document.getElementById("livealert").remove();
		},2000);
}
</script>
<!-- DOM -->
<!DOCTYPE html>
<html>
<body>
<!-- PAGE NAVBAR SECTION --> 
<?php include('inc/header.php'); ?>
<section class="cmcASection">
    <div class="container bg-secondary text-white">
        <div class="cmsContainer">
            <h4 class="fw-bold mb-4 text-center">Edit Category</h4>
            <form class="addFrom" method="post" action="" enctype="multipart/form-data">
                <!-- Form contents -->
                <!-- Existing form fields go here -->
                <input type="button" value="Back" id="prevPage" class="prevPage btn bg-danger text-white fw-bold " onclick="location.href='<?php echo ROOT_PATH; ?>category.php'"/>
                <input type="submit" value="Update" id="updateBannerData" name="updateBannerData" class="updateBannerData btn bg-danger text-white fw-bold"/>
            </form>

            <?php
                if($categoryData['parent_id'] == 0) {
                    // Display subcategories sortable table
                } elseif ($categoryData['parent_id'] != 0) {
                    // Display products sortable table
                }
            ?>
        </div>
    </div>
</section>

<script src="https://code.jquery.com/ui/1.13.3/jquery-ui.js"></script>
<script>
    // Alert Box function
    function alertBox(message) {
        const existingAlert = document.getElementById("liveAlert");
        if (existingAlert) {
            existingAlert.remove();
        }
        let alert =
            '<div id="liveAlert" class="alert w-50 alert-secondary alert-dismissible fade show mt-3" role="alert">' +
            '<strong class="text-success">Success!</strong>' + message + '.' +
            '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>' +
            '</div>';
        const mytable = document.querySelector('.cmsBTable');
        mytable.insertAdjacentHTML('beforebegin', alert);
        setTimeout(() => {
            document.getElementById("liveAlert").remove();
        }, 1000);
    }

    <?php if($categoryData['parent_id'] == 0) { ?>
        $(function() {
            $(".sortCategory").sortable({
                update: function(event, ui) {
                    var order = $(this).sortable('toArray', { attribute: 'data-id' });
                    $.ajax({
                        url: 'update-category-sort-order.php',
                        method: 'POST',
                        data: { order },
                        success: function(response) {
                            var mes = ' Order Updated!';
                            alertBox(mes);
                        }
                    });
                }
            });
        });
    <?php } else if($categoryData['parent_id'] != 0) { ?>
        $(function() {
            $(".sortProducts").sortable({
                update: function(event, ui) {
                    var order = $(this).sortable('toArray', { attribute: 'data-id' });
                    $.ajax({
                        url: 'update-products-sort-order.php',
                        method: 'POST',
                        data: { order },
                        success: function(response) {
                            var mes =' Order Updated!';
                            alertBox(mes);
                        }
                    });
                }
            });
        });
    <?php } ?>
</script>

<?php include('inc/footer.php'); ?>
</body>
</html>
<?php
document.addEventListener('DOMContentLoaded', (event) => {
    console.log("DOM fully loaded and parsed");

    // Edit button for category
    document.querySelectorAll('.catEditBtn').forEach(button => {
        console.log("Adding event listener to category edit button", button);
        button.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            console.log("Category edit button clicked, id:", id);
            window.location.href = "editcategory.php?id=" + id;
        });
    });

    // Edit button for products
    document.querySelectorAll('.editbtn').forEach(button => {
        console.log("Adding event listener to product edit button", button);
        button.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            console.log("Product edit button clicked, id:", id);
            window.location.href = "editproducts.php?id=" + id;
        });
    });
});
?>
<!--Alert Box -->
<script>
$(function() {
	$('.sortCategory').sortable({
		update: function(event, ui) {
			var order = $(this).sortable('toArray', {attribute: 'data-id'});
			$.ajax({
				url: 'update-category-sort-order.php',
				method: 'POST',
				data: {order},
				success: function(response) {
					var mesg = ' Order Updated!';
					alertBox(mesg);
				}
			});
		}
	});
});
</script>

<script>
function alertBox(message) {
	const existingAlert = document.getElementById("livealert");
	if (existingAlert) {
		existingAlert.remove();
	}
	let alert =
		'<div id="livealert" class="alert w-50 alert-secondary alert-dismissable fade show mt-3" role="alert">' +
		'<strong class="text-success">Success</strong> ' + message + '.' +
		'<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>' +
		'</div>';
	const table = document.querySelector('.cmsTable');
	table.insertAdjacentHTML('beforebegin', alert);
	
	setTimeout(() => {
		const alertElement = document.getElementById("livealert");
		if (alertElement) {
			alertElement.remove();
		}
	}, 2000);
}
</script>

