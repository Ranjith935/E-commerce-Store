<!--REMOVE MESSAGE FROM URL -->
<?php  
	session_start(); 
	if(!isset($_SESSION['loggedin'])){
		header("Location: login.php");
		exit();
	}
	include('lib/connection.php');
	include('lib/category-class.php');
	$category = new Category();
	$updateMessage = isset($_GET['message']) ? $_GET['message'] : null;
	
?>
<!DOCTYPE html>
<html>
<!-- PAGE NAVBAR SECTION --> 
<?php
	include 'inc/header.php' ;
?>

<section class="cmsBSection">
<div class="container bg-secondary">
	<div class="cmsContainer">
		<h4 class="fw-bold text-white text-center">Category List</h4>
		<button id="addButton" class="addButton btn bg-danger text-white fw-bold">ADD</button>
		<script>
			document.getElementById('addButton').addEventListener('click',function(){
				window.location.href = '<?php echo ROOT_PATH;?>addcategory.php';
			});
		</script>
		<?php if($updateMessage): ?>
           	<div class="d-flex justify-content-center">
                <div id="topAlert" class="alert w-75 alert-secondary alert-dismissible fade show" role="alert">
                    <strong class="text-success">Success!</strong> <?php echo $updateMessage; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
				<script>
					// Remove the message from the URL without reloading the page
					if (window.history.replaceState) {
						const url = new URL(window.location);
						url.searchParams.delete('message');
						window.history.replaceState({}, document.title, url.toString());
					}
					
					setTimeout(()=>{
						document.getElementById("topAlert").remove();
					},3000);
				</script>
           </div>
		<?php endif; ?>
		
		<!-- Rest of your code -->
	</div>
  </div>
</section>

<!-- Your existing JavaScript code here 
This JavaScript code snippet is designed to modify the browser's URL without reloading the page. Here's a breakdown of what each part does:
1. if (window.history.replaceState) {

This line checks if the replaceState method is available in the browser's history API. The replaceState method allows you to modify the current history entry without causing a page reload. Most modern browsers support this, but this check ensures compatibility.
2. const url = new URL(window.location);

This line creates a new URL object using the current page's URL (window.location). The URL object provides an easy way to manipulate different parts of the URL, such as its query parameters.
3. url.searchParams.delete('message');

This line removes the message query parameter from the URL's search parameters. For example, if the URL was https://example.com?message=hello, this line would remove message=hello from the URL.
4. window.history.replaceState({}, document.title, url.toString());

This line updates the browser's history entry with the modified URL (which no longer includes the message parameter).

    window.history.replaceState({}, document.title, url.toString()); has three arguments:
        The first argument {} is the state object associated with the new history entry, often left empty or used to store some data.
        The second argument document.title is the title of the document (the text shown on the browser tab).
        The third argument url.toString() is the new URL string to update in the browser's address bar.-->

<?php 
	include('inc/footer.php');
?>
</html>
