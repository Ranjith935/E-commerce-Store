<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dropdown Example</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-3">
    <!-- CMS LISTS Dropdown -->
    <div class="dropdown mt-3">
        <button class="w-75 btn btn-secondary dropdown-toggle text-start" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown">
            <i class="fa-solid fa-border-all"></i> CMS LISTS
        </button>
        <ul class="dropdown-menu bg-warning w-75" aria-labelledby="dropdownMenuButton">
            <li class="dropdown-submenu">
                <a class="dropdown-item dropdown-toggle" href="#">CATEGORY LIST</a>
                <ul class="dropdown-menu bg-warning">
                    <li><a class="dropdown-item" href="category1.php">Category 1</a></li>
                    <li><a class="dropdown-item" href="category2.php">Category 2</a></li>
                    <li><a class="dropdown-item" href="category3.php">Category 3</a></li>
                    <!-- Add more categories as needed -->
                </ul>
            </li>
            <li><a class="dropdown-item" href="#">BANNER CAROUSEL LIST</a></li>
            <li><a class="dropdown-item" href="#">HOME PRODUCTS LIST</a></li>
        </ul>
    </div>
</div>

<!-- Bootstrap JS and Popper.js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.10.2/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/js/bootstrap.min.js"></script>
</body>
</html>
<!--category and sub in table-->
<section class="cmsBSection">
<div class="container bg-secondary">
	<div class="cmsContainer">
		<h4 class="fw-bold text-white text-center">Category List</h4>
		<button id="addButton" class="addButton btn bg-danger text-white fw-bold">ADD</button>
		<script>
			document.getElementById('addButton').addEventListener('click',function(){
				window.location.href = 'addcategory.php';
			});
		</script>
		<table class="cmsBTable bg-white">
			<thead>
				<tr class="bg-black text-white">
					<th>Actions</th>
					<th>Title</th>
					<th class="w-75">Description</th>
				</tr>
			</thead>
			<tbody class="sort">
				   <?php
					$mainCategories = $category->parentIdQuery(); // Fetch main categories (parent_id = 0)
					if(mysqli_num_rows($mainCategories) > 0){
					  while($mainRow = mysqli_fetch_assoc($mainCategories)){
						$mainImage = $category->showImage($mainRow['title']);
						$mainImagePath = UPLOAD_PATH.'categories/'.$mainImage;
				   ?>
						<tr>
						  <td>
								<div class="d-flex">
									<button class="imageBtn btn hover-text p-0">
										<img src="<?php echo $mainImagePath; ?>" class="border border-dark" alt="" width="30"  />
										<span class="tooltip-text" id="right">
											<img src="<?php echo $mainImagePath; ?>" alt="Main Category Image" width="170" />
										</span>
									</button>
									<button class="livebtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Live" data-id="<?php echo $mainRow['id']; ?>" >
										<i class="fa-regular <?php if($mainRow['live'] == 1){ echo 'fa-eye'; }else{ echo 'fa-eye-slash';} ?>"></i>
									</button>
									<button class="editbtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit" data-id="<?php echo $mainRow['id']; ?>">
										<i class="fa-regular fa-pen-to-square"></i>
									</button>
									<button class="deletebtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete" data-id="<?php echo $mainRow['id']; ?>">
										<i class="fa-solid fa-trash"></i>
									</button>
								</div>
						 </td>
						 <td class="w-25 fw-bold"><?php echo $mainRow['title']; ?></td>
						 <td class="w-50"><?php echo $mainRow['description']; ?></td>
						</tr>
				   <?php
						$subCategories = $category->selectCategoryData(); // Fetch all categories to find subcategories
						if(mysqli_num_rows($subCategories) > 0){
						  while($subRow = mysqli_fetch_assoc($subCategories)){
							  if($subRow['parent_id'] == $mainRow['id']) { // Check if it is a subcategory of the main category
								$subImage = $category->showImage($subRow['title']);
								$subImagePath = UPLOAD_PATH.'categories/'.$subImage;
				   ?>
							<tr>
							  <td>
									<div class="d-flex ms-4">
										<button class="imageBtn btn hover-text p-0">
											<img src="<?php echo $subImagePath; ?>" class="border border-dark" alt="" width="30"  />
											<span class="tooltip-text" id="right">
												<img src="<?php echo $subImagePath; ?>" alt="Subcategory Image" width="170" />
											</span>
										</button>
										<button class="livebtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Live" data-id="<?php echo $subRow['id']; ?>" >
											<i class="fa-regular <?php if($subRow['live'] == 1){ echo 'fa-eye'; }else{ echo 'fa-eye-slash';} ?>"></i>
										</button>
										<button class="editbtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit" data-id="<?php echo $subRow['id']; ?>">
											<i class="fa-regular fa-pen-to-square"></i>
										</button>
										<button class="deletebtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete" data-id="<?php echo $subRow['id']; ?>">
											<i class="fa-solid fa-trash"></i>
										</button>
									</div>
							 </td>
							 <td class="w-25"><i class="fa-solid fa-arrow-right-long"></i><i class="fa-solid fa-circle-arrow-right"></i><?php echo $subRow['title']; ?></td>
							 <td class="w-50"><?php echo $subRow['description']; ?></td>
							</tr>
						<?php
							  }
							}
						  }
						}
					}else {
					?>
					<tr><td colspan="3">No data inserted.</td></tr>
					<?php
					}
					  ?>
			</tbody>
		</table>
		<input type="button" value="ADD" class="addButton2 btn bg-danger text-white fw-bold" onclick="location.href='addcategory.php'"/>
	</div>
  </div>
</section>
edit main CATEGORY
<section class="cmcASection">
  <div class="container bg-secondary text-white">
    <div class="cmsContainer">
      <h4 class="fw-bold mb-4 text-center">Add Category</h4>
      <form class="addFrom" method="post" action="" enctype="multipart/form-data">
        <div class="form-group row mb-3">
          <label for="mainCategory" class="col-sm-3 form-label fw-bold text-end">Main Category:</label>
          <div class="col-sm-1">
            <input class="form-check-input" type="radio" name="mainCategory" id="mainCatYes" value="1" onclick="toggleCategorySection(true)" />
            <label class="form-check-label" for="mainCatYes">Yes</label>
          </div>
          <div class="col-sm-1">
            <input class="form-check-input" type="radio" name="mainCategory" id="mainCatNo" value="0" checked onclick="toggleCategorySection(false)" />
            <label class="form-check-label" for="mainCatNo">No</label>
          </div>
        </div>
        <div id="categorySection" style="display:none;">
          <div class="form-group row mb-3">
            <label for="category" class="col-sm-3 form-label fw-bold text-end">Category:</label>
            <div class="col-sm-8">
              <select class="text-center w-25" name="mainC">
                <option value="1">Indoor</option>
                <option value="2">Outdoor</option>
              </select>
            </div>
          </div>
        </div>
        <div class="form-group row mb-3">
          <label for="title" class="col-sm-3 form-label fw-bold text-end">Title:</label>
          <div class="col-sm-8">
            <input type="text" class="form-control" id="title" name="title"/>
          </div>
        </div>
        <div class="form-group row mb-3">
          <label for="description" class="col-sm-3 form-label fw-bold text-end">Description:</label>
          <div class="col-sm-8">
            <textarea class="form-control" id="description" name="description" rows="5"></textarea>
          </div>
        </div>
        <div class="form-group row mb-3">
          <label for="fileupload" class="col-sm-3 form-label fw-bold text-end">Upload Image:</label>
          <div class="col-sm-4">
            <input type="file" class="form-control" id="fileupload" name="fileupload"/>
          </div>
          <div class="col-sm-2">
            <input type="text" class="form-control bg-secondary text-white" width="40px" value="File size <= 5 MB" disabled />
          </div>
        </div>
        <div class="form-group row mb-3">
          <label for="fontclass" class="col-sm-3 form-label fw-bold text-end">Font-Class:</label>
          <div class="col-sm-8 w-50">
            <input type="text" class="form-control" id="fontclass" name="fontclass"/>
          </div>
        </div>
        <div class="form-group row mb-3">
          <label for="bLiveyes" class="col-sm-3 form-label fw-bold text-end">Service is Live:</label>
          <div class="col-sm-1">
            <input class="form-check-input" type="radio" name="bLive" id="bLiveyes" value="1" checked />
            <label class="form-check-label" for="bLiveoyes">Yes</label>
          </div>
          <div class="col-sm-1">
            <input class="form-check-input" type="radio" name="bLive" id="bLiveno" value="0" />
            <label class="form-check-label" for="bLiveno">No</label>
          </div>
        </div>
        <input type="button" value="Listing Page" id="prevPage" class="prevPage btn bg-danger text-white fw-bold" onclick="location.href='category.php'"/>
        <input type="submit" value="Add" id="addBannerData" name="addBannerData" class="addBannerData btn bg-danger text-white fw-bold"/>
      </form>
    </div>
  </div>
</section>
<!-- CMS header dropdowns -->

<div class="offcanvas-body">
							<div class="mt-3">
								<button class="w-75 btn btn-secondary text-start">
									<i class="fa-solid fa-border-all"></i> <a class="text-white" href="<?php echo ROOT_PATH;?>home.php" style="text-decoration:none;">DASHBOARD</a>
								</button>
								<!--<ul class="dropdown-menu bg-warning w-75" aria-labelledby="dropdownMenuButton">
									<li><a class="dropdown-item" href="<?php echo ROOT_PATH;?>category.php"> CATEGORY LIST</a></li>
									<li><a class="dropdown-item" href="<?php echo ROOT_PATH;?>banner.php">BANNER LIST</a></li>
									<li><a class="dropdown-item" href="#">HOME PRODUCTS LIST</a></li>
								</ul>-->
							</div>
							<div class="dropdown mt-3">
								<button class="w-75 btn btn-secondary dropdown-toggle text-start" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown">
									<i class="fa-solid fa-border-all"></i> CMS LISTS
								</button>
								<ul class="dropdown-menu bg-warning w-75" aria-labelledby="dropdownMenuButton">
									<li><a class="dropdown-item" href="<?php echo ROOT_PATH;?>category.php"> CATEGORY LIST</a></li>
									<li><a class="dropdown-item" href="<?php echo ROOT_PATH;?>banner.php">BANNER LIST</a></li>
									<li><a class="dropdown-item" href="#">HOME PRODUCTS LIST</a></li>
								</ul>
							</div>
							<div class="dropdown mt-3">
								<button class="w-75 btn btn-secondary dropdown-toggle text-start" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
									<i class="fa-solid fa-layer-group"></i> CATEGORIES
								</button>
								<ul class="dropdown-menu bg-warning w-50" aria-labelledby="dropdownMenuButton">
                                   <li class="nav-item dropdown dropend">
                                       <a class="dropdown-item dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" onclick="event.stopPropagation();"><i class="fa-solid fa-person-shelter"></i>  INDOOR</a>
                                       <ul class="dropdown-menu bg-warning">
                                           <li><a class="dropdown-item" href="#"><i class="fa-brands fa-space-awesome"></i>  BADMINTON</a></li>
                                           <li><a class="dropdown-item" href="#"><i class="fa-solid fa-basketball"></i>  BASKETBALL</a></li>
										   <li><a class="dropdown-item" href="#"><i class="fa-solid fa-table-tennis-paddle-ball"></i>  TENNIS</a></li>
                                       </ul>
                                   </li>
                                   <li class="nav-item dropdown dropend">
                                       <a class="dropdown-item dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" onclick="event.stopPropagation();"><i class="fa-solid fa-land-mine-on"></i> OUTDOOR</a>
                                       <ul class="dropdown-menu bg-warning">
                                           <li><a class="dropdown-item" href="#"><i class="fa-solid fa-baseball-bat-ball"></i>  CRICKET</a></li>
                                           <li><a class="dropdown-item" href="#"><i class="fa-solid fa-futbol"></i>  FOOTBALL</a></li>
                                           <li><a class="dropdown-item" href="#"><i class="fa-solid fa-wand-sparkles"></i>  HOCKEY</a></li>
                                       </ul>
                                   </li>
                               </ul>
							</div>
							<div class="dropdown mt-3">
								<button class="w-75 btn btn-secondary dropdown-toggle text-start" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown">
									<i class="fas fa-user mx-1"></i> PROFILE
								</button>
								<ul class="dropdown-menu bg-warning w-50" aria-labelledby="dropdownMenuButton">
									<!--<li><a class="dropdown-item" href="#"><i class="fa-solid fa-id-card-clip"></i>  My account</a></li>-->
									<li><a class="dropdown-item" href="#"><i class="fa-solid fa-box-open"></i>  Orders</a></li>
									<li><a class="dropdown-item" href="#"><i class="fa-solid fa-address-book"></i>  Address</a></li>
									<li><a class="dropdown-item" name="logout" href="<?php echo ROOT_PATH;?>logout.php"><i class="fa-solid fa-right-from-bracket"></i>  Log out</a></li>
								</ul>
							</div>
						</div>
<!--tooltip getlivecategory.php-->

<?php
session_start();
if(!isset($_SESSION['loggedin'])){
    header("Location: login.php");
    exit();
}
include('lib/category-class.php');
$category = new Category();

if(isset($_POST['id'])){
    $id = $_POST['id'];
    $result = $category->getCategoryById($id);
    if($result){
        $live = $result['live'];
        echo json_encode(['live' => $live]);
    } else {
        echo json_encode(['error' => 'Category not found']);
    }
}
?>
<?php  
	session_start(); 
	if(!isset($_SESSION['loggedin'])){
		header("Location: login.php");
		exit();
	}
	include('lib/category-class.php');
	$category = new Category();
?>
<!DOCTYPE html>
<html>
<head>
	<!-- Include Bootstrap CSS and any other required CSS/JS files -->
	<link rel="stylesheet" href="path/to/bootstrap.min.css">
	<script src="path/to/jquery.min.js"></script>
	<script src="path/to/bootstrap.bundle.min.js"></script>
	<style>
		.tooltip-inner {
			max-width: 200px;
		}
	</style>
</head>
<body>
<!-- PAGE NAVBAR SECTION --> 
<?php include 'inc/header.php'; ?>

<section class="cmsBSection">
	<div class="container bg-secondary">
		<div class="cmsContainer">
			<h4 class="fw-bold text-white text-center">Category List</h4>
			<button id="addButton" class="addButton btn bg-danger text-white fw-bold">ADD</button>
			<script>
				document.getElementById('addButton').addEventListener('click',function(){
					window.location.href = '<?php echo ROOT_PATH;?>addcategory.php';
				});
			</script>
			<table class="cmsBTable bg-white">
				<thead>
					<tr class="bg-black text-white">
						<th>Actions</th>
						<th>Title</th>
						<th class="w-75">Description</th>
					</tr>
				</thead>
				<tbody class="sort">
					<!-- FOR MAIN CATEGORIES -->
					<?php
					$mainCategory = $category->parentIdQuery();
					if(mysqli_num_rows($mainCategory) > 0){
						while($mainrow= mysqli_fetch_assoc($mainCategory)){
							$mainImage = $category->showImage($mainrow['title']);
							$mainImagePath = UPLOAD_PATH.'categories/'.$mainImage;
					?>
					<tr class="bg-warning bg-opacity-25">
						<td>
							<div class="d-flex justify-content-center">
								<button class="imageBtn btn hover-text p-0">
									<img src="<?php echo $mainImagePath; ?>" class="border border-dark" alt="" width="30" />
									<span class="tooltip-text" id="right">
										<img src="<?php echo $mainImagePath; ?>" alt="Image" width="150" />
									</span>
								</button>
								<button class="livebtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Live" data-id="<?php echo $mainrow['id']; ?>">
									<i class="fa-regular <?php echo $mainrow['live'] == 1 ? 'fa-eye' : 'fa-eye-slash'; ?>"></i>
								</button>
								<button class="editbtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit" data-id="<?php echo $mainrow['id']; ?>">
									<i class="fa-regular fa-pen-to-square"></i>
								</button>
								<button class="deletebtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete" data-id="<?php echo $mainrow['id']; ?>">
									<i class="fa-solid fa-trash"></i>
								</button>
							</div>
						</td>
						<td class="w-25 fw-bold"><?php echo $mainrow['title']; ?></td>
						<td class="w-50 fw-bold"><?php echo $mainrow['description']; ?></td>
					</tr>
					<!-- FOR SUBCATEGORIES -->
					<?php
						$subCategory = $category->selectCategoryData();
						if(mysqli_num_rows($subCategory)>0){
							while($subrow = mysqli_fetch_assoc($subCategory)){
								if($subrow['parent_id'] == $mainrow['id']){
									$subCategoryImage = $category->showImage($subrow['title']);
									$subImagePath = UPLOAD_PATH.'categories/'.$subCategoryImage;
					?>
					<tr>
						<td>
							<div class="d-flex ms-4">
								<button class="btn" style="border:none;" disabled>
									<i class="fa-solid fa-arrow-right-long text-center"></i>
								</button>
								<button class="imageBtn btn hover-text p-0">
									<img src="<?php echo $subImagePath; ?>" class="border border-dark" alt="" width="30" />
									<span class="tooltip-text" id="right">
										<img src="<?php echo $subImagePath; ?>" alt="Image" width="170" />
									</span>
								</button>
								<button class="livebtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Live" data-id="<?php echo $subrow['id']; ?>">
									<i class="fa-regular <?php echo $subrow['live'] == 1 ? 'fa-eye' : 'fa-eye-slash'; ?>"></i>
								</button>
								<button class="editbtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit" data-id="<?php echo $subrow['id']; ?>">
									<i class="fa-regular fa-pen-to-square"></i>
								</button>
								<button class="deletebtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete" data-id="<?php echo $subrow['id']; ?>">
									<i class="fa-solid fa-trash"></i>
								</button>
							</div>
						</td>
						<td class="w-25"><?php echo $subrow['title']; ?></td>
						<td class="w-50"><?php echo $subrow['description']; ?></td>
					</tr>
					<!-- For super-sub category -->
					<?php
						$superSubCategory = $category->selectCategoryData();
						if(mysqli_num_rows($superSubCategory)>0){
							while($superSubrow = mysqli_fetch_assoc($superSubCategory)){
								if($superSubrow['parent_id'] == $subrow['id']){
									$superSubCategoryImage = $category->showImage($superSubrow['title']);
									$superSubImagePath = UPLOAD_PATH.'categories/'.$superSubCategoryImage;
					?>
					<tr>
						<td>
							<div class="d-flex ms-5">
								<button class="btn" style="border:none;" disabled>
									<i class="fa-solid fa-arrow-right-long text-center"></i>
								</button>
								<button class="imageBtn btn hover-text p-0">
									<img src="<?php echo $superSubImagePath; ?>" class="border border-dark" alt="" width="30" />
									<span class="tooltip-text" id="right">
										<img src="<?php echo $superSubImagePath; ?>" alt="Image" width="170" />
									</span>
								</button>
								<button class="livebtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Live" data-id="<?php echo $superSubrow['id']; ?>">
									<i class="fa-regular <?php echo $superSubrow['live'] == 1 ? 'fa-eye' : 'fa-eye-slash'; ?>"></i>
								</button>
								<button class="editbtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit" data-id="<?php echo $superSubrow['id']; ?>">
									<i class="fa-regular fa-pen-to-square"></i>
								</button>
								<button class="deletebtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete" data-id="<?php echo $superSubrow['id']; ?>">
									<i class="fa-solid fa-trash"></i>
								</button>
							</div>
						</td>
						<td class="w-25"><?php echo $superSubrow['title']; ?></td>
						<td class="w-50"><?php echo $superSubrow['description']; ?></td>
					</tr>
					<?php
								}
							}
						}
					}
				}
			}
		}
	} else {
	?>
	<tr><td colspan="3">No data inserted.</td></tr>
	<?php
	}
	?>
				</tbody>
			</table>
			<input type="button" value="ADD" class="addButton2 btn bg-danger text-white fw-bold" onclick="location.href='<?php echo ROOT_PATH;?>addcategory.php'"/>
		</div>
	</div>
</section>

<script>
document.querySelectorAll('.editbtn').forEach(button => {
	button.addEventListener('click', function() {
		const id = this.getAttribute('data-id');
		window.location.href = "editcategory.php?id=" + id;
	});
});

document.querySelectorAll('.livebtn').forEach(button => {
	button.addEventListener('click', function() {
		const id = this.getAttribute('data-id');
		const button = this;
		$.ajax({
			type: 'POST',
			url: 'togglelivecategory.php',
			data: {id: id},
			dataType: 'json',
			success: function(response) {
				if (response.live == 1) {
					alertMessage = 'Category is live';
					addAlert(alertMessage);
					button.querySelector('i').classList.remove('fa-eye-slash');
					button.querySelector('i').classList.add('fa-eye');
				} else {
					alertMessage = 'Category is un-live';
					addAlert(alertMessage);
					button.querySelector('i').classList.remove('fa-eye');
					button.querySelector('i').classList.add('fa-eye-slash');
				}
			},
			error: function(xhr, status, error) {
				console.error(xhr.responseText);
			}
		});
	});
});

function addAlert(message) {
	const existingAlert = document.getElementById("liveAlert");
	if (existingAlert) {
		existingAlert.remove();
	}
	let alert =
		'<div id="liveAlert" class="alert w-75 alert-secondary alert-dismissible fade show" role="alert">' +
		'<strong class="text-success">Success!</strong>' + message + '.' +
		'<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>' +
		'</div>';
	const mytable = document.querySelector('.cmsBTable');
	mytable.insertAdjacentHTML('beforebegin', alert);
}

document.querySelectorAll('.deletebtn').forEach(button => {
	button.addEventListener('click', function() {
		const id = this.getAttribute('data-id');
		if (confirm('Confirm to delete?')) {
			window.location.href = "deletecategory.php?id=" + id;
		}
	});
});

document.querySelectorAll('.livebtn').forEach(button => {
	button.addEventListener('mouseover', function() {
		const id = this.getAttribute('data-id');
		const tooltipElement = this;
		$.ajax({
			type: 'POST',
			url: 'getlivecategory.php',
			data: {id: id},
			dataType: 'json',
			success: function(response) {
				const liveStatus = response.live == 1 ? 'Live' : 'Un-live';
				tooltipElement.setAttribute('title', liveStatus);
				const tooltipInstance = bootstrap.Tooltip.getInstance(tooltipElement);
				tooltipInstance.setContent({ '.tooltip-inner': liveStatus });
			},
			error: function(xhr, status, error) {
				console.error(xhr.responseText);
			}
		});
	});
});

var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
	return new bootstrap.Tooltip(tooltipTriggerEl);
});
</script>
<?php include('inc/footer.php'); ?>
</body>
</html>
<!-- timeout alertbox -->
<script>
function addAlert(message) {
	const existingAlert = document.getElementById("liveAlert");
	if (existingAlert) {
		existingAlert.remove();
	}

	let alert =
		'<div id="liveAlert" class="alert w-75 alert-secondary alert-dismissible fade show" role="alert">' +
		'<strong class="text-success">Success!</strong>' + message + '.' +
		'<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>' +
		'</div>';
	const mytable = document.querySelector('.cmsBTable');
	mytable.insertAdjacentHTML('beforebegin', alert);

	setTimeout(() => {
		const alertElement = document.getElementById("liveAlert");
		if (alertElement) {
			alertElement.classList.remove('show');
			alertElement.addEventListener('transitionend', () => alertElement.remove());
		}
	}, 3000);
}
</script>
<!-- FOr super sub category -->
<?php
	$superSubCategory = $category->selectCategoryData();
	if(mysqli_num_rows($superSubCategory)>0){
		while($superSubrow = mysqli_fetch_assoc($superSubCategory)){
			if($superSubrow['parent_id']==$subrow['id']){
			$superSubCategoryImage = $category->showImage($superSubrow['title']);
			$superSubImagePath = UPLOAD_PATH.'categories/'.$superSubCategoryImage;
?>
<tr>
	<td>
		<div class="d-flex ms-5">
			<button class="btn" style="border:none;" disabled>
				<i class="fa-solid fa-arrow-right-long text-center"></i>
			</button>
			<button class="imageBtn btn hover-text p-0">
				<img src="<?php echo $superSubImagePath; ?> " class="border border-dark" alt="" width="30" />
				<span class="tooltip-text" id="right">
					<img src="<?php echo $superSubImagePath; ?>" alt="Image" width="170" />
				</span>
			</button>
			<button class="livebtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Live" data-id="<?php echo $superSubrow['id'];  ?>" >
				<i class="fa-regular <?php if($superSubrow['live'] == 1){ echo 'fa-eye'; }else{ echo 'fa-eye-slash';} ?>"></i>
			</button>
			<button class="editbtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit" data-id="<?php echo $superSubrow['id'] ?>" >
				<i class="fa-regular fa-pen-to-square"></i>
			</button>
			<button class="deletebtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete" data-id="<?php echo $superSubrow['id']; ?>" >
				<i class="fa-solid fa-trash"></i>
			</button>
		</div>
	</td>
	<td class="w-25"><?php echo $superSubrow['title']; ?></td>
	<td class="w-50"><?php echo $superSubrow['description']; ?></td>
</tr>
<!--Join Table insert-->
<?php
public function insertProductData($userId){
    global $conn;
    $cat = $_POST['mainCategory'];
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $price = mysqli_real_escape_string($conn, $_POST['productPrice']);
    $bLive = mysqli_real_escape_string($conn, $_POST['bLive']);
    $ip = $_SERVER['REMOTE_ADDR'];

    include('inc/uploadProducts.php');
    $target_file = uploadFile($_FILES['fileupload']);

    if (!empty($cat)) {
        foreach ($cat as $option) {
            $sql = "INSERT INTO products SET
                    `fk_cid` ='".$option."',
                    `title`='".$title."',
                    `description`='".$description."',
                    `image`='".$target_file."',
                    `price`='".$price."',
                    `live`='".$bLive."',
                    `ip_address`='".$ip."',
                    `created_by` = '".$userId."' ";
            
            $result = mysqli_query($conn, $sql);

            if (!$result) {
                // Error handling
                return false;
            }

            $prod_id = mysqli_insert_id($conn);

            // Insert into join table
            $joinTableQuery = "INSERT INTO prod_cat_join SET
                                prod_id='".$prod_id."',
                                cat_id='".$option."'";
            $joinRes = mysqli_query($conn, $joinTableQuery);

            if (!$joinRes) {
                // Error handling
                return false;
            }
        }
        return true; 
    }
    return false; 
}
?>
<!---->
<?php
public function insertProductData($userId) {
    global $conn;
    
    // Validate and sanitize inputs
    $cat = isset($_POST['mainCategory']) ? $_POST['mainCategory'] : [];
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $price = mysqli_real_escape_string($conn, $_POST['productPrice']);
    $bLive = mysqli_real_escape_string($conn, $_POST['bLive']);
    $ip = $_SERVER['REMOTE_ADDR'];
    
    // Include the upload file functionality
    include('inc/uploadProducts.php');
    $target_file = uploadFile($_FILES['fileupload']);

    if (!empty($cat)) {
        // Insert into products table
        $sql = "INSERT INTO products SET
            `title` = '$title',
            `description` = '$description',
            `image` = '$target_file',
            `price` = '$price',
            `live` = '$bLive',
            `ip_address` = '$ip',
            `created_by` = '$userId'";

        $result = mysqli_query($conn, $sql);
        
        if ($result) {
            $prod_id = mysqli_insert_id($conn);

            // Insert into prod_cat_join table for each category
            foreach ($cat as $option) {
                $option = mysqli_real_escape_string($conn, $option); // Sanitize each category id
                $joinTableQuery = "INSERT INTO prod_cat_join SET
                    `prod_id` = '$prod_id',
                    `cat_id` = '$option'";
                $joinRes = mysqli_query($conn, $joinTableQuery);
                
                if (!$joinRes) {
                    // Handle error if inserting into join table fails
                    return false;
                }
            }
            return true;
        } else {
            return false;
        }
    }
    return false; 
}
?>
<!--cat title-->
<?php
public function productMainCategory($id) {
    global $conn;

    // Ensure $id is properly escaped to prevent SQL injection
    $id = mysqli_real_escape_string($conn, $id);

    // Get category ID(s) from prod_cat_join table
    $catIdQuery = "SELECT cat_id FROM prod_cat_join WHERE prod_id = '$id'";
    $catIdResult = mysqli_query($conn, $catIdQuery);

    if ($catIdResult && mysqli_num_rows($catIdResult) > 0) {
        // Initialize an array to store category titles
        $categoryTitles = [];

        // Fetch each category ID and get the corresponding title
        while ($catRow = mysqli_fetch_assoc($catIdResult)) {
            $catId = $catRow['cat_id'];

            // Get the title from the category table
            $titleQuery = "SELECT title FROM category WHERE id = '$catId'";
            $titleResult = mysqli_query($conn, $titleQuery);

            if ($titleResult && mysqli_num_rows($titleResult) > 0) {
                $titleRow = mysqli_fetch_assoc($titleResult);
                $categoryTitles[] = $titleRow['title'];
            }
        }

        // Return the category titles as an array
        return $categoryTitles;
    } else {
        // Return an empty array if no categories found
        return [];
    }
}
?>
<!-- Edit pro-->
<?php
public function getMainCategoryByProductId($id) {
    global $conn;

    // Prepare and execute the query to fetch category IDs associated with the product
    $joinQuery = "SELECT cat_id FROM prod_cat_join WHERE prod_id=?";
    $stmt = mysqli_prepare($conn, $joinQuery);
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    $joinQueryResult = mysqli_stmt_get_result($stmt);

    if ($joinQueryResult && mysqli_num_rows($joinQueryResult) > 0) {
        // Initialize variable to hold the category data
        $mainCatRow = [];
        while ($catRow = mysqli_fetch_assoc($joinQueryResult)) {
            $catId = $catRow['cat_id'];

            // Prepare and execute the query to fetch the category title
            $mainCatQuery = "SELECT id, title FROM category WHERE id=?";
            $stmtCat = mysqli_prepare($conn, $mainCatQuery);
            mysqli_stmt_bind_param($stmtCat, 'i', $catId);
            mysqli_stmt_execute($stmtCat);
            $mainCatResult = mysqli_stmt_get_result($stmtCat);

            if ($mainCatResult && mysqli_num_rows($mainCatResult) > 0) {
                // Fetch the category details
                $mainCatRow = mysqli_fetch_assoc($mainCatResult);
            }
        }

        return $mainCatRow;
    } else {
        return [];
    }
}

?>
<!--display the selected cat-->
<div class="col-sm-8">
    <select class="text-center w-50 p-1" name="mainCategory[]" size="6" multiple>
        <!-- Display the categories which are selected previously here -->
        <?php
        $mainCategory = $product->getMainCategoryByProductId($productData['id']);
        foreach ($mainCategory as $category) {
        ?>
            <option class="border" value="<?php echo $category['id']; ?>" selected><?php echo $category['title']; ?></option>
        <?php
        }
        ?>
        <?php
        $otherMainCategory = $product->getAllMainCategory($productData['id']);
        if (mysqli_num_rows($otherMainCategory) > 0) {
            while ($otherRow = mysqli_fetch_assoc($otherMainCategory)) {
        ?>
            <option class="border" value="<?php echo $otherRow['id']; ?>"><?php echo $otherRow['title']; ?></option>
        <?php
            }
        }
        ?>
    </select>
</div>
<!-- -->
<?php
public function getMainCategoryByProductId($id){
    global $conn;
    $joinQuery = "SELECT cat_id FROM prod_cat_join WHERE prod_id='$id'";
    $joinQueryResult = mysqli_query($conn, $joinQuery);
    $mainCatRows = [];
    if ($joinQueryResult && mysqli_num_rows($joinQueryResult) > 0) {
        while ($catRow = mysqli_fetch_assoc($joinQueryResult)) {
            $catId = $catRow['cat_id'];
            $mainCatQuery = "SELECT id, title FROM category WHERE id='$catId'";
            $mainCatResult = mysqli_query($conn, $mainCatQuery);
            if ($mainCatResult && mysqli_num_rows($mainCatResult) > 0) {
                $mainCatRows[] = mysqli_fetch_assoc($mainCatResult);
            }
        }
    }
    return $mainCatRows;
}
public function getAllMainCategory($productId){
    global $conn;
    $query = "
        SELECT * FROM category 
        WHERE id NOT IN (
            SELECT cat_id FROM prod_cat_join WHERE prod_id='$productId'
        ) 
        AND parent_id != '0' 
        AND delete_id != '1'
    ";
    $result = mysqli_query($conn, $query);
    return $result;
}
?>
<!--SOrting the table -->
<!DOCTYPE html>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.13.3/jquery-ui.js"></script>
<div>
    <script>
        $(function() {
            $(".sort").sortable({
                update: function(event, ui) {
                    var order = $(this).sortable('toArray', { attribute: 'data-id' });
                    $.ajax({
                        url: 'update_sort_order.php',
                        method: 'POST',
                        data: { order: order },
                        success: function(response) {
                            console.log(response);
                        }
                    });
                }
            });
        });
    </script>

    <?php
        if($categoryData['parent_id'] == 0) {
    ?>
    <table class="cmsBTable bg-white mt-2">
        <thead>
            <tr class="bg-black text-white">
                <th>Actions</th>
                <th>Title</th>
                <th class="w-75">Description</th>
            </tr>
        </thead>
        <tbody class="sort">
            <?php
                $subCategory = $category->selectCategoryData();
                if(mysqli_num_rows($subCategory) > 0) {
                    while($subrow = mysqli_fetch_assoc($subCategory)) {
                        if($subrow['parent_id'] == $id) {
                            $subCategoryImage = $category->showImage($subrow['title']);
                            $subImagePath = UPLOAD_PATH.'categories/'.$subCategoryImage;
            ?>
            <tr class="text-dark" data-id="<?php echo $subrow['id']; ?>">
                <td>
                    <div class="d-flex ms-4">
                        <button class="btn" style="border:none;" disabled>
                            <i class="fa-solid fa-arrow-right-long text-center"></i>
                        </button>
                        <button class="imageBtn btn hover-text p-0">
                            <img src="<?php echo $subImagePath; ?>" class="border border-dark" alt="" width="30" />
                            <span class="tooltip-text" id="right">
                                <img src="<?php echo $subImagePath; ?>" alt="Image" width="170" />
                            </span>
                        </button>
                        <button class="editbtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit" data-id="<?php echo $subrow['id']; ?>">
                            <i class="fa-regular fa-pen-to-square"></i>
                        </button>
                    </div>
                </td>
                <td class="w-25"><?php echo $subrow['title']; ?></td>
                <td class="w-50"><?php echo $subrow['description']; ?></td>
            </tr>
            <?php
                        }
                    }
                } else {
            ?>
            <tr><td colspan="3">No data inserted.</td></tr>
            <?php
                }
            ?>
        </tbody>
    </table>
    <?php
        }
    ?>
</div>
</body>
</html>
//
<?php
require_once 'config.php'; // include your database connection file

if(isset($_POST['order'])) {
    $order = $_POST['order'];
    foreach($order as $sort_id => $id) {
        $query = "UPDATE category SET sort_id = $sort_id WHERE id = $id";
        mysqli_query($conn, $query);
    }
    echo 'Order updated successfully';
} else {
    echo 'No data received';
}
?>

