<?php  
	session_start(); 
	if(!isset($_SESSION['loggedin'])){
		header("Location: login.php");
		exit();
	}
	include('lib/connection.php');
	include('lib/category-class.php');
	$category = new Category();
	$updateMessage = isset($_GET['message']) ? $_GET['message'] : null;
	
?>
<!DOCTYPE html>
<html>
<!-- PAGE NAVBAR SECTION --> 
<?php
	include 'inc/header.php' ;
?>

<section class="cmsBSection">
<div class="container bg-secondary">
	<div class="cmsContainer">
		<h4 class="fw-bold text-white text-center">Category List</h4>
		<button id="addButton" class="addButton btn bg-danger text-white fw-bold">ADD</button>
		<script>
			document.getElementById('addButton').addEventListener('click',function(){
				window.location.href = '<?php echo ROOT_PATH;?>addcategory.php';
			});
		</script>
		<?php if($updateMessage): ?>
           	<div class="d-flex justify-content-center">
                <div id="topAlert" class="alert w-75 alert-secondary alert-dismissible fade show" role="alert">
                    <strong class="text-success">Success!</strong> <?php echo $updateMessage; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
				<script>
				<!--to remove the message in urL -->
			        const url = new URL(window.location);
					url.searchParams.delete('message');
					window.history.replaceState(null,null,url);
				</script>
				<script>
					setTimeout(()=>{
						document.getElementById("topAlert").remove();
					},2000);
				</script>
           </div>
		<?php endif; ?>
			<table class="cmsBTable bg-white">
			<thead>
				<tr class="bg-black text-white">
					<th>Actions</th>
					<th>Title</th>
					<th class="w-75">Description</th>
				</tr>
			</thead>
			<tbody class="sort">
			<!-- FOR MAIN CATEGORIES -->
				   <?php
					$mainCategory = $category->parentIdQuery();
					if(mysqli_num_rows($mainCategory) > 0){
					  while($mainrow= mysqli_fetch_assoc($mainCategory)){
						$mainImage = $category->showImage($mainrow['id']);
						$mainImagePath = UPLOAD_PATH.'categories/'.$mainImage;
				   ?>
						<tr class="bg-warning bg-opacity-25">
						  <td>
								<div class="d-flex justify-content-center">
									<button class="imageBtn btn hover-text p-0">
										<img src="<?php echo $mainImagePath; ?>" class="border border-dark" alt="" width="30"  />
										<span class="tooltip-text" id="right">
											<img src="<?php echo $mainImagePath; ?>" alt="Image" width="150" />
										</span>
									</button>
									<button class="livebtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" data-id="<?php echo $mainrow['id']; ?>" >
										<i class="fa-regular <?php if($mainrow['live'] == 1){ echo 'fa-eye'; }else{ echo 'fa-eye-slash';} ?>"></i>
									</button>
									<button class="editbtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit" data-id="<?php echo $mainrow['id']; ?>">
										<i class="fa-regular fa-pen-to-square"></i>
									</button>
									<button class="deletebtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete" data-id="<?php echo $mainrow['id']; ?>">
										<i class="fa-solid fa-trash"></i>
									</button>
								</div>
						 </td>
						 <td class="w-25 fw-bold">
							<a class="editWithTitle text-dark" href="editcategory.php?id=<?php echo $mainrow['id']; ?>">
								<?php echo $mainrow['title']; ?>
							</a>
						</td>
						 <td class="w-50 fw-bold"><?php echo $mainrow['description']; ?></td>
						</tr>
					<!-- FOR SUBCATEGORIES -->
					<?php
						$subCategory = $category->selectCategoryData();
						if(mysqli_num_rows($subCategory)>0){
							while($subrow = mysqli_fetch_assoc($subCategory)){
								if($subrow['parent_id']==$mainrow['id']){
								$subCategoryImage = $category->showImage($subrow['id']);
								$subImagePath = UPLOAD_PATH.'categories/'.$subCategoryImage;
					?>
					<tr>
						<td>
							<div class="d-flex ms-4">
								<button class="btn" style="border:none;" disabled>
									<i class="fa-solid fa-arrow-right-long text-center"></i>
								</button>
								<button class="imageBtn btn hover-text p-0">
									<img src="<?php echo $subImagePath; ?> " class="border border-dark" alt="" width="30" />
									<span class="tooltip-text" id="right">
										<img src="<?php echo $subImagePath; ?>" alt="Image" width="170" />
									</span>
								</button>
								<button class="livebtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" data-id="<?php echo $subrow['id'];  ?>" >
									<i class="fa-regular <?php if($subrow['live'] == 1){ echo 'fa-eye'; }else{ echo 'fa-eye-slash';} ?>"></i>
								</button>
								<button class="editbtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit" data-id="<?php echo $subrow['id'] ?>" >
									<i class="fa-regular fa-pen-to-square"></i>
								</button>
								<button class="deletebtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete" data-id="<?php echo $subrow['id']; ?>" >
									<i class="fa-solid fa-trash"></i>
								</button>
							</div>
						</td>
						<td class="w-25">
							<a class="editWithTitle text-dark" href="editcategory.php?id=<?php echo $subrow['id']; ?>">
								<?php echo $subrow['title']; ?>
							</a>
						</td>
						<td class="w-50"><?php echo $subrow['description']; ?></td>
					</tr>
					<!-- For super-sub(products) category -->
					<?php
								}
							}
						}
					  }
					}else {
					?>
                    <tr><td colspan="3">No data inserted.</td></tr>
					<?php
				    	}
				    ?>
			</tbody>
		</table>
		<input type="button" value="ADD" class="addButton2 btn bg-danger text-white fw-bold" onclick="location.href='<?php echo ROOT_PATH;?>addcategory.php'"/>
	</div>
  </div>
</section>

<script>
<!--Edit-->
document.querySelectorAll('.editbtn').forEach(button => {
   button.addEventListener('click', function() {
		const id = this.getAttribute('data-id');
		window.location.href = "editcategory.php?id="+id;
	});
});
<!--Live toggle-->
document.querySelectorAll('.livebtn').forEach(button => {
  button.addEventListener('click', function() {
    const id = this.getAttribute('data-id');
	const button = this;
	$.ajax({
		type: 'POST',
		url: 'togglelivecategory.php',
		data: {id:id},
		dataType: 'json',
		success: function(response) {
			if (response.live == 1) {
				alertMessage =' Category is live';
				addAlert(alertMessage);
				button.querySelector('i').classList.remove('fa-eye-slash');
				button.querySelector('i').classList.add('fa-eye');
			} else {
				alertMessage =' Category is un-live'; 
				addAlert(alertMessage);
				button.querySelector('i').classList.remove('fa-eye');
				button.querySelector('i').classList.add('fa-eye-slash');
			}
		},
		error: function(xhr,status,error) {
			console.error(xhr.responseText);
		}
		});
	});
});
<!--live function to show alert box-->
function addAlert(message){
	const existingAlert = document.getElementById("liveAlert");
	if(existingAlert){
		existingAlert.remove();
	}
    let alert =
			'<div id="liveAlert" class="alert w-75 alert-secondary alert-dismissible fade show" role="alert">' +
            '<strong class="text-success">Success!</strong>' + message + '.' +
            '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>' +
			'</div>';
    const mytable = document.querySelector('.cmsBTable');
    mytable.insertAdjacentHTML('beforebegin', alert);
	<!-- Timeout to remove the AlertBoxx-->
	setTimeout(() => {
		document.getElementById("liveAlert").remove();
	},3000)
}
<!--Delete-->
document.querySelectorAll('.deletebtn').forEach(button => {
	button.addEventListener('click', function() {
		const id= this.getAttribute('data-id');
		if(confirm('Confirm to delete?')){
			window.location.href = "deletecategory.php?id="+id;
		}
	});
});
		
<!--Change live button status on hover -->
document.querySelectorAll('.livebtn').forEach(button => {
	button.addEventListener('mouseover',function() {
		const id = this.getAttribute('data-id');
		const button = this;
		$.ajax({
			type:'POST',
			url: 'getliveCategory.php',
			data :{id},
			dataType: 'json',
			success: function(response){
				if(response.live=='1'){
					const liveStatus = 'Live';
					button.setAttribute('title', liveStatus);
				}else if(response.live == '0'){
					const liveStatus ='Un-live';
					button.setAttribute('title', liveStatus);
				}
			},
			error: function(xhr,status,error) {
				console.error(xhr.responseText);
			}
		});
	});		
});
</script>

<?php 
	include('inc/footer.php');
?>
</html>