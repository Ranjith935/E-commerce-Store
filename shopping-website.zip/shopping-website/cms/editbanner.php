<?php  
	session_start(); 
	if(!isset($_SESSION['loggedin'])){
		header("Location: login.php");
		exit();
	}

 include('lib/connection.php');
 include_once('inc/defines.php');
 include('lib/banner-class.php');
 $banner = new Banner();

 
 // checking id
 $id = isset($_GET['id']) ? $_GET['id'] : null;
 $bannerData = null;

 if($id){
	$bannerData = $banner->getBannerById($id);
	// Retrieving the image using ABSOLUTE-PATH
	$imagePath = UPLOAD_PATH.'banners/'.$bannerData['image'];
 }
 //update the data
 if(isset($_POST['updateBannerData'])){
	 
	$username = $_SESSION['cms_username'];
	$sql= "SELECT id FROM cms_users where email ='$username'";
	$res = mysqli_query($conn,$sql);
	$user = mysqli_fetch_assoc($res);
	$userId = $user['id'];
	
	$title=$_POST['title'];
	$file = $_FILES['fileupload'];
	
	if(empty($title)){
		echo"<script>
		alert('Specify the Category Title!');
		window.location.href='editbanner.php?id=$id';
		</script>";
		exit();
	}
	$result = $banner->updateBannerData($id,$userId);
	if($result){
		$message=' Banner Updated Successfully!';
		echo "<script>
		window.location.href='banner.php?message=$message';
		</script>";
	}
	else{
		echo "<script>
		alert('Error: " . $conn->error . "');
		</script>";
	}
 }
 
?>
<!DOCTYPE html>
<html>
<body>
<!-- PAGE NAVBAR SECTION --> 
<?php
	include('inc/header.php') ;
?>

<section class="cmcASection">
<div class="container bg-secondary text-white">
	<div class="cmsContainer">
	<h4 class="fw-bold mb-4 text-center">Edit Banner</h4>
		<form class="addFrom" method="post" action="" enctype="multipart/form-data" >
			<div class="form-group row mb-3">
				<label for="title" class="col-sm-3 form-label fw-bold text-end">Title:</label>
				<div class="col-sm-8">
					<input type="text" class="form-control" id="title" name="title" value="<?php echo $bannerData['title'] ?>">
				</div>
			</div>
			
			<div class="form-group row mb-3">
				<label for="image" class="col-sm-3 form-label fw-bold text-end">Image:</label>
				<div class="displayImage w-25">
					<img src="<?php echo $imagePath;?>" width="480" >
				</div>
			</div>
			
			<div class="form-group row mb-3">
				<label for="fileupload" class="col-sm-3 form-label fw-bold text-end">Upload Image:</label>
				<div class="col-sm-4">
					<input type="file" class="form-control" id="fileupload" name="fileupload">
				</div>
				<div class="col-sm-2">
					<input type="text" class="form-control  bg-secondary text-white" width="40px" value="File size <= 5 MB" disabled>
				</div>
			</div>
			<div class="form-group row mb-3">
				<label for="" class="col-sm-3 form-label fw-bold text-end"></label>
				<div class="col-sm-3">
					<div class="form-check">
						<input class="form-check-input" type="checkbox" value="1" id="imageChecked" name="imageChecked" />
							<label class="form-check-label" for="imageChecked">
								Confirm to update image
							</label>
					</div>
				</div>
			</div>
			<div class="form-group row mb-3">
				<label for="bLiveyes" class="col-sm-3 form-label fw-bold text-end">Service is Live:</label>
				<div class="col-sm-1">
					<input class="form-check-input" type="radio" name="bLive" id="bLiveyes" value="1" <?php echo isset($bannerData['live']) && $bannerData['live']=='1' ? 'checked' : ''; ?> >
					<label class="form-check-label" for="bLiveoyes">Yes</label>
				</div>
				<div class="col-sm-1">
					<input class="form-check-input" type="radio" name="bLive" id="bLiveno" value="0" <?php echo isset($bannerData['live']) && $bannerData['live'] == '0' ? 'checked' : ''; ?> >
					<label class="form-check-label" for="bLiveno">No</label>
				</div>
			</div>
			<input type="button" value="Back" id="prevPage" class="prevPage btn bg-danger text-white fw-bold " onclick="location.href='banner.php'"/>
			<input type="submit" value="Update" id="updateBannerData" name="updateBannerData" class="updateBannerData btn bg-danger text-white fw-bold"/>
			
		</form>
	</div>
  </div>
</section>

<?php
	include('inc/footer.php');
?>
</body>
</html>