<?php
	session_start(); 
	if(!isset($_SESSION['loggedin'])){
		header("Location: login.php");
		exit();
	}
	include('lib/connection.php');
	
	$username = $_SESSION['cms_username'];
	$sqlquery= "SELECT id FROM cms_users WHERE email ='$username'";
	$res = mysqli_query($conn,$sqlquery);
	$user = mysqli_fetch_assoc($res);
	$userId = $user['id'];
	
	if (isset($_POST['id'])) {
		$id = $_POST['id'];
		
		$sql = "SELECT live FROM products WHERE id = $id";
		$result = mysqli_query($conn, $sql);
		$productData = mysqli_fetch_assoc($result);
		$currentLive = $productData['live'];
		
		if($currentLive == 0){
			$newLive=1;
		}elseif($currentLive ==1){
			$newLive=0;
		}
		$sqlUpdate = "UPDATE products SET
		`live` = '".$newLive."',
		`modified_by` = '".$userId."'
		WHERE id = $id";
		if (mysqli_query($conn, $sqlUpdate)) {
			$response = array('success' => true, 'live' => $newLive);
			echo json_encode($response);
		}else {
			$response = array('success' => false, 'error' => 'Failed to update live status');
			echo json_encode($response);
		}
	}else{
		$response = array('success' => false, 'error' => 'ID not provided');
		echo json_encode($response);
	}
?>