<?php  
	session_start(); 
	if(!isset($_SESSION['loggedin'])){
		header("Location: login.php");
		exit();
	}
include('lib/connection.php');
include('lib/category-class.php');
$category = new Category();
$message ='';
 
	$username = $_SESSION['cms_username'];
	$sql= "SELECT id FROM cms_users where email ='$username'";
	$res = mysqli_query($conn,$sql);
	$user = mysqli_fetch_assoc($res);
	$userId = $user['id'];
 
 
 // to add data
 if(isset($_POST['addBannerData'])){
	 
	$cat = $_POST['mainCategory'];
	$title=$_POST['title'];
	$description =$_POST['description'];
	
	if(empty($title)){
		echo"<script>
		alert('Specify the Category Title');
		window.location.href='addcategory.php';
		</script>";
		exit();
	}
	if(empty($description)){
		echo"<script>
		alert('Specify the Category Description');
		window.location.href='addcategory.php';
		</script>";
		exit();
	}
	
	$result = $category->insertCategoryData($userId);
	if($result){
		$message =' Category Added Successfully!';
			echo "<script>
			window.location.href='category.php?message=$message';
			</script>";
	}
	else{
		$message = ' Failed to add Category';
			echo"<script>
			window.location.href='category.php?message=$message';
			</script>";
	}
 }
?>


<!DOCTYPE html>
<html>
<body>
<!-- PAGE NAVBAR SECTION --> 
<?php
	include_once('inc/header.php');
?>
<!--ALERT BOX FOR LOGIN MISMATCH -->
<section class="cmcASection">
  <div class="container bg-secondary text-white">
	<div class="cmsContainer">
	<h4 class="fw-bold mb-4 text-center">Add Category</h4>
		<form class="addFrom" method="post" action="" enctype="multipart/form-data" >
			<div class="form-group row mb-3">
				<label for="category" class="col-sm-3 form-label fw-bold text-end">Category:</label>
				<div class="col-sm-8">
					<select class="text-center w-50" name="mainCategory">
						<option value="0">This is Main Category</option>
						<?php
							$mainCat = $category->parentIdQuery();
							if(mysqli_num_rows($mainCat)){
								while($row = mysqli_fetch_assoc($mainCat)){
						?>
							<option value="<?php echo $row['id']; ?>"><?php echo $row['title']; ?></option>
						<?php
								}
							}
						?>
					</select>
				</div>
			</div>
			<div class="form-group row mb-3">
				<label for="title" class="col-sm-3 form-label fw-bold text-end">Title:</label>
				<div class="col-sm-8">
					<input type="text" class="form-control" id="title" name="title"/>
				</div>
			</div>
			<div class="form-group row mb-3">
				<label for="description" class="col-sm-3 form-label fw-bold text-end">Description:</label>
				<div class="col-sm-8">
					<textarea class="form-control" id="description" name="description" rows="5"></textarea>
				</div>
			</div>
			<div class="form-group row mb-3">
				<label for="fileupload" class="col-sm-3 form-label fw-bold text-end">Upload Image:</label>
				<div class="col-sm-4">
					<input type="file" class="form-control" id="fileupload" name="fileupload"/>
				</div>
				<div class="col-sm-2">
					<input type="text"  class="form-control  bg-secondary text-white" width="40px" value="File size <= 5 MB" disabled />
				</div>
			</div>
			<div class="form-group row mb-3">
				<label for="title" class="col-sm-3 form-label fw-bold text-end">Font-Class:</label>
				<div class="col-sm-8 w-50">
					<input type="text" class="form-control" id="fontclass" name="fontclass"/>
				</div>
			</div>
			<div class="form-group row mb-3">
				<label for="bLiveyes" class="col-sm-3 form-label fw-bold text-end">Category is Live:</label>
				<div class="col-sm-1">
					<input class="form-check-input" type="radio" name="bLive" id="bLiveyes" value="1" checked />
					<label class="form-check-label" for="bLiveoyes">Yes</label>
				</div>
				<div class="col-sm-1">
					<input class="form-check-input" type="radio" name="bLive" id="bLiveno" value="0" />
					<label class="form-check-label" for="bLiveno">No</label>
				</div>
			</div>
			<input type="button" value="Back" id="prevPage" class="prevPage btn bg-danger text-white fw-bold " onclick="location.href='<?php echo ROOT_PATH; ?>category.php'"/>
			<input type="submit" value="Add" id="addBannerData" name="addBannerData" class="addBannerData btn bg-danger text-white fw-bold"/>
		</form>
	</div>
  </div>
</section>

<?php
	include('inc/footer.php');
?>
</body>
</html>