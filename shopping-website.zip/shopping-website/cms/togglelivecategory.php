<?php
	session_start(); 
	if(!isset($_SESSION['loggedin'])){
		header("Location: login.php");
		exit();
	}
	
	include('lib/connection.php');
	
	$username = $_SESSION['cms_username'];
	$sqlquery= "SELECT id FROM cms_users WHERE email ='$username'";
	$res = mysqli_query($conn,$sqlquery);
	$user = mysqli_fetch_assoc($res);
	$userId = $user['id'];
	
	if (isset($_POST['id'])) {
		$id = $_POST['id'];
		
		$sql = "SELECT live,parent_id FROM category WHERE id = $id";
		$result = mysqli_query($conn, $sql);
		$categoryData = mysqli_fetch_assoc($result);
		//$parentId = $categoryData['parent_id'];
		$currentLive = $categoryData['live'];
		// if($parentId==0 && $currentLive==1){
			// $sql = "UPDATE category SET live='0' WHERE parent_id = '$id'";
			// $res = mysqli_query($conn,$sql);
			// $newLive=1;
		// }
		if($currentLive == 0){
			$newLive=1;
		}elseif($currentLive ==1){
			$newLive=0;
		}
	
		$sqlUpdate = "UPDATE category SET live = $newLive,modified_by = $userId WHERE id = $id";
		if (mysqli_query($conn, $sqlUpdate)) {
			$response = array('success' => true, 'live' => $newLive);
			echo json_encode($response);
		}else {
			$response = array('success' => false, 'error' => 'Failed to update live status');
			echo json_encode($response);
		}
	}else {
		$response = array('success' => false, 'error' => 'ID not provided');
		echo json_encode($response);
	}
?>
