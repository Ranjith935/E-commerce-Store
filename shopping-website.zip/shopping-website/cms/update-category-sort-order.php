<?php
require_once('lib/connection.php');
 //For updating the sort id
if(isset($_POST['order'])) {
    $order = $_POST['order'];
    foreach($order as $sort_id => $id) {
        $query = "UPDATE category SET sort_id = $sort_id WHERE id = $id";
        mysqli_query($conn, $query);
    }
}
?>