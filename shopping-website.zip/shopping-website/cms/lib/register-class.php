<?php
	class Register{
		public function checkRegister($fname, $lname, $pnumber, $email, $password){
			global $conn;	
			$check_sql = "SELECT * FROM cms_users WHERE email='$email' OR phone_number = '$pnumber'";
			$check_result = mysqli_query($conn, $check_sql);
			$check_count = mysqli_num_rows($check_result);
		
			if($check_count > 0){
				return "failed" ;
			} else {
				$sql = "INSERT INTO cms_users SET
				`email` = '".$email."',
				`password` = '".$password."'";
			
			$result = mysqli_query($conn, $sql);
			return "successful";
			}
	}
}
?>