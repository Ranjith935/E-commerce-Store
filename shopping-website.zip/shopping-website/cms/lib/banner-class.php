<?php
	class Banner{
		public function insertBannerData($userId){
			global $conn;
			$title=$_POST['title'];
		
			$bLive = $_POST['bLive'];
			$ip = $_SERVER['REMOTE_ADDR'];
			
			include('inc/uploadBanner.php');
			$target_file = uploadFile($_FILES['fileupload']);
			
			$sql="INSERT INTO banner SET
				`title`='".$title."',
				`image`='".$target_file."', 
				`live`='".$bLive."', 
				`ip_address`='".$ip."',
				`created_by` = '".$userId."' ";
				
			$result = mysqli_query($conn,$sql);
			return $result;
	   }
		
		// For banner.php to load the data from table
		public function selectBannerData(){
			global $conn;
			$query = "SELECT id,title,live FROM banner WHERE delete_id='0'";
			$result = mysqli_query($conn,$query);
			return $result;
		}
		// to display the banner image.
		public function showImage($title){
			global $conn;
			$query = "SELECT image FROM banner WHERE title = '$title'";
			$result = mysqli_query($conn,$query);
			$row = mysqli_fetch_assoc($result);
			return $row['image'];
		}
		// to fetch all data using banner id for edit.
		public function getBannerById($id){
			global $conn;
			$query = "SELECT * FROM banner WHERE id = '$id'";
			$result = mysqli_query($conn,$query);
			$row = mysqli_fetch_assoc($result);
			return $row;
		}
		//to update the banner data through edit.
		public function updateBannerData($id,$userId){
			global $conn;
			$title=$_POST['title'];
			$bLive = $_POST['bLive'];
			$ip = $_SERVER['REMOTE_ADDR'];
			$imagecheck = isset($_POST['imageChecked']) ? $_POST['imageChecked'] : null;
			
			// Checkbox condition for image upload
			if (($imagecheck == '1') && (!empty($_FILES['fileupload']))) {
				include('inc/uploadBanner.php');
				$target_file = uploadFile($_FILES['fileupload']);
			}else {
				$query = "SELECT `image` FROM banner WHERE id='$id'";
				$result = mysqli_query($conn, $query);
				$row = mysqli_fetch_assoc($result);
				$target_file = $row['image'];
			}
			$query = "UPDATE banner SET
				`title`='".$title."',
				`image`='".$target_file."',
				`live`='".$bLive."',
				`ip_address`='".$ip."',
				`modified_by`='".$userId."'
				WHERE id ='$id'";
				$result = mysqli_query($conn,$query);
				return $result;
		  }		
		// delete the banner item
		public function deleteBannerData($id,$userId){
			global $conn;
			$sql = "UPDATE banner SET 
				`delete_id` = '1',
				`modified_by` = '".$userId."'
				WHERE id = '".$id."'";
			$result = mysqli_query($conn,$sql);
			return $result;
		}
	}
?>

