<?php
	class Product{
		public function insertProductData($userId){
			global $conn;
			$cat = $_POST['mainCategory'];
			$title=$_POST['title'];
			$description = $_POST['description'];
			$price = mysqli_real_escape_string($conn,$_POST['productPrice']);
			$bLive = $_POST['bLive'];
			$ip = $_SERVER['REMOTE_ADDR'];
			
			include('inc/uploadProducts.php');
			$target_file = uploadFile($_FILES['fileupload']);
			if (!empty($cat)) {
				$sql="INSERT INTO products SET
					`title`='".$title."',
					`description`='".$description."',
					`image`='".$target_file."',
					`price`='".$price."',
					`live`='".$bLive."',
					`ip_address`='".$ip."',
					`created_by` = '".$userId."' ";
				$result = mysqli_query($conn,$sql);
				//to store the id of product
				$prod_id = mysqli_insert_id($conn);
				foreach ($cat as $option){
				//to add details to join table for each selected category
					$joinTableQuery="INSERT INTO prod_cat_join SET
						prod_id='".$prod_id."',
						cat_id='".$option."'";
					$joinRes = mysqli_query($conn,$joinTableQuery);
				}
				if($joinRes){
					return $result;
				}
			}
		}
		// For category.php to load the data from table
		public function selectProductData(){
			global $conn;
			$query = "SELECT id, title, description,live FROM products WHERE delete_id='0'";
			$result = mysqli_query($conn,$query);
			return $result;
		}
		//To display all the main category
		// public function parentIdQuery(){
			// global $conn;
			// $query = "SELECT id,title, description,live FROM category WHERE delete_id='0' AND parent_id !='0'";
			// $result = mysqli_query($conn,$query);
			// return $result;
		// }
		// to display the product image.
		public function showImage($id){
			global $conn;
			$query = "SELECT image FROM products WHERE id = '$id'";
			$result = mysqli_query($conn,$query);
			$row = mysqli_fetch_assoc($result);
			return $row['image'];
		}
		//to get main category(cricket..) usind fk_cid
		public function productMainCategory($id){
			global $conn;
			//getting category_id's from product_id then pass each category_id to category table to get the category title
			$catIdQuery = "SELECT cat_id FROM prod_cat_join WHERE prod_id ='$id'";
			$catIdResult =mysqli_query($conn,$catIdQuery);
			if($catIdResult && mysqli_num_rows($catIdResult)>0){
				$categoryTitles=[];
				while($catRow = mysqli_fetch_assoc($catIdResult)){
					$catId = $catRow['cat_id'];
					//to get the individual title using cat_id
					$titleQuery="SELECT title FROM category WHERE id='$catId'";
					$titleResult = mysqli_query($conn,$titleQuery);
					if($titleResult && mysqli_num_rows($titleResult)>0){
						$titleRow= mysqli_fetch_assoc($titleResult);
						$categoryTitles[] = $titleRow['title'];
					}
				}
				return $categoryTitles;
			}else{
				return [];
			}
		}
		//to fetch the main category using product_id and return the title and id from category
		public function getMainCategoryByProductId($id){
			global $conn;
				$joinQuery ="SELECT cat_id FROM prod_cat_join WHERE prod_id='$id'";
				$joinQueryResult = mysqli_query($conn,$joinQuery);
				$mainCatRow=[];
				if($joinQueryResult && mysqli_num_rows($joinQueryResult)>0){
					while($catRow = mysqli_fetch_assoc($joinQueryResult)){
					$catId = $catRow['cat_id'];
					//to get the individual title using cat_id
					$mainCatQuery="SELECT id,title FROM category WHERE id='$catId'";
					$mainCatResult = mysqli_query($conn,$mainCatQuery);
						if($mainCatResult && mysqli_num_rows($mainCatResult)>0){
							$mainCatRow[]= mysqli_fetch_assoc($mainCatResult);
						}
					}	
				}
				return $mainCatRow;
			}
		//to fetch the sub category using parent_id
		public function getSubCategoryByParentId($parentId){
			global $conn;
		        $query = "SELECT * FROM category WHERE id = '$parentId'";
		        $result = mysqli_query($conn,$query);
		        $row = mysqli_fetch_assoc($result);
		        return $row;
		}
		// to fetch all data using category id for edit.
		public function getProductById($id){
			global $conn;
			$query = "SELECT * FROM products WHERE id = '$id'";
			$result = mysqli_query($conn,$query);
			$row = mysqli_fetch_assoc($result);
			return $row;
		}
		//to fetch all the other category for edit page
		public function getAllMainCategory($productId){
			global $conn;
			$query = "SELECT * FROM category 
					WHERE id NOT IN (SELECT cat_id FROM prod_cat_join WHERE prod_id='$productId')
					AND parent_id != '0'
					AND delete_id !='1'";
			$result = mysqli_query($conn,$query);
			return $result;
		}
		//to update the category data through edit.
		public function updateProductData($id,$userId){
			global $conn;
			$cat = $_POST['mainCategory'];
			$title=$_POST['title'];
			$description = mysqli_real_escape_string($conn,$_POST['description']);
			$price = mysqli_real_escape_string($conn,$_POST['productPrice']);
			$bLive = $_POST['bLive'];
			$ip = $_SERVER['REMOTE_ADDR'];
			$imagecheck = isset($_POST['imageChecked']) ? $_POST['imageChecked'] : null;
			
			// Checkbox condition for image upload
			if (($imagecheck == '1') && (!empty($_FILES['fileupload']))) {
				include('inc/uploadProducts.php');
				$target_file = uploadFile($_FILES['fileupload']);
			}else {
				$query = "SELECT `image` FROM products WHERE id='$id'";
				$result = mysqli_query($conn, $query);
				$row = mysqli_fetch_assoc($result);
				$target_file = $row['image'];
			}
			//if category is selected then first delete that product and then insert in join table
			//delete and insert everytime
			if(!empty($cat)){
				$sql = "UPDATE products SET
					`title`='".$title."',
					`description`='".$description."',
					`image`='".$target_file."',
					`price` ='".$price."',
					`live`='".$bLive."',
					`ip_address`='".$ip."',
					`modified_by`='".$userId."'
				WHERE id ='$id'";
				$result = mysqli_query($conn,$sql);
				//delete the product info from join table
				$query ="DELETE FROM prod_cat_join
						WHERE prod_id='".$id."'";
				$delResult = mysqli_query($conn,$query);
					foreach ($cat as $option){
					//to add details to join table for each selected category
						$joinTableQuery="INSERT INTO prod_cat_join SET
							prod_id='".$id."',
							cat_id='".$option."'";
						$joinRes = mysqli_query($conn,$joinTableQuery);
					}
				}
				return $result;
			}
		//delete the product item from 2 tables
		public function deleteProductData($id,$userId){
			global $conn;
			$joinDeleteQuery = "DELETE FROM prod_cat_join
				WHERE prod_id='".$id."' ";
			$joinDeleteResult = mysqli_query($conn,$joinDeleteQuery);
			$sql = "UPDATE products SET
				`delete_id` = '1',
				`modified_by` = '".$userId."'
				WHERE id = '".$id."'";
			$result = mysqli_query($conn,$sql);
			return $result;
		}
	}
?>