<?php
	class Category{
		public function insertCategoryData($userId){
			global $conn;
			$cat = $_POST['mainCategory'];
			$title=$_POST['title'];
			$description = $_POST['description'];
			$fontclass = mysqli_real_escape_string($conn,$_POST['fontclass']);
			
			$bLive = $_POST['bLive'];
			$ip = $_SERVER['REMOTE_ADDR'];
			
			include('inc/uploadCategory.php');
			$target_file = uploadFile($_FILES['fileupload']);
			if($cat == '0'){
				$sql="INSERT INTO category SET
				`parent_id` ='".$cat."',
				`title`='".$title."',
				`description`='".$description."',
				`image`='".$target_file."',
				`font_class`='".$fontclass."', 
				`live`='".$bLive."', 
				`ip_address`='".$ip."',
				`created_by` = '".$userId."' ";
				$result = mysqli_query($conn,$sql);
				return $result;
			}else{
	              $sql="INSERT INTO category SET
	              	`parent_id` ='".$cat."',
	              	`title`='".$title."',
	              	`description`='".$description."',
	              	`image`='".$target_file."',
	              	`font_class`='".$fontclass."',
	              	`live`='".$bLive."',
	              	`ip_address`='".$ip."',
	              	`created_by` = '".$userId."' ";
	              $result = mysqli_query($conn,$sql);
	              return $result;
			}
		}
		// For category.php to load the data from table
		public function selectCategoryData(){
			global $conn;
			$query = "SELECT id, parent_id, title, description,live FROM category WHERE delete_id='0' ORDER BY sort_id";
			$result = mysqli_query($conn,$query);
			return $result;
		}
		//To display all the main category
		public function parentIdQuery(){
			global $conn;
			$query = "SELECT id,title, description,live FROM category WHERE delete_id='0' AND parent_id='0'";
			$result = mysqli_query($conn,$query);
			return $result;
		}
		// to display the category image.
		public function showImage($id){
			global $conn;
			$query = "SELECT image FROM category WHERE id ='$id'";
			$result = mysqli_query($conn,$query);
			$row = mysqli_fetch_assoc($result);
			return $row['image'];
		}
		public function showProductImage($id){
			global $conn;
			$query ="SELECT image FROM products WHERE id ='$id'";
			$result = mysqli_query($conn,$query);
			$row = mysqli_fetch_assoc($result);
			return $row['image'];
		}
		//to fetch the main category using parent_id
		public function getMainCategoryByParentId($parentId){
			global $conn;
			if($parentId!='0'){
		        $query = "SELECT * FROM category WHERE id = '$parentId'";
		        $result = mysqli_query($conn,$query);
		        $row = mysqli_fetch_assoc($result);
		        return $row;
		   }else if($parentId=='0'){
				$row['title']='This is the Main Category';
				return $row;
		   }
		}
		//to fetch the sub category using parent_id
		public function getSubCategoryByParentId($parentId){
			global $conn;
		        $query = "SELECT * FROM category WHERE id = '$parentId'";
		        $result = mysqli_query($conn,$query);
		        $row = mysqli_fetch_assoc($result);
		        return $row;
		}
		// to fetch all data using category id for edit.
		public function getCategoryById($id){
			global $conn;
			$query = "SELECT * FROM category WHERE id = '$id'";
			$result = mysqli_query($conn,$query);
			$row = mysqli_fetch_assoc($result);
			return $row;
		}
		//to fetch all products under specific Category
		public function getProductsForCategory($id){
			global $conn;
			$query="SELECT * FROM products
				WHERE id IN(SELECT prod_id FROM prod_cat_join 
				WHERE cat_id ='$id') ORDER BY sort_id";
			$result = mysqli_query($conn,$query);
			return $result;
		}
		//to update the category data through edit.
		public function updateCategoryData($id,$userId){
			global $conn;
			$title=$_POST['title'];
			$description = mysqli_real_escape_string($conn,$_POST['description']);
			$fontclass = mysqli_real_escape_string($conn,$_POST['fontclass']);
			$bLive = $_POST['bLive'];
			$ip = $_SERVER['REMOTE_ADDR'];
			$imagecheck = isset($_POST['imageChecked']) ? $_POST['imageChecked'] : null;
			
			// Checkbox condition for image upload
			if (($imagecheck == '1') && (!empty($_FILES['fileupload']))) {
				include('inc/uploadCategory.php');
				$target_file = uploadFile($_FILES['fileupload']);
			}else {
				$query = "SELECT `image` FROM category WHERE id='$id'";
				$result = mysqli_query($conn, $query);
				$row = mysqli_fetch_assoc($result);
				$target_file = $row['image'];
			}
			$query = "UPDATE category SET
				`title`='".$title."',
				`description`='".$description."',
				`image`='".$target_file."',
				`font_class` ='".$fontclass."',
				`live`='".$bLive."',
				`ip_address`='".$ip."',
				`modified_by`='".$userId."'
				WHERE id ='$id'";
				$result = mysqli_query($conn,$query);
				return $result;
		  }
		// delete the category item
		public function deleteCategoryData($id,$userId){
			global $conn;
			$sql = "UPDATE category SET
				`delete_id` = '1',
				`modified_by` = '".$userId."'
				WHERE id = '".$id."'";
			$result = mysqli_query($conn,$sql);
			return $result;
		}
	}
?>