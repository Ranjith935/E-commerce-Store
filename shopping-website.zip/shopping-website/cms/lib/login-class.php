<?php
class Login{
	public function checkLoginData($email,$password){
		global $conn;
		$sql = "SELECT * FROM cms_users WHERE email ='$email' AND password ='$password'";
		$result = mysqli_query($conn,$sql);
		$count = mysqli_num_rows($result);
		if($count>0){
			return "successful";
		}else{
			return "failed";
		}
	}
}
?>