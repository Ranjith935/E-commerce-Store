<?php  
	session_start(); 
	if(!isset($_SESSION['loggedin'])){
		header("Location: login.php");
		exit();
	}
include('lib/connection.php');
include('lib/banner-class.php');
$banner = new Banner();
 
	$username = $_SESSION['cms_username'];
	$sql= "SELECT id FROM cms_users where email ='$username'";
	$res = mysqli_query($conn,$sql);
	$user = mysqli_fetch_assoc($res);
	$userId = $user['id'];
 
 
 // to add data
 if(isset($_POST['addBannerData'])){
	
	$title=$_POST['title'];
	$file = $_FILES['fileupload'];
	
	if(empty($title)){
		echo"<script>
		alert('Specify the Banner Title!');
		window.location.href='addbanner.php';
		</script>";
		exit();
	}
	if($file['size']==0){
		echo"<script>
		alert('Upload the Image!');
		window.location.href='addbanner.php';
		</script>";
		exit();
	}
	
	$result = $banner->insertBannerData($userId);
	if($result){
		echo "<script>
		alert('Banner added Successfully.');
		window.location.href='banner.php';
		</script>";
	}
	else{				
		echo "<script>
		alert('Error: " . $conn->error . "');
		</script>";
	}
 }
?>


<!DOCTYPE html>
<html>
<body>
<!-- PAGE NAVBAR SECTION --> 
<?php
	include_once('inc/header.php');
?>
<section class="cmcASection">
  <div class="container bg-secondary text-white">
	<div class="cmsContainer">
	<h4 class="fw-bold mb-4 text-center">Add Banner</h4>
		<form class="addFrom" method="post" action="" enctype="multipart/form-data" >
			<div class="form-group row mb-3">
				<label for="title" class="col-sm-3 form-label fw-bold text-end">Title:</label>
				<div class="col-sm-8">
					<input type="text" class="form-control" id="title" name="title"/>
				</div>
			</div>
			<div class="form-group row mb-3">
				<label for="fileupload" class="col-sm-3 form-label fw-bold text-end">Upload Image:</label>
				<div class="col-sm-4">
					<input type="file" class="form-control" id="fileupload" name="fileupload"/>
				</div>
				<div class="col-sm-2">
					<input type="text"  class="form-control  bg-secondary text-white" width="40px" value="File size <= 5 MB" disabled />
				</div>
			</div>
			<div class="form-group row mb-3">
				<label for="bLiveyes" class="col-sm-3 form-label fw-bold text-end">Banner is Live:</label>
				<div class="col-sm-1">
					<input class="form-check-input" type="radio" name="bLive" id="bLiveyes" value="1" checked />
					<label class="form-check-label" for="bLiveoyes">Yes</label>
				</div>
				<div class="col-sm-1">
					<input class="form-check-input" type="radio" name="bLive" id="bLiveno" value="1" />
					<label class="form-check-label" for="bLiveno">No</label>
				</div>
			</div>
			<input type="button" value="Listing Page" id="prevPage" class="prevPage btn bg-danger text-white fw-bold " onclick="location.href='banner.php'"/>
			<input type="submit" value="Add" id="addBannerData" name="addBannerData" class="addBannerData btn bg-danger text-white fw-bold"/>
			
		</form>
	</div>
  </div>
</section>

<?php
	include('inc/footer.php');
?>
</body>
</html>