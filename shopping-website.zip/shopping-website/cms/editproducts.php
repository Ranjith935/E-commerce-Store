<?php  
	session_start(); 
	if(!isset($_SESSION['loggedin'])){
		header("Location: login.php");
		exit();
	}

 include('lib/connection.php');
 include_once('inc/defines.php');
 include('lib/products-class.php');
 $product = new Product();
 $message ='';
 
 // checking id
 $id = isset($_GET['id']) ? $_GET['id'] : null;
 $productData = null;

 if($id){
	$productData = $product->getProductById($id);
	// Retrieving the image using ABSOLUTE-PATH
	$imagePath = UPLOAD_PATH.'products/'.$productData['image'];
 }
 //update the data
 if(isset($_POST['updateBannerData'])){
	 
	$username = $_SESSION['cms_username'];
	$sql= "SELECT id FROM cms_users where email ='$username'";
	$res = mysqli_query($conn,$sql);
	$user = mysqli_fetch_assoc($res);
	$userId = $user['id'];
	
	$cat = $_POST['mainCategory'];
	$title=$_POST['title'];
	$description = $_POST['description']; 
	if(empty($cat)){
		$message='Select the Category';
		echo"<script>
		window.location.href='editproduct.php?id=$id&message=$message;
		</script>";
	}
	if(empty($title)){
		echo"<script>
		alert('Specify the Title');
		window.location.href='editproducts.php?id=$id';
		</script>";
		exit();
	}
	if(empty($description)){
		echo"<script>
		alert('Specify the Description');
		window.location.href='editproducts.php?id=$id';
		</script>";
		exit();
	}
	$result = $product->updateProductData($id,$userId);
	if($result){
		$message=' Product Updated Successfully!';
			echo "<script>
			window.location.href='products.php?message=$message';
			</script>";
	}
	else{
		$message = 'Failed to Update Category';
			echo"<script>
				window.location.href='products.php?message=$message';
				</script>";
		}
 }
 
?>
<!DOCTYPE html>
<html>
<body>
<!-- PAGE NAVBAR SECTION --> 
<?php
	include('inc/header.php');
?>
<section class="cmcASection">
<div class="container bg-secondary text-white">
	<div class="cmsContainer">
	<h4 class="fw-bold mb-4 text-center">Edit Product</h4>
		<form class="addFrom" method="post" action="" enctype="multipart/form-data" >
			<div class="form-group row mb-3">
				<label for="mainCategory" class="col-sm-3 form-label fw-bold text-end">Category:</label>
				<div class="col-sm-8">
					<select class="text-center w-50 p-1" name="mainCategory[]" size="6" multiple>
					<!--Display the category which are selected previously here-->
					<?php
					$mainCategory = $product->getMainCategoryByProductId($productData['id']);
						foreach($mainCategory as $category){
					?>
						<option class="border" value="<?php echo $category['id']; ?>" selected><?php echo $category['title']; ?></option>
					<?php
						}
					?>
					<?php
					//other categoris which are not previously selected
						$otherMainCategory = $product->getAllMainCategory($productData['id']);
						if(mysqli_num_rows($otherMainCategory)>0){
							while($otherRow = mysqli_fetch_assoc($otherMainCategory)){
					?>
						<option class="border" value="<?php echo $otherRow['id']; ?>"><?php echo $otherRow['title']; ?></option>
					<?php
							}
						}
					?>
					</select>
				</div>
			</div>
			<div class="form-group row mb-3">
				<label for="title" class="col-sm-3 form-label fw-bold text-end">Title:</label>
				<div class="col-sm-8">
					<input type="text" class="form-control" id="title" name="title" value="<?php echo $productData['title'] ?>">
				</div>
			</div>
			<div class="form-group row mb-3">
				<label for="description" class="col-sm-3 form-label fw-bold text-end">Description:</label>
				<div class="col-sm-8">
					<textarea class="form-control" id="description" name="description" rows="5"><?php echo $productData['description'] ?></textarea>
				</div>
			</div>
			<div class="form-group row mb-3">
				<label for="image" class="col-sm-3 form-label fw-bold text-end">Image:</label>
				<div class="displayImage w-25">
					<img src="<?php echo $imagePath;?>" width="250" >
				</div>
			</div>
			<div class="form-group row mb-3">
				<label for="fileupload" class="col-sm-3 form-label fw-bold text-end">Upload Image:</label>
				<div class="col-sm-4">
					<input type="file" class="form-control" id="fileupload" name="fileupload">
				</div>
				<div class="col-sm-2">
					<input type="text"  class="form-control  bg-secondary text-white" width="40px" value="File size <= 5 MB" disabled>
				</div>
			</div>
			<div class="form-group row mb-3">
				<label for="" class="col-sm-3 form-label fw-bold text-end"></label>
				<div class="col-sm-3">
					<div class="form-check">
						<input class="form-check-input" type="checkbox" value="1" id="imageChecked" name="imageChecked" />
							<label class="form-check-label" for="imageChecked">
								Confirm to update image
							</label>
					</div>
				</div>
			</div>
			<div class="form-group row mb-3">
				<label for="productPrice" class="col-sm-3 form-label fw-bold text-end">Price (INR):</label>
				<div class="col-sm-8 w-50">
					<input type="text" class="form-control" id="productPrice" name="productPrice" value="<?php echo $productData['price'] ?>"/>
				</div>
			</div>
			<div class="form-group row mb-3">
				<label for="bLiveyes" class="col-sm-3 form-label fw-bold text-end">Product is Live:</label>
				<div class="col-sm-1">
					<input class="form-check-input" type="radio" name="bLive" id="bLiveyes" value="1" <?php echo isset($productData['live']) && $productData['live']=='1' ? 'checked' : ''; ?> >
					<label class="form-check-label" for="bLiveoyes">Yes</label>
				</div>
				<div class="col-sm-1">
					<input class="form-check-input" type="radio" name="bLive" id="bLiveno" value="0" <?php echo isset($productData['live']) && $productData['live'] == '0' ? 'checked' : ''; ?> >
					<label class="form-check-label" for="bLiveno">No</label>
				</div>
			</div>
			<input type="button" value="Back" id="prevPage" class="prevPage btn bg-danger text-white fw-bold " onclick="location.href='<?php echo ROOT_PATH; ?>products.php'"/>
			<input type="submit" value="Update" id="updateBannerData" name="updateBannerData" class="updateBannerData btn bg-danger text-white fw-bold"/>
		</form>
	</div>
  </div>
</section>

<?php
	include('inc/footer.php');
?>

</body>
</html>