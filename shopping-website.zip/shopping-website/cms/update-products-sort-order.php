<?php
require_once 'lib/connection.php';
 
if(isset($_POST['order'])) {
    $order = $_POST['order'];
    foreach($order as $sort_id => $id) {
        $query = "UPDATE products SET sort_id = $sort_id WHERE id = $id";
        mysqli_query($conn, $query);
    }
}
?>