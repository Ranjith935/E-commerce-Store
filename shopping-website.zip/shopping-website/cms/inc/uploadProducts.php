<?php
//for banners image upload
include('lib/class.upload.php');
use Verot\Upload\Upload;

function uploadFile($file) {
    $handle = new Upload($file);
    if ($handle->uploaded) {
        // File size in bytes (50-Lakh byte is 5-MB)
        if ($handle->file_src_size > 5000000) {
            echo "<script>alert('Image size is too large');</script>";
            exit();
        }

        $mxdim = 1920;
        $mydim = 560;
        $x = $handle->image_src_x;
        $y = $handle->image_src_y;

        $handle->image_resize = true;
		if ($x > $y) {
			if ($x > $mxdim) {
				$handle->image_x = $mxdim;
				$handle->image_ratio_y = true;
				echo"<script> 
					alert('Modified width :'+ $handle->image_x);
					</script>";
			}else {
				$handle->image_resize = false;
			}
		}elseif ($y > $x) {
			if ($y > $mydim) {
				$handle->image_y = $mydim;
				$handle->image_ratio_x = true;
				echo"<script>
					alert('Modified height :'+ $handle->image_y);
					</script>";
			}else {
				$handle->image_resize = false;
			}
		}
        $file_extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $new_filename = time();
        $target_file = $new_filename .'.'. $file_extension;
		
        $handle->file_new_name_body = $new_filename;
		$handle->process('../uploads/products/');
		
        if ($handle->processed){
            $handle->clean();
            return $target_file;
        } else {
            echo "<script>alert('Target file error: " . $handle->error . "');</script>";
        }
    }
    return false;
}
?>