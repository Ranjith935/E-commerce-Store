<?php
	//FOR UPLOAD
	$siteFolder = 'shopping-website';
	define("UPLOAD_PATH",'/'.$siteFolder.'/uploads/');
	
	//FOR ABSOLUTE PATH 
	define("ROOT_PATH",'http://localhost:90/shopping-website/cms/');
	//FOR CSS
	define("CSS_PATH",'/'.$siteFolder.'/cms/css/');
	
	//FOR JS
	define("JS_PATH",'/'.$siteFolder.'/cms/js/');
?>