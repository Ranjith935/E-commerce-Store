<footer class="footerSection bg-info">
	 <div class="row bg-info text-dark lastRow text-center">
		<p>@ 2024 All Rights Reserved. By SportGearHub Wordpress Templates By DesignTM</p>
	</div>
</footer>