<?php
	include('lib/connection.php');
?>
<?php
	include_once('inc/defines.php');
?>
<head>
 <title>SPORTS-SHOP WEBSITE</title>
    <meta name="description" content="It is a Sports-Gear shopping website, which contains all premium products!"/>
	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<link rel="stylesheet" href="<?php echo CSS_PATH;?>bootstrap.min.css"/>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/> 
	<link rel="stylesheet" href="<?php echo CSS_PATH;?>style.css"/>
	<script type="text/javascript" src="<?php echo JS_PATH; ?>bootstrap.bundle.min.js"></script>
	<script type="text/javascript" src="<?php echo JS_PATH; ?>jquery-2.1.3.min.js"></script>
	<link rel="stylesheet" href="https://code.jquery.com/ui/1.13.3/themes/base/jquery-ui.css">
</head>

<header class="headerSection sticky-top">
<nav class="mainNavbar navbar container-fluid bg-info">

	<nav class="firstnav navbar navbar-expand-lg bg-info text-white">
		<div class="container">
			<a class="navbar-brand fw-bold" href="<?php echo ROOT_PATH; ?>home.php"><i>SportsGearHub</i></a>
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent" aria-controls="navbarContent" aria-expanded="false">
				<span class="navbar-toggler-icon"></span>
			</button>

			<div class="collapse navbar-collapse " id="navbarContent">
			<div class="container w-75 mt-4 ps-0">
				<!--<form class="d-flex" role="search">
				<input class="form-control" type="search" placeholder="Search for Gears..." aria-label="Search">
					<button class="btn btn-outline-dark" type="submit">Search</button>
				</form> -->
			</div>
				<ul class="navbar-nav">
					<!--<li class="nav-item">
						<a class=" fw-bold text-dark nav-link ps-4 me-2" href="">CART <i class="fa-solid fa-cart-shopping"></i></a>
					</li> -->
					<li class="nav-item">
						<a class="fw-bold text-dark nav-link ps-4" href="<?php echo ROOT_PATH;?>logout.php">LOGOUT <i class="fa-solid fa-user"></i></a>
					</li>
				</ul>
			</div>
		</div>
	</nav>
	<nav class="secondnav navbar">
				<button class="btn fw-bold text-dark" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample" aria-controls="offcanvasExample">
						MENU <span class="menuIcon navbar-toggler-icon"></span>
				</button>
					<div class="offcanvas offcanvas-end bg-info" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
						<div class="offcanvas-header">
							<h5 class="offcanvas-title fw-bold" id="offcanvasExampleLabel"><u>Menu List</u></h5>
							<button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
						</div>
						 <div class="offcanvas-body">
							<div class="mt-3">
								<button class="w-75 btn btn-secondary text-start">
									<i class="fa-solid fa-house-chimney"></i> <a class="text-white" href="<?php echo ROOT_PATH;?>home.php" style="text-decoration:none;">DASHBOARD</a>
								</button>
								<!--<ul class="dropdown-menu bg-warning w-75" aria-labelledby="dropdownMenuButton">
									<li><a class="dropdown-item" href="<?php echo ROOT_PATH;?>category.php"> CATEGORY LIST</a></li>
									<li><a class="dropdown-item" href="<?php echo ROOT_PATH;?>banner.php">BANNER LIST</a></li>
									<li><a class="dropdown-item" href="#">HOME PRODUCTS LIST</a></li>
								</ul>-->
							</div>
							<div class="mt-3">
								<button class="w-75 btn btn-secondary text-start">
									<i class="fa-solid fa-images"></i> <a class="text-white" href="<?php echo ROOT_PATH;?>banner.php" style="text-decoration:none;">BANNERS</a>
								</button>
							</div>
							<div class="mt-3">
								<button class="w-75 btn btn-secondary text-start">
									<i class="fa-solid fa-layer-group"></i> <a class="text-white" href="<?php echo ROOT_PATH;?>category.php" style="text-decoration:none;">CATEGORIES</a>
								</button>
							</div>
							<div class="mt-3">
								<button class="w-75 btn btn-secondary text-start">
									<i class="fa-solid fa-sitemap"></i> <a class="text-white" href="<?php echo ROOT_PATH;?>products.php" style="text-decoration:none;">PRODUCTS</a>
								</button>
							</div>
							<!--<div class="dropdown mt-3">
								<button class="w-75 btn btn-secondary dropdown-toggle text-start" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
									<i class="fa-solid fa-layer-group"></i> CATEGORIES
								</button>
								<ul class="dropdown-menu bg-warning w-50" aria-labelledby="dropdownMenuButton">
                                   <li class="nav-item dropdown dropend">
                                       <a class="dropdown-item dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" onclick="event.stopPropagation();"><i class="fa-solid fa-person-shelter"></i>  INDOOR</a>
                                       <ul class="dropdown-menu bg-warning">
                                           <li><a class="dropdown-item" href="#"><i class="fa-brands fa-space-awesome"></i>  BADMINTON</a></li>
                                           <li><a class="dropdown-item" href="#"><i class="fa-solid fa-basketball"></i>  BASKETBALL</a></li>
										   <li><a class="dropdown-item" href="#"><i class="fa-solid fa-table-tennis-paddle-ball"></i>  TENNIS</a></li>
                                       </ul>
                                   </li>
                                   <li class="nav-item dropdown dropend">
                                       <a class="dropdown-item dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" onclick="event.stopPropagation();"><i class="fa-solid fa-land-mine-on"></i> OUTDOOR</a>
                                       <ul class="dropdown-menu bg-warning">
                                           <li><a class="dropdown-item" href="#"><i class="fa-solid fa-baseball-bat-ball"></i>  CRICKET</a></li>
                                           <li><a class="dropdown-item" href="#"><i class="fa-solid fa-futbol"></i>  FOOTBALL</a></li>
                                           <li><a class="dropdown-item" href="#"><i class="fa-solid fa-wand-sparkles"></i>  HOCKEY</a></li>
                                       </ul>
                                   </li>
                               </ul>
							</div> -->
							<div class="dropdown mt-3">
								<button class="w-75 btn btn-secondary dropdown-toggle text-start" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown">
									<i class="fas fa-user mx-1"></i> PROFILE
								</button>
								<ul class="dropdown-menu bg-warning w-50" aria-labelledby="dropdownMenuButton">
									<!--<li><a class="dropdown-item" href="#"><i class="fa-solid fa-id-card-clip"></i>  My account</a></li>-->
									<!--<li><a class="dropdown-item" href="#"><i class="fa-solid fa-box-open"></i>  Orders</a></li>
									<li><a class="dropdown-item" href="#"><i class="fa-solid fa-address-book"></i>  Address</a></li> -->
									<li><a class="dropdown-item" name="logout" href="<?php echo ROOT_PATH;?>logout.php"><i class="fa-solid fa-right-from-bracket"></i>  Log out</a></li>
								</ul>
							</div>
						</div>
					</div>
	</nav>
</nav>
</header>