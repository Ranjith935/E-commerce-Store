<?php
session_start();
if(!isset($_SESSION['loggedin'])){
    header("Location: login.php");
    exit();
}
include('lib/connection.php');
include('lib/products-class.php');
$product = new Product();

if(isset($_POST['id'])){
    $id = $_POST['id'];
    $result = $product->getProductById($id);
    if($result){
        $live = $result['live'];
        echo json_encode(['live' => $live]);
    } else {
        echo json_encode(['error' => 'Category not found']);
    }
}
?>