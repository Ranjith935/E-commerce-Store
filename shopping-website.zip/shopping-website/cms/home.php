<?php  
	session_start();
	if(!isset($_SESSION['cms_loggedin'])){
		header("Location: login.php");
		exit();
	}else{
		$id = isset($_GET['id']) ? $_GET['id'] : null;
	}
?> 
<!DOCTYPE html>
<html>
<!-- PAGE NAVBAR SECTION --> 
<?php
	include('inc/header.php');
?>

<section class="cmsSection">
  <div class="container bg-secondary text-white">
	<div class="cmsContainer">
		<h5 class="fw-bold text-end"> Welcome<span> <?php echo $_SESSION['cms_username']; ?> </span></h5>
	</div>
  </div>
</section>

<?php
	include('inc/footer.php');
?>
</html>