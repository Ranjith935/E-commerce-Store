<?php  
	session_start(); 
	if(!isset($_SESSION['loggedin'])){
		header("Location: login.php");
		exit();
	}
	include('lib/banner-class.php');
	$banner = new Banner();
	$updateMessage = isset($_GET['message']) ? $_GET['message'] : null;
?>
<!DOCTYPE html>
<html>
<body>
<!-- PAGE NAVBAR SECTION -->
<?php
	include('inc/header.php');
?>

<section class="cmsBSection">
<div class="container bg-secondary">
	<div class="cmsContainer">
		<h4 class="fw-bold text-white text-center">Banner List</h4>
		<button id="addButton" class="addButton btn bg-danger text-white fw-bold">ADD</button>
		<script>
			document.getElementById('addButton').addEventListener('click',function(){
				window.location.href = 'addbanner.php';
			});
		</script>
		<?php if($updateMessage): ?>
           	<div class="d-flex justify-content-center">
                <div id="topAlert" class="alert w-75 alert-secondary alert-dismissible fade show" role="alert">
                    <strong class="text-success">Success!</strong> <?php echo $updateMessage; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
				<script>
					const url = new URL(window.location);
					url.searchParams.delete('message');
					window.history.replaceState(null,null,url);
				</script>
				<script>
					setTimeout(()=>{
						document.getElementById("topAlert").remove();
					},2000);
				</script>
           </div>
		<?php endif; ?>
			<table class="cmsBTable bg-white">
			<thead>
				<tr class="bg-black text-white">
					<th>Actions</th>
					<th>Title</th>
				</tr>
			</thead>
			  <!--<script>
					$( function() {
					 $( ".sort" ).sortable();
					});
			 </script> -->
			<tbody class="sort">
				   <?php
					$result = $banner->selectBannerData();
					if(mysqli_num_rows($result) > 0){
					  while($row= mysqli_fetch_assoc($result)){
						$image = $banner->showImage($row['title']);
						$imagePath = UPLOAD_PATH.'banners/'.$image;
				   ?>
						<tr>
						  <td>
								<div class="d-flex justify-content-center">
									<button class="imageBtn btn hover-text p-0">
										<img src="<?php echo $imagePath; ?>" class="border border-dark" alt="" width="30"  />
										<span class="tooltip-text" id="right">
											<img src="<?php echo $imagePath; ?>" alt="Cricket Image" width="480" />
										</span>
									</button>
									<button class="livebtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Live" data-id="<?php echo $row['id']; ?>" >
										<i class="fa-regular <?php if($row['live'] == 1){ echo 'fa-eye'; }else{ echo 'fa-eye-slash';} ?>"></i>
									</button>
									<button class="editbtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit" data-id="<?php echo $row['id']; ?>">
										<i class="fa-regular fa-pen-to-square"></i>
									</button>
									<button class="deletebtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete" data-id="<?php echo $row['id']; ?>">
										<i class="fa-solid fa-trash"></i>
									</button>
								</div>
						 </td>
						 <td class="w-75">
							<a class="editWithTitle text-dark" href="editbanner.php?id=<?php echo $row['id']; ?>">
								<?php echo $row['title']; ?>
							</a>
						 </td>
						</tr>
					<?php
					  }
					}else {
					?>
                    <tr><td colspan="3">No data inserted.</td></tr>
					<?php
				    	}
				    ?>
			</tbody>
		</table>
		<!--<input type="button" value="Previous Page" id="prevPage1" class="prevPage1 btn bg-danger text-white fw-bold " onclick="location.href='home.php'"/> -->
		<input type="button" value="ADD" class="addButton2 btn bg-danger text-white fw-bold" onclick="location.href='addbanner.php'"/>
	</div>
  </div>
</section>

<script>
<!--Edit Button-->
	document.querySelectorAll('.editbtn').forEach(button => {
	   button.addEventListener('click', function() {
			const id = this.getAttribute('data-id');
			window.location.href = "editbanner.php?id="+id;
		});
	});
<!--Live Button-->
	 document.querySelectorAll('.livebtn').forEach(button => {
		button.addEventListener('click', function() {
		    const id = this.getAttribute('data-id');
			const button = this;
			$.ajax({
				type: 'POST',
				url: 'togglelivebanner.php',
				data: {id:id},
				dataType: 'json',
				success: function(response) {
					if (response.live == 1) {
						alertMessage =' Banner is live';
						addAlert(alertMessage);
						button.querySelector('i').classList.remove('fa-eye-slash');
						button.querySelector('i').classList.add('fa-eye');
					} else {
						alertMessage =' Banner is un-live';
						addAlert(alertMessage);
						button.querySelector('i').classList.remove('fa-eye');
						button.querySelector('i').classList.add('fa-eye-slash');
					}
				},
				error: function(xhr,status,error) {
					console.error(xhr.responseText);
				}
				});
			});
		});
<!--Live Button function to Dsiplay alert-box-->
function addAlert(message){
	const existingAlert = document.getElementById("liveAlert");
	if(existingAlert){
		existingAlert.remove();
	}
    let alert =
			'<div id="liveAlert" class="alert w-75 alert-secondary alert-dismissible fade show" role="alert">' +
            '<strong class="text-success">Success!</strong>' + message + '.' +
            '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>' +
			'</div>';
    const mytable = document.querySelector('.cmsBTable');
    mytable.insertAdjacentHTML('beforebegin', alert);
	setTimeout(()=>{
		document.getElementById("liveAlert").remove();
	},1000)
}
<!-- Delete Button -->
		document.querySelectorAll('.deletebtn').forEach(button => {
			button.addEventListener('click', function() {
				const id= this.getAttribute('data-id');
				if(confirm('Confirm to delete?')){
					window.location.href = "deletebanner.php?id="+id;
				}
			});
		});
</script>
<script>
	var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
	var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
		return new bootstrap.Tooltip(tooltipTriggerEl)
	})
</script>
<?php
	include('inc/footer.php');
?>
</body>
</html>