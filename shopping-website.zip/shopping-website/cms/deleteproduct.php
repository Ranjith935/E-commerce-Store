<?php
	session_start();
	if (!isset($_SESSION['loggedin'])) {
		header("Location: login.php");
		exit();
	}
	include('lib/connection.php');
	
	$username = $_SESSION['cms_username'];
	$sql= "SELECT id FROM cms_users where email ='$username'";
	$res = mysqli_query($conn,$sql);
	$user = mysqli_fetch_assoc($res);
	$userId = $user['id'];
	
include('lib/products-class.php');
 $product = new Product();

// checking id
 $id = isset($_GET['id']) ? $_GET['id'] : null;
 $result = null;

 if($id){
	$result = $product->deleteProductData($id,$userId);
	// id delete_id is 1(One)
	if($result=='1'){
		echo "<script>
		alert('Product Deleted Successfully.');
		window.location.href='products.php';
		</script>";
	}
 }
?>