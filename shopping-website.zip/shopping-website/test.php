<head>
 <title>SPORTS-SHOP WEBSITE</title>
 <meta name="description" content="It is a Sports-gear shopping website">
	<meta name="viewport" content="width=device-width, initial-scale=1" >
 
   <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
  <script src="https://code.jquery.com/ui/1.13.3/jquery-ui.js"></script>
 <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.3/themes/base/jquery-ui.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- <script defer src="js/bootstrap.min.js"> </script> -->
	<script src="js/bootstrap.bundle.min.js"> </script>
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap" rel="stylesheet" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" />
	<!-- <script src="https://code.jquery.com/jquery-2.1.3.min.js"></script> -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
	<style>
	
	
	</style>
</head>

<header class="headerSection sticky-top">
<nav class="mainNavbar navbar container-fluid bg-info">

	<nav class="firstnav navbar navbar-expand-lg bg-info text-white">
		<div class="container">
			<a class="navbar-brand fw-bold" href="home.php"><i>SportsGearHub</i></a>
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent" aria-controls="navbarContent" aria-expanded="false">
				<span class="navbar-toggler-icon"></span>
			</button>

			<div class="collapse navbar-collapse " id="navbarContent">
			<div class="container w-75 mt-4 ps-0">
				<form class="d-flex" role="search">
				<input class="form-control" type="search" placeholder="Search for Gears..." aria-label="Search">
					<button class="btn btn-outline-dark" type="submit">Search</button>
				</form>
			</div>
				<ul class="navbar-nav">
					<li class="nav-item">
						<a class=" fw-bold text-dark nav-link ps-4 me-2" href="">CART <i class="fa-solid fa-cart-shopping"></i></a>
					</li>
					<li class="nav-item">
						<a class="fw-bold text-dark nav-link ps-4" href="login.php">LOGIN <i class="fa-solid fa-user"></i></a>
					</li>
				</ul>
			</div>
		</div>
	</nav>
	<nav class="secondnav navbar">
				<button class="btn fw-bold text-dark" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample" aria-controls="offcanvasExample">
						MENU <span class="menuIcon navbar-toggler-icon"></span>
				</button>
					<div class="offcanvas offcanvas-end bg-info" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
						<div class="offcanvas-header">
							<h5 class="offcanvas-title" id="offcanvasExampleLabel">Menu Items</h5>
							<button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
						</div>
						 <div class="offcanvas-body">
                               <div class="dropdown mt-3">
                                 <button class="w-100 btn btn-secondary dropdown-toggle text-start" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                                     <i class="fa-solid fa-layer-group"></i> CATEGORIES
                                 </button>
                                 <ul class="sort dropdown-menu bg-warning w-75" aria-labelledby="dropdownMenuButton">
                                     <li class="nav-item dropdown dropend">
                                         <a class="dropdown-item dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" onclick="event.stopPropagation();">INDOOR</a>
                                         <ul class="dropdown-menu bg-warning">
                                             <li><a class="dropdown-item" href="#">BADMINTON</a></li>
                                             <li><a class="dropdown-item" href="#">BASKETBALL</a></li>
                                         </ul>
                                     </li>
                                     <li class="nav-item dropdown dropend">
                                         <a class="dropdown-item dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" onclick="event.stopPropagation();">OUTDOOR</a>
                                         <ul class="dropdown-menu bg-warning">
                                             <li><a class="dropdown-item" href="#">CRICKET</a></li>
                                             <li><a class="dropdown-item" href="#">FOOTBALL</a></li>
                                             <li><a class="dropdown-item" href="#">HOCKEY</a></li>
                                             <li><a class="dropdown-item" href="#">TENNIS</a></li>
                                         </ul>
                                     </li>
                                 </ul>
							</div>
							<div class="dropdown mt-3">
								<button class="w-100 btn btn-secondary dropdown-toggle text-start" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown">
									<i class="fas fa-user mx-1"></i> PROFILE
								</button>
								<ul class="dropdown-menu bg-warning w-75" aria-labelledby="dropdownMenuButton">
									<li><a class="dropdown-item" href="#">My account  <i class="fa-solid fa-id-card-clip"></i> </a></li>
									<li><a class="dropdown-item" href="#">Log out  <i class="fa-solid fa-right-from-bracket"></i></a></li>
									<li><a class="dropdown-item" href="#">Address  <i class="fa-solid fa-address-book"></i></a></li>
									<li><a class="dropdown-item" href="#">Orders  <i class="fa-brands fa-shopify"></i></a></li>
								</ul>
							</div>
							<div class="form-check form-switch">
    <input class="form-check-input" type="checkbox" id="darkModeSwitch" checked>
    <label class="form-check-label" for="darkModeSwitch">Dark Mode</label>
</div>

<script>
document.addEventListener('DOMContentLoaded', (event) => {
    const htmlElement = document.documentElement;
    const switchElement = document.getElementById('darkModeSwitch');

    // Set the default theme to dark if no setting is found in local
    const currentTheme = localStorage.getItem('bsTheme') || 'dark';
    htmlElement.setAttribute('data-bs-theme', currentTheme);
    switchElement.checked = currentTheme === 'dark';

    switchElement.addEventListener('change', function () {
        if (this.checked) {
            htmlElement.setAttribute('data-bs-theme', 'dark');
            localStorage.setItem('bsTheme', 'dark');
        } else {
            htmlElement.setAttribute('data-bs-theme', 'light');
            localStorage.setItem('bsTheme', 'light');
        }
    });
});
</script>

							
						</div>
					</div>
	</nav>
</nav>
</header>
<!--<section>
<div onload="addState()">
<button onload="addState()">
        Add history state
</button>
    <script>
        function addState() {
            let stateObj = { id: "100" };
 
            window.history.pushState(stateObj,
                "Page 2", "/page2.html");
        } 
    </script>
</div>
</section> -->
<!-- table sort  -->
<section>
<div>
</div>

<div class="container">
<script>
$( function(){
	$(".sort").sortable();
});
</script>
		<table class="cmsBTable bg-white mt-2 sortable sortable">
			<thead>
				<tr class="bg-black text-white">
					<th>Actions</th>
					<th>Title</th>
					<th class="w-75">Description</th>
				</tr>
			</thead>
			<tbody class="sort">
					<tr class="text-dark">
						<td>
							<div class="d-flex ms-4">
								<button class="btn" style="border:none;" disabled>
									<i class="fa-solid fa-arrow-right-long text-center"></i>
								</button>
								<button class="imageBtn btn hover-text p-0">
									<img src="abcd " class="border border-dark" alt="" width="30" />
									<span class="tooltip-text" id="right">
										<img src="abcd" alt="Image" width="170" />
									</span>
								</button>
								<button class="editbtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit" data-id="" >
									<i class="fa-regular fa-pen-to-square"></i>
								</button>
							</div>
						</td>
						<td class="w-25">21347123</td>
						<td class="w-50">1231</td>
					</tr>
					<tr class="text-dark">
						<td>
							<div class="d-flex ms-4">
								<button class="btn" style="border:none;" disabled>
									<i class="fa-solid fa-arrow-right-long text-center"></i>
								</button>
								<button class="imageBtn btn hover-text p-0">
									<img src="abcd " class="border border-dark" alt="" width="30" />
									<span class="tooltip-text" id="right">
										<img src="abcd" alt="Image" width="170" />
									</span>
								</button>
								<button class="editbtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit" data-id="" >
									<i class="fa-regular fa-pen-to-square"></i>
								</button>
							</div>
						</td>
						<td class="w-25">0000002</td>
						<td class="w-50">0000012</td>
					</tr>
					<tr class="text-dark">
						<td>
							<div class="d-flex ms-4">
								<button class="btn" style="border:none;" disabled>
									<i class="fa-solid fa-arrow-right-long text-center"></i>
								</button>
								<button class="imageBtn btn hover-text p-0">
									<img src="abcd " class="border border-dark" alt="" width="30" />
									<span class="tooltip-text" id="right">
										<img src="abcd" alt="Image" width="170" />
									</span>
								</button>
								<button class="editbtn btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit" data-id="" >
									<i class="fa-regular fa-pen-to-square"></i>
								</button>
							</div>
						</td>
						<td class="w-25">ABCDE</td>
						<td class="w-50">AERTDD</td>
					</tr>
			</tbody>
		</table>
</div>
</section>