<?php
	class Register{
		public function checkRegister(){
			global $conn;
			$fname = $_POST['registerFName'];
            $lname = $_POST['registerLName'];
            $address = mysqli_escape_string($conn, $_POST['registerAddress']);
            $address2 = mysqli_escape_string($conn, $_POST['registerAddress2']);
            $city = $_POST['registerCity'];
            $state = $_POST['registerState'];
            $postal = $_POST['registerPostalcode'];
            $country = $_POST['registerCountry'];
            $pnumber = $_POST['registerNumber'];
            $email = $_POST['registerEmail'];
            $password = $_POST['registerPassword'];
            $ip = $_SERVER['REMOTE_ADDR'];
			
			$check_sql = "SELECT * FROM users WHERE email='$email' OR phone_number = '$pnumber'";
			$check_result = mysqli_query($conn, $check_sql);
			$check_count = mysqli_num_rows($check_result);

			if($check_count > 0){
				return "failed";
			} else {
				//ENCRYPTING PASSWORD
				$enteredPass =  base64_encode($password);
                $salt = 'a;g0d-wd8*oiba';
                $enteredPass = hash("sha256", $enteredPass.$salt);
                $enteredPass = strrev($enteredPass);

				$sql = "INSERT INTO users SET
				`first_name` = '".$fname."',
				`last_name` = '".$lname."',
				`address` = '".$address."',
				`address_two` = '".$address2."',
				`town_city` = '".$city."',
				`county_state` = '".$state."',
				`postal_code` = '".$postal."',
				`country` = '".$country."',
				`phone_number` = '".$pnumber."',
				`email` = '".$email."',
				`password` = '".$enteredPass."',
				`ip_address` = '".$ip."'";
			$result = mysqli_query($conn, $sql);
			return "successful";
			}
	}
}
?>