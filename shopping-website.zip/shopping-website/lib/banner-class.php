<?php
	class bannerSection{
		public function updateBannerSection(){
			global $conn;
			$sql = "SELECT image 
                FROM banner
                WHERE live = '1' AND delete_id ='0'";
			$result= mysqli_query($conn,$sql);
			return $result;
		}
	}
?>