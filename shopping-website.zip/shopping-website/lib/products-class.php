<?php
	class productSection {
		public function queryMainCategory(){
			global $conn;
			$sql = "SELECT id FROM category 
					WHERE delete_id='0'
					AND live='1'
					AND parent_id !='0' LIMIT 4 ";
			$result = mysqli_query($conn, $sql);
			return $result;
		}
		public function queryProductForCategory($id){
			global $conn;
			$sql ="SELECT id, title, image, price
				FROM products WHERE live='1'
				AND delete_id='0' 
				AND id IN
				(SELECT prod_id FROM prod_cat_join
				WHERE cat_id ='".$id."') ORDER BY sort_id LIMIT 4";
			$result = mysqli_query($conn, $sql);
			return $result;
		}
	}
?>