<?php
	class categorySection {
		public function updateCategorySection() {
			global $conn;
			$sql = "SELECT c1.title,c1.image,c1.font_class,c1.parent_id
				FROM category c1
				JOIN category c2 ON c1.parent_id = c2.id
				WHERE c1.live = '1'
				  AND c1.delete_id = '0'
				  AND c2.parent_id = '0'
				  AND c2.live = '1'
				  AND c2.delete_id ='0'";
			$result = mysqli_query($conn, $sql);
			return $result;
		}
		public function updateCategoryMenu() {
			global $conn;
			$sql = "SELECT title,font_class,id
				FROM category
				WHERE parent_id = '0' AND live='1' AND delete_id ='0'";
			$result = mysqli_query($conn, $sql);
			return $result;
		}
	}
?>