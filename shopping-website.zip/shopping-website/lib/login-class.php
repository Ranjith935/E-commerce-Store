<?php
class Login{
	public function checkLoginData($email,$password){
		global $conn;
		//COMPARING WITH ENCRYPTED PASSWORD
		$enteredPass =  base64_encode($password);
        $salt = 'a;g0d-wd8*oiba';
        $enteredPass = hash("sha256", $enteredPass.$salt);
        $enteredPass = strrev($enteredPass);
		$sql = "SELECT * FROM users WHERE email ='$email' AND password ='$enteredPass'";
		$result = mysqli_query($conn,$sql);
		$count = mysqli_num_rows($result);
		if($count>0){
			return "successful";
		}else{
			return "failed";
		}
	}
	public function queryFirstName($id){
		global $conn;
		$sql = "SELECT first_name FROM users WHERE id ='$id'";
		$result = mysqli_query($conn,$sql);
		$row = mysqli_fetch_assoc($result);
		return $row['first_name'];
	}
}
?>