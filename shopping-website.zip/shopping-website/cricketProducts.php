<?php 
	session_start();
?>
<?php
	include('inc/header.php');
?>

<section>
  <div class="container">
	<h5 class="fw-bold">Cricket Products!</h5>
	<div class="row">
		<div class="col">
		</div>
	</div>
  </div>
</section>

<?php 
	include('inc/footer.php');
?>