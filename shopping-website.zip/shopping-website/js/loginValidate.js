function myFunction() {
    		var x = document.getElementById("loginPassword");
    		if (x.type === "password"){
    			x.type = "text";
    		} else {
    			x.type = "password";
    		}
    	}
function isvalid(){
			var email = document.getElementById("loginEmail").value;
			var pass = document.getElementById("loginPassword").value;
			valid = true;
			if(email.length ==""){
				emailError.innerHTML ='Enter your Email';
				valid = false;
			}else{
				emailError.innerHTML ="";
			}
			if(pass.length ==""){
				passwordError.innerHTML = 'Enter your Password';
				valid = false;
			}else{
				passwordError.innerHTML ="";
			}
			return valid;
		}