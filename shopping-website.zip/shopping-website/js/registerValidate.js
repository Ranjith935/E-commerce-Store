function myFunction() {
					var x = document.getElementById("registerPassword");
					var y = document.getElementById("registerConfirmPassword");
					if ((x.type === "password") &&(y.type === "password")) {
						x.type = "text";
						y.type = "text";
					}else {
						y.type = "password";
						x.type = "password";
					}
			}

function isvalid(){
				var fname = document.getElementById("registerFName").value;
				var lname = document.getElementById("registerLName").value;
				var add1 = document.getElementById("registerAddress").value;
				var add2 = document.getElementById("registerAddress2").value;
				var city = document.getElementById("registerCity").value;
				var state = document.getElementById("registerState").value;
				var post = document.getElementById("registerPostalcode").value;
				var country = document.getElementById("registerCountry").value;
				var pnumber = document.getElementById("registerNumber").value;
				var email = document.getElementById("registerEmail").value;
				var pass = document.getElementById("registerPassword").value;
				var rpass = document.getElementById("registerConfirmPassword").value;
				
				var fnameError = document.getElementById("fnameError");
				var lnameError = document.getElementById("lnameError");
				var addressError = document.getElementById("addressError");
				var cityError = document.getElementById("cityError");
				var stateError = document.getElementById("stateError");
				var postalcodeError = document.getElementById("postalcodeError");
				var countryError = document.getElementById("countryError");
				var phoneError = document.getElementById("phoneError");
				var emailError = document.getElementById("emailError");
				var passwordError = document.getElementById("passwordError");
				var confirmPasswordError = document.getElementById("confirmPasswordError");
				var pattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
				
				var valid = true;
				
				if(fname.length ==""){
					fnameError.innerHTML ='Enter your First name';
					valid = false;
				}else{
					document.getElementById("registerFName").innerHTML = fname;
					fnameError.innerHTML='';
				}
				if(add1.length == ""){
					addressError.innerHTML ='Enter your Address';
					valid = false;
				}else{
					document.getElementById("registerAddress").innerHTML = add1;
					addressError.innerHTML ='';
				}
				if(city.length == ''){
					cityError.innerHTML = 'Enter your City';
					valid = false;
				}else{
					document.getElementById("registerCity").innerHTML = city;
					cityError.innerHTML ='';
				}
				if(state.length == ""){
					stateError.innerHTML =' Enter your State';
					valid = false;
				}else{
					document.getElementById("registerState").innerHTML = state;
					stateError.innerHTML ='';
				}
				if(post.length == ""){
					postalcodeError.innerHTML = 'Enter your Postal-code';
					valid = false;
				}else{
					document.getElementById("registerPostalcode").innerHTML = post;
					postalcodeError.innerHTML = '';
				}
				if(country.length == ''){
					countryError.innerHTML = 'Enter your Country';
					valid = false;
				}else{
					document.getElementById("registerCountry").innerHTML = country;
					countryError.innerHTML = '';
				}
				if(pnumber.length == ""){
					phoneError.innerHTML ='Enter your Phone Number';
					valid = false;
				}else{
					document.getElementById("registerNumber").innerHTML = pnumber;
					phoneError.innerHTML = '';
				}
				if(email.length ==""){
					emailError.innerHTML ='Enter your Email';
					valid = false;
				}else{
					document.getElementById("registerEmail").innerHTML = email;
					emailError.innerHTML = '';
				}
				if(pass.length ==""){
					passwordError.innerHTML ='Enter your Password';
					valid = false;
				}else{
					document.getElementById("registerPassword").innerHTML = pass;
					passwordError.innerHTML='';
				}
				if(rpass.length ==""){
					confirmPasswordError.innerHTML ='Confirm your Password';
					valid = false;
				}else{
					document.getElementById("registerConfirmPassword").innerHTML = rpass;
					confirmPasswordError.innerHTML = '';
				}
				if(!pattern.test(email)){
					emailError.innerHTML='Enter valid Email';
					valid = false;
				}else{
					document.getElementById("registerEmail").innerHTML = email;
					emailError.innerHTML = '';
				}
				if(pass!=rpass){
					confirmPasswordError.innerHTML ='Password didnot match';
					valid = false;
				}else{
					document.getElementById("registerConfirmPassword").innerHTML = rpass;
					confirmPasswordError.innerHTML ='';
				}
				if(pass.length<6){
					passwordError.innerHTML ='Enter Password (length >=6)';
					valid = false;
				}else{
					document.getElementById("registerPassword").innerHTML = pass;
					passwordError.innerHTML = '';
				}
				return valid;
			}