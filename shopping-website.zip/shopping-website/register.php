<?php 
	include('inc/header.php');
	include('lib/register-class.php');
	$register = new Register;
	$message='';
?>
<!--REGISTER -->
<?php
	$fname =$lname= $address = $address2 = $city = $state = $postal = $country = $pnumber = $email = $password = $confirmPassword = "";
	$fnameError = $addressError = $cityError = $stateError = $postalcodeError = $countryError = $phoneError = $emailError = $passwordError = $confirmPasswordError = "";
	
if(isset($_POST['register'])){
	
	$fname = $_POST['registerFName'];
	$lname = $_POST['registerLName'];
	$address = $_POST['registerAddress'];
	$address2 = $_POST['registerAddress2'];
	$city = $_POST['registerCity'];
	$state = $_POST['registerState'];
	$postal = $_POST['registerPostalcode'];
	$country = $_POST['registerCountry'];
	$pnumber = $_POST['registerNumber'];
	$email = $_POST['registerEmail'];
	$password = $_POST['registerPassword'];
	$confirmPassword = $_POST['registerConfirmPassword'];
	
	if(empty($fname)){
		$fnameError = 'Enter your First Name';
	}
	if(empty($address)){
		$addressError = 'Enter your Address';
	}
	if(empty($city)){
		$cityError = 'Enter your City';
	}
	if(empty($state)){
		$stateError = 'Enter your State';
	}
	if(empty($postal)){
		$postalcodeError = 'Enter your Postal-code';
	}
	if(empty($country)){
		$countryError = 'Enter your Country';
	}
	if(empty($pnumber)){
		$phoneError = 'Enter your Phone Number';
	}
	if(empty($email)){
		$emailError = 'Enter your Email';
	}
	if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		$emailError = "Invalid email format";
	}
	if(empty($password)){
		$passwordError = 'Enter your Password';
	}
	if(strlen($password)<6){
		$passwordError='Enter length should be >=6';
	}
	if(empty($confirmPassword)){
		$confirmPasswordError = 'Confirm your Password';
	}
	if($password !== $confirmPassword){
		$confirmPasswordError = 'Passwords do not match';
	}
	
	if(empty($fnameError) && empty($addressError) && empty($cityError) && empty($stateError) && empty($postalcodeError) && empty($countryError) && empty($phoneError) && empty($emailError) && empty($passwordError) && empty($confirmPasswordError)){
		$result = $register->checkRegister();
		if($result === "successful"){
			$fname = $lname = $address = $address2 = $city = $state = $postal = $country = $pnumber = $email = $password = $confirmPassword = "";
			$message = 'Registration Successful!';
		}else if($result === "failed"){
			$message = 'User already exists!';
		}
	}
}
?>
<!--ALERT BOX FOR REGISTER PAGE -->
<?php if($message):?>
    <div class="d-flex justify-content-center">
        <div class="alert text-center w-75 alert-warning alert-dismissible fade show mt-3 mb-0" role="alert">
            <strong class="text-danger"><?php echo $message; ?></strong> 
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    </div>
<?php endif; ?>

<section class="registerPage">
  <div class="container registerContainer">
    <div class="row justify-content-center align-items-center">
        <div class="card bg-secondary text-white">
            <h2 class="fw-bold text-center">REGISTER</h2>
            <p class="text-white-50 text-center mb-4">Please create an Account!</p>
	        <form name="form" action="" method="POST" onsubmit="return isvalid()">
                      <div class="row">
                        <div class="col col-md-6 col-lg-6">
							<label class="form-label" for="registerFName">Firstname</label>
							<input type="text" id="registerFName" name="registerFName" class="form-control" placeholder="Enter your First name" value="<?php echo $fname; ?>" />
							<span id="fnameError" style="color:red;font-size:13px;padding-left:15px;"><?php echo $fnameError; ?></span>
                        </div>
                        <div class="col col-md-6 col-lg-6">
							<label class="form-label" for="registerLName">Lastname</label>
							<input type="text" id="registerLName" name="registerLName" class="form-control" placeholder="Enter your Last name" value="<?php echo $lname; ?>"/>
							<!--<span id="lnameError" style="color:red;font-size:13px;padding-left:15px;"><?php //echo $lnameError; ?></span> -->
                        </div>
                      </div>
					  <div class="row">
	        			<div class="col col-md-6 col-lg-6">
	        				<label class="form-label" for="registerAddress">Address</label>
	        				<textarea class="form-control" id="registerAddress" name ="registerAddress" rows="3" placeholder="Enter your Address"><?php echo $address; ?></textarea>
	        				<span id="addressError" style="color:red;font-size:13px;padding-left:15px;"><?php echo $addressError; ?></span>
	        			</div>
	        			<div class="col col-md-6 col-lg-6">
	        				<label class="form-label" for="registerAddress2">Address-2</label>
	        				<textarea class="form-control" id="registerAddress2" name ="registerAddress2" rows="3" placeholder="Enter your Address-2"><?php echo $address2; ?></textarea>
	        				<!--<span id="address2Error" style="color:red;font-size:13px;padding-left:15px;"><?php //echo $emailError; ?></span> -->
	        			</div>
	        		  </div>
					  <div class="row">
	        			<div class="col col-md-4 col-lg-4">
	        				<label class="form-label" for="registerCity">Town/City</label>
	        				<input type="text" id="registerCity" name ="registerCity" class="form-control" placeholder="Enter your City" value="<?php echo $city;  ?>"/>
	        				<span id="cityError" style="color:red;font-size:13px;padding-left:15px;"><?php echo $cityError; ?></span>
	        			</div>
						<div class="col col-md-4 col-lg-4">
	        				<label class="form-label" for="registerState">State/Province</label>
	        				<input type="text" id="registerState" name ="registerState" class="form-control" placeholder="Enter your State" value="<?php echo $state;  ?>"/>
	        				<span id="stateError" style="color:red;font-size:13px;padding-left:15px;"><?php echo $stateError; ?></span>
	        			</div>
						<div class="col col-md-4 col-lg-4">
	        				<label class="form-label" for="registerPostalcode">Postal-code</label>
	        				<input type="text" id="registerPostalcode" name ="registerPostalcode" class="form-control" placeholder="Enter your postal-code" value="<?php echo $postal; ?>"/>
	        				<span id="postalcodeError" style="color:red;font-size:13px;padding-left:15px;"><?php echo $postalcodeError; ?></span>
	        			</div>
	        		  </div>
					  <div class="row">
	        			<div class="col col-md-6 col-lg-6">
	        				<label class="form-label" for="registerCountry">Country</label>
	        				<input type="text" id="registerCountry" name ="registerCountry" class="form-control" placeholder="Enter your Country" value="<?php echo $country;  ?>"/>
	        				<span id="countryError" style="color:red;font-size:13px;padding-left:15px;"><?php echo $countryError; ?></span>
	        			</div>
	        		  </div>
					  <div class="row">
	        			<div class="col col-md-6 col-lg-6">
	        				<label class="form-label" for="registerNumber">Phone Number</label>
	        				<input type="text" id="registerNumber" name ="registerNumber" class="form-control" placeholder="Enter your Phone Number" value="<?php echo $pnumber ?>"/>
	        				<span id="phoneError" style="color:red;font-size:13px;padding-left:15px;"><?php echo $phoneError; ?></span>
	        			</div>
	        		  </div>
	        		  <div class="row">
	        			<div class="col col-md-6 col-lg-6">
	        				<label class="form-label" for="registerEmail">Email</label>
	        				<input type="email" id="registerEmail" name ="registerEmail" class="form-control" placeholder="Enter your Email" value="<?php echo $email; ?>"/>
	        				<span id="emailError" style="color:red;font-size:13px;padding-left:15px;"><?php echo $emailError; ?></span>
	        			</div>
	        		  </div>
	        		  <div class="row">
	        			<div class="col col-md-6 col-lg-6">
	        				<label class="form-label" for="registerPassword">Password</label>
	        				<input type="password" id="registerPassword" name="registerPassword" class="form-control form-control" placeholder="Enter your Password" value="<?php echo $password; ?>"/>
	        				<span id="passwordError" style="color:red;font-size:13px;padding-left:15px;"><?php echo $passwordError; ?></span>
	        			</div>
	        			<div class="col col-md-6 col-lg-6">
	        				<label class="form-label" for="registerConfirmPassword">Confirm Password</label>
	        				<input type="password" id="registerConfirmPassword" name="registerConfirmPassword" class="form-control form-control" placeholder="Confirm your Password" value="<?php echo $confirmPassword ?>"/>
	        				<span id="confirmPasswordError" style="color:red;font-size:13px;padding-left:15px;"><?php echo $confirmPasswordError; ?></span>
	        			</div>
	        			<span style="font-size:14px;"><input style="width:30px; height:20px;" type="checkbox" onclick="myFunction()">Show Password </span>
	        		  </div>
	        		  <div class="text-center">
							<button class="btn btn-outline-light btn-lg" type="submit" name="register" id="register">Register</button>
							<div>
								<p class="mb-0">Already have an account? <a href="login.php" class="text-white-50 fw-bold">Login</a></p>
							</div>
	        		  </div>
	        </form>
        </div>
    </div>
  </div>
  <script type="text/javascript" src="js/registerValidate.js"></script>
</section>

<?php 
	include('inc/footer.php');
?>